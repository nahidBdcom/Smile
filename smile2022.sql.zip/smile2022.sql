-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 28, 2022 at 10:43 AM
-- Server version: 8.0.31-0ubuntu0.20.04.1
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smile2022`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int NOT NULL DEFAULT '0',
  `order` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `brand_category_id` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`, `logo`, `url`, `status`, `order`, `created_at`, `updated_at`, `brand_category_id`) VALUES
(1, 'Dutch Bangla Bank', 'brands/November2022/cKFCHy6PAHuPHZDofbed.png', 'www.dbbl.com', 1, 1, '2022-11-12 21:51:01', '2022-11-12 21:54:16', 1),
(2, 'City Bank', 'brands/November2022/YC8w797IHp5ukgvn9ksx.png', 'www.citybank.com', 1, 2, '2022-11-12 21:53:39', '2022-11-12 21:54:17', 1),
(3, 'Nagad', 'brands/November2022/CtcZXs6Ijt0wsqNE05aD.png', 'www.nagad.com.bd', 1, 3, '2022-11-12 21:54:01', '2022-11-12 21:54:17', 2),
(4, 'Bkash', 'brands/November2022/1ixChw4XlVGXNB06udhv.png', 'www.bkash.com', 1, 4, '2022-11-12 21:54:47', '2022-11-12 21:54:58', 2);

-- --------------------------------------------------------

--
-- Table structure for table `brand_categories`
--

CREATE TABLE `brand_categories` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brand_categories`
--

INSERT INTO `brand_categories` (`id`, `name`, `slug`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Bank', 'bank', 'Financial Organization', '2022-11-12 21:39:35', '2022-11-12 21:39:35'),
(2, 'MFS', 'mfs', 'Mobile Financial Solutions', '2022-11-12 21:40:15', '2022-11-12 21:40:15');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int UNSIGNED NOT NULL,
  `parent_id` int UNSIGNED DEFAULT NULL,
  `order` int NOT NULL DEFAULT '1',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `order`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, NULL, 1, 'Category 1', 'category-1', '2021-07-19 01:13:02', '2021-07-19 01:13:02'),
(2, NULL, 1, 'Category 2', 'category-2', '2021-07-19 01:13:02', '2021-07-19 01:13:02'),
(3, NULL, 1, 'Category 3', 'category-3', '2021-10-27 02:40:42', '2021-10-27 02:40:42');

-- --------------------------------------------------------

--
-- Table structure for table `connectivity_applications`
--

CREATE TABLE `connectivity_applications` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_id` int NOT NULL,
  `internet_coverage_id` int DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `package_id` int NOT NULL,
  `promo_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `policy_agreed` tinyint(1) DEFAULT NULL,
  `is_human_verified` tinyint DEFAULT NULL,
  `human_verification_result` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remote_addr` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remote_port` int DEFAULT NULL,
  `request_scheme` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_method` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `platform` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser_maker` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser_version` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_pointing_method` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `minorver` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ismobiledevice` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `istablet` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crawler` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `http_user_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isemailed` int DEFAULT '0',
  `emailed_to` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_sent_by_api` int DEFAULT '0',
  `api_request_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `api_reply_data` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `referrer_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `connectivity_applications`
--

INSERT INTO `connectivity_applications` (`id`, `name`, `phone`, `email`, `district_id`, `internet_coverage_id`, `address`, `package_id`, `promo_code`, `policy_agreed`, `is_human_verified`, `human_verification_result`, `remote_addr`, `remote_port`, `request_scheme`, `request_method`, `platform`, `browser`, `browser_maker`, `browser_version`, `device_type`, `device_pointing_method`, `minorver`, `ismobiledevice`, `istablet`, `crawler`, `http_user_agent`, `isemailed`, `emailed_to`, `is_sent_by_api`, `api_request_data`, `api_reply_data`, `created_at`, `updated_at`, `referrer_id`) VALUES
(24, 'Nahid Reaz', '01521430518', 'nahidreaz8@gmail.com', 1, NULL, '', 8, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, '2022-11-17 03:28:33', '2022-11-17 03:28:33', ''),
(25, 'Nahid Reaz', '01521430518', 'nahidreaz8@gmail.com', 1, NULL, '', 7, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, '2022-11-17 04:16:17', '2022-11-17 04:16:17', ''),
(26, 'Nahid Reaz', '01521430518', 'nahidreaz8@gmail.com', 1, NULL, '', 7, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, '2022-11-17 04:17:50', '2022-11-17 04:17:50', ''),
(27, 'Nahid Reaz', '01521430518', 'nahidreaz8@gmail.com', 1, NULL, '', 5, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, '2022-11-17 04:19:30', '2022-11-17 04:19:30', ''),
(28, 'Nahid Reaz', '01521430518', 'nahidreaz8@gmail.com', 1, NULL, '', 8, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, '2022-11-17 04:20:12', '2022-11-17 04:20:12', ''),
(29, 'Nahid Reaz', '01521430518', 'nahidreaz8@gmail.com', 13, NULL, '', 7, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, '2022-11-17 04:22:08', '2022-11-17 04:22:08', ''),
(30, 'Nahid Reaz', '01521430518', 'nahidreaz8@gmail.com', 1, NULL, '', 8, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, NULL, '2022-11-22 00:38:03', '2022-11-22 00:38:03', '');

-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE `contents` (
  `id` int UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description_more` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_titlle` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meta_keyword` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `og_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `og_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int NOT NULL DEFAULT '0',
  `created_by` int UNSIGNED NOT NULL,
  `last_updated_by` int UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contents`
--

INSERT INTO `contents` (`id`, `title`, `slug`, `description_title`, `description_excerpt`, `description_more`, `description_image`, `seo_titlle`, `meta_description`, `meta_keyword`, `og_title`, `og_description`, `og_image`, `status`, `created_by`, `last_updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Home', '/', 'No. 1 broadband internet service provider in Bangladesh with most cost effective package plans.', '<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">Smile Broadband- a service brand of BDCOM Online Ltd., is now a common name among the home broadband users of Bangladesh as the Brand has now emerged as the top broadband internet service provider in the country. With super fast speed, 24/7 customer support, countrywide network and the best value for money broadband internet package plans, Smile topped the wish list of internet users in Bangladesh.</span></p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\">&nbsp;</p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">Satisfied customers paved the way to become the brand smile is today and this is the motivating reason for everyone in the team to pursue the goal of satisfying the users above all. To satisfy the ever increasing demand of the internet users in Bangladesh, smile has designed its internet package plans to provide more bandwidth speed at less price.</span></p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\">&nbsp;</p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">With faster and stable performance, Smile users enjoy faster downloads, buffer-less videos and lag-free browsing, even with multiple users online at once from your home. We strive to empower our users with the freedom to access with no limitation, also every package is included with Dynamic Real IP that ensures user&rsquo;s authenticity and limitless accessibility over the web. We believe that there is no certain/Ideal time for internet usage, which is why we commit &ldquo;No Peak-No off Peak, accurate speed and 24/7 prompt customer support. Since smile package plans don\'t have any FUP or Data cap, all users enjoy package-wise bandwidth speed 24/7.</span></p>', '<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">From 2020, Smile took an initiative called &ldquo;Internet for all - সবার জন্য ইন্টারনেট\'\' to make internet affordable to every household around the country. Under this initiative, smile is offering a 5Mbps broadband internet package at 300Tk./Month which has received a tremendous response in broadband users communities in Bangladesh. From Urban to Rural, We aim to connect every household in Bangladesh to the digital world.</span></p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\">&nbsp;</p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">In June 2021, Bangladesh Telecommunication Regulatory Commission (BTRC), inaugurated a common broadband internet tariff plan for rural areas called \"ek desh ek rate - এক দেশ এক রেট\" and made it mandatory for all ISP operating in Bangladesh. Fortunately, the prices of all smile packages were already aligned with the declared tariff plan. And, after the declaration off \"ek desh ek rate - এক দেশ এক রেট\", smile immediately responded with govt. policies and launched three new \"ek desh ek rate - এক দেশ এক রেট\"&nbsp; package plans for rural areas &amp; union parishad level as per BTRC instruction.</span></p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\">&nbsp;</p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">Currently Smile is providing it\'s broadband internet in Dhaka, Comilla, Sylhet, Chittagong, Khulna, Bogra,&nbsp; Narayanganj, Rajshahi, Rangpur, Tangail, Kushtia, Jessore, and Mymensingh. So, whenever someone looks for a broadband internet service provider near these locations, smile gets No. 1 place in their choice list.</span></p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\">&nbsp;</p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">So don&rsquo;t get confused between the peak and off-peak riddle, have a look at our most affordable broadband internet packages and choose what suits best to your requirements. To get the broadband connectivity, just fill up the connectivity application form or call 09666 666 666. After that our team will contact you immediately with all additional details and ensure a prompt installation service.</span></p>', 'contents/medicine-3298451_1920 (1).jpg', 'Smile broadband | best broadband internet service provider in bd', 'The best broadband internet service provider in Bangladesh that provides broadband packages at best price with accurate bandwidth speed 24/7.', 'best broadband internet service provider in bd', 'Smile broadband | best broadband internet service provider in bd', 'The best broadband internet service provider in Bangladesh that provides broadband packages at best price with accurate bandwidth speed 24/7.', 'contents/medicine-3298451_1920 (1).jpg', 1, 1, 3, '2021-08-28 23:49:37', '2021-10-27 02:19:45'),
(2, 'Contact us', 'contact', 'Contact us', '<p>JL Bhaban (5th floor)</p>\r\n<p>House # 1, Road # 1, Gulshan Avenue, Gulshan-1</p>\r\n<p>Dhaka-1212, Bangladesh</p>\r\n<p>&nbsp;</p>\r\n<p>Phone : +88 09666 333 666</p>\r\n<p>24/7 Helpdesk : +8809666 666 666</p>\r\n<p>E-mail : office@bdcom.com</p>\r\n<p>&nbsp;</p>\r\n<p>Web : www.bdcom.com</p>', NULL, 'contents/dummy-400.jpg', 'Contact SEO title', 'Contact SEO Meta Description', 'Contact SEO Meta Keyword', 'Contact Og Title', 'Contact Og Description', 'contents/dummy-400.jpg', 1, 1, 3, '2021-08-29 06:16:03', '2021-09-23 02:53:17'),
(3, 'Connectivity Application', 'connectivity', 'Why people love Smile', '<p>SMILE Broadband &amp; Phone is a registered service brand of BDCOM Online Limited, a Public Limited Company, 19 Years of Internet Service Portfolio, Enthusiastic about Customer Service. SMILE Broadband &amp; Phone is the first Nationwide Internet Service in Bangladesh that provides High Speed Fiber Broadband internet in Countrywide with single price model. SMILE Broadband &amp; Phone strives to empower its Internet users with the freedom to access Infotainment content and to surf with no limitation.</p>', '<p>We value ourselves as the innovative Nationwide ISP that pioneered the removal of restrictive industry practices like bandwidth caps and traffic shaping. At the same time, we implemented best practices such as best path routing, ensuring that subscribers get exactly what they pay for &ndash; fast internet access. Network fully complied with IPv6 routing.</p>', NULL, 'Connectivity Application Seo Titlle', 'Connectivity Application Meta Description', 'Connectivity Application Meta Keyword', 'Connectivity Application Og Title', 'Connectivity Application Og Description', 'contents/dummy-400.jpg', 1, 1, 1, '2021-09-05 02:00:01', '2021-11-02 22:44:44'),
(4, 'Helpdesk 09666 666 666 Available 24/7', 'helpdesk', 'Helpdesk', '<p id=\"docs-internal-guid-a0c38d84-7fff-ccba-bee0-de7df31079fc\" dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;\">When your internet connection doesn&rsquo;t work as Committed, it impacts both your personal and professional goals. With Smile broadband internet, You have dedicated engineers ready to serve you 24/7/365 to ensure real time solution for any technical woes. Whether it\'s day or night, we ensure you get prompt responses that no other internet service provider can assure.</span></p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\">&nbsp;</p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;\">To delight you with maximum service quality, we always keep our support engineers updated with latest knowledge and industry-leading tools to resolve any issues rapidly and accurately through regular training and live workshops.</span></p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\">&nbsp;</p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;\">Check out our BASIC TROUBLESHOOTING TIPS below. If that information doesn\'t solve your issues, just give us a call on +8809666 666 666 or report a problem using the form below.</span></p>', NULL, NULL, 'Helpdesk Seo Titlle', 'Meta Description', 'Meta Keyword', 'Og Title', 'Og Description', NULL, 1, 1, 3, '2021-09-07 04:03:05', '2021-10-27 02:10:53'),
(5, 'Media Center', 'blog', 'Blogs', '<p>Blog</p>', '<p>Blog</p>', NULL, 'Blogs Seo Titlle', 'Blogs Meta Description', 'Blogs Meta Keyword', 'Blogs Og Title', 'Blogs Og Description', NULL, 1, 1, NULL, '2021-09-09 00:17:38', '2021-09-09 00:17:38'),
(6, 'About Smile Broadband - Internet for All', 'about', 'About Smile Broadband - Internet for All', '<div class=\"col-12 s-pb-25\" style=\"text-align: justify;\">\r\n<h3>WHO WE ARE</h3>\r\nsed blandit libero volutpat sed cras ornare arcu dui vivamus arcu felis bibendum ut tristique et egestas quis ipsum suspendisse ultrices gravida dictum fusce ut placerat orci nulla pellentesque dignissim enim sit amet venenatis urna cursus eget nunc scelerisque viverra mauris in aliquam sem fringilla ut morbi tincidunt augue interdum velit euismod in pellentesque massa placerat duis ultricies lacus sed turpis tincidunt id aliquet risus feugiat in ante metus dictum at tempor commodo ullamcorper a lacus vestibulum sed arcu non odio euismod lacinia at quis risus sed vulputate odio ut enim blandit volutpat maecenas volutpat blandit aliquam etiam erat velit.</div>\r\n<div class=\"col-12 col-md-6 s-py-25\" style=\"text-align: justify;\">\r\n<h3>OUR VALUES</h3>\r\n<ul>\r\n<li>sed blandit libero volutpat sed cras ornare arcu</li>\r\n<li>sed blandit libero volutpat sed cras ornare arcu</li>\r\n<li>sed blandit libero volutpat sed cras ornare arcu sed blandit libero volutpat sed cras ornare arcu</li>\r\n<li>sed blandit libero volutpat sed cras ornare arcu</li>\r\n<li>sed blandit libero volutpat sed cras ornare arcu</li>\r\n<li>sed blandit libero volutpat sed cras ornare arcu</li>\r\n</ul>\r\n</div>\r\n<div class=\"col-12 col-md-6 s-py-25\" style=\"text-align: justify;\">\r\n<h3>OUR COMMITEMENTS</h3>\r\n<ul>\r\n<li>sed blandit libero volutpat sed cras ornare arcu</li>\r\n<li>sed blandit libero volutpat sed cras ornare arcu</li>\r\n<li>sed blandit libero volutpat sed cras ornare arcu</li>\r\n<li>sed blandit libero volutpat sed cras ornare arcu sed blandit libero volutpat sed cras ornare arcu</li>\r\n<li>sed blandit libero volutpat sed cras ornare arcu</li>\r\n<li>sed blandit libero volutpat sed cras ornare arcu</li>\r\n</ul>\r\n</div>\r\n<div class=\"col-12 s-py-25\" style=\"text-align: justify;\">\r\n<h3>INTERNET FOR ALL INITIATIVE</h3>\r\nsed blandit libero volutpat sed cras ornare arcu dui vivamus arcu felis bibendum ut tristique et egestas quis ipsum suspendisse ultrices gravida dictum fusce ut placerat orci nulla pellentesque dignissim enim sit amet venenatis urna cursus eget nunc scelerisque viverra mauris in aliquam sem fringilla ut morbi tincidunt augue interdum velit euismod in pellentesque massa placerat duis ultricies lacus sed turpis tincidunt id aliquet risus feugiat in ante metus dictum at tempor commodo ullamcorper a lacus vestibulum sed arcu non odio euismod lacinia at quis risus sed vulputate odio ut enim blandit volutpat maecenas volutpat blandit aliquam etiam erat velit.</div>', '<p>none</p>', 'contents/dummy-400.jpg', 'Seo Content Title for About Smile Broadband - Internet for All', 'Meta Description  for About Smile Broadband - Internet for All', 'Meta Keyword  for About Smile Broadband - Internet for All', 'Og Title  for About Smile Broadband - Internet for All', 'Og Description  for About Smile Broadband - Internet for All', 'contents/dummy-400.jpg', 1, 1, NULL, '2021-10-27 04:46:55', '2021-10-27 04:46:55'),
(7, 'Terms of Uses', 'terms-of-uses', NULL, NULL, '<h4>Terms of Finance</h4>\r\n<p>SMILE Broadband- a service brand of BDCOM Online Ltd., is now a common name among the home broadband users of Bangladesh as the Brand has now emerged as the top broadband internet service provider in the country. With super fast speed, 24/7 customer support, countrywide network and the best value for money broadband internet package plans, Smile topped the wish list of internet users in Bangladesh.</p>\r\n<p>Satisfied customers paved the way to become the brand smile is today and this is the motivating reason for everyone in the team to pursue the goal of satisfying the users above all. To satisfy the ever increasing demand of the internet users in Bangladesh, smile has designed its internet package plans to provide more bandwidth speed at less price.</p>\r\n<h4>Terms of Finance</h4>\r\n<p>SMILE Broadband- a service brand of BDCOM Online Ltd., is now a common name among the home broadband users of Bangladesh as the Brand has now emerged as the top broadband internet service provider in the country. With super fast speed, 24/7 customer support, countrywide network and the best value for money broadband internet package plans, Smile topped the wish list of internet users in Bangladesh.</p>\r\n<h4>Terms of Finance</h4>\r\n<p class=\"mb-0\">SMILE Broadband- a service brand of BDCOM Online Ltd., is now a common name among the home broadband users of Bangladesh as the Brand has now emerged as the top broadband internet service provider in the country. With super fast speed, 24/7 customer support, countrywide network and the best value for money broadband internet package plans, Smile topped the wish list of internet users in Bangladesh.</p>\r\n<ul>\r\n<li>Broadband service brand of BDCOM Online.</li>\r\n<li>Service brand of BDCOM Online.</li>\r\n</ul>\r\n<p>Satisfied customers paved the way to become the brand smile is today and this is the motivating reason for everyone in the team to pursue the goal of satisfying the users above all. To satisfy the ever increasing demand of the internet users in Bangladesh, smile has designed its internet package plans to provide more bandwidth speed at less price.</p>\r\n<p>So don&rsquo;t get confused between the peak and off-peak riddle, have a look at our most affordable broadband internet packages and choose what suits best to your requirements. To get the broadband connectivity.</p>', 'contents/terms-2.png', NULL, NULL, NULL, NULL, NULL, NULL, 1, 4, NULL, '2022-11-10 03:33:06', '2022-11-10 03:33:06'),
(8, 'Privacy Policy', 'privacy-policy', NULL, NULL, '<h4>Violance of Privacy</h4>\r\n<p>SMILE Broadband- a service brand of BDCOM Online Ltd., is now a common name among the home broadband users of Bangladesh as the Brand has now emerged as the top broadband internet service provider in the country. With super fast speed, 24/7 customer support, countrywide network and the best value for money broadband internet package plans, Smile topped the wish list of internet users in Bangladesh.</p>\r\n<p>Satisfied customers paved the way to become the brand smile is today and this is the motivating reason for everyone in the team to pursue the goal of satisfying the users above all. To satisfy the ever increasing demand of the internet users in Bangladesh, smile has designed its internet package plans to provide more bandwidth speed at less price.</p>\r\n<h4>Violance of Finance</h4>\r\n<p>SMILE Broadband- a service brand of BDCOM Online Ltd., is now a common name among the home broadband users of Bangladesh as the Brand has now emerged as the top broadband internet service provider in the country. With super fast speed, 24/7 customer support, countrywide network and the best value for money broadband internet package plans, Smile topped the wish list of internet users in Bangladesh.</p>\r\n<h4>Violance of Finance</h4>\r\n<p class=\"mb-0\">SMILE Broadband- a service brand of BDCOM Online Ltd., is now a common name among the home broadband users of Bangladesh as the Brand has now emerged as the top broadband internet service provider in the country. With super fast speed, 24/7 customer support, countrywide network and the best value for money broadband internet package plans, Smile topped the wish list of internet users in Bangladesh.</p>\r\n<ul>\r\n<li>Broadband service brand of BDCOM Online.</li>\r\n<li>Service brand of BDCOM Online.</li>\r\n</ul>\r\n<p>Satisfied customers paved the way to become the brand smile is today and this is the motivating reason for everyone in the team to pursue the goal of satisfying the users above all. To satisfy the ever increasing demand of the internet users in Bangladesh, smile has designed its internet package plans to provide more bandwidth speed at less price.</p>\r\n<p>So don&rsquo;t get confused between the peak and off-peak riddle, have a look at our most affordable broadband internet packages and choose what suits best to your requirements. To get the broadband connectivity.</p>', 'contents/terms.png', NULL, NULL, NULL, NULL, NULL, NULL, 1, 4, 4, '2022-11-10 04:06:30', '2022-11-10 04:15:49'),
(9, 'Bill Payment Guide', 'bill-payment-guide', NULL, NULL, '<h4>Bill Payment Guide Text</h4>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'contents/terms-2.png', NULL, NULL, NULL, NULL, NULL, NULL, 1, 4, NULL, '2022-11-10 04:32:36', '2022-11-10 04:32:36'),
(10, 'Media Center', 'media-center', NULL, NULL, '<h4>Media Center Text</h4>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'contents/terms-2.png', NULL, NULL, NULL, NULL, NULL, NULL, 1, 4, NULL, '2022-11-10 05:09:13', '2022-11-10 05:09:13'),
(11, 'Our Mission', 'our-mission', NULL, NULL, '<h3>Our Mission</h3>\r\n<p>To bring out 64 districts, 492 upazilas and 4554 unions under our broadband network coverage and deliver most cost effective broadband solutions based on market demand.</p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 4, NULL, '2022-11-10 06:04:59', '2022-11-10 06:04:59'),
(12, 'Our Vision', 'our-vision', NULL, NULL, '<h3>Our Vision</h3>\r\n<p>To make the internet available and affordable to every household around the country.</p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 4, NULL, '2022-11-10 06:06:03', '2022-11-10 06:06:03'),
(13, 'About', 'about-story', NULL, NULL, '<h2>Our Story</h2>\r\n<p>Smile broadband is one of the pioneers of home broadband service in Bangladesh. In 2009, BDCOM Online Ltd. officially acquired the business of Smile and started to provide home broadband service under the brand. After the successful business acquisition of Smile, BDCOM Online Ltd. upgraded it&rsquo;s packages to meet the primary internet requirements of broadband internet users in Bangladesh, in the sense of price and bandwidth speed.</p>\r\n<p>&nbsp;</p>\r\n<p>Since its inception, Smile Broadband is focused to empower its Internet users with the freedom to access Infotainment content and to surf with no limitations. Within 2016, Smile broadband became the most recognized service brand of BDCOM Online Ltd. for it&rsquo;s cost effective single price model and exceptional customer service.</p>', 'contents/story.png', NULL, NULL, NULL, NULL, NULL, NULL, 1, 4, 4, '2022-11-10 06:11:22', '2022-11-12 22:14:45'),
(14, 'Brands who trusts us', 'brands-who-trusts-us', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 4, NULL, '2022-11-13 00:14:21', '2022-11-13 00:14:21'),
(15, 'Service & Support', 'service-and-support', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 5, NULL, '2022-11-12 18:21:46', '2022-11-12 18:21:46'),
(16, 'Frequently Ask Questions', 'frequently-ask-questions', 'Frequently Asked Questions', '<p>Our shared connections feel like dedicated ones because we deliver package-wise committed bandwidth to each and every users no matter how many users are active in the network.</p>', '<p>Our shared connections feel like dedicated ones because we deliver package-wise committed bandwidth to each and every users no matter how many users are active in the network.</p>', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 5, 5, '2022-11-12 18:25:18', '2022-11-12 18:35:51');

-- --------------------------------------------------------

--
-- Table structure for table `content_faqs`
--

CREATE TABLE `content_faqs` (
  `id` int UNSIGNED NOT NULL,
  `content_id` int UNSIGNED NOT NULL,
  `parent_id` int DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int UNSIGNED NOT NULL,
  `status` int NOT NULL DEFAULT '0',
  `created_by` int NOT NULL,
  `last_updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `content_faqs`
--

INSERT INTO `content_faqs` (`id`, `content_id`, `parent_id`, `title`, `description`, `order`, `status`, `created_by`, `last_updated_by`, `created_at`, `updated_at`) VALUES
(1, 3, NULL, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt?', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 2, 1, 1, 1, '2021-09-05 02:04:59', '2021-09-05 03:36:04'),
(2, 3, NULL, 'id aliquet lectus proin nibh nisl condimentum id venenatis a condimentum vitae', '<p>id leo in vitae turpis massa sed elementum tempus egestas sed sed risus pretium quam vulputate dignissim suspendisse in est ante in nibh mauris cursus mattis molestie a iaculis at erat pellentesque adipiscing commodo elit</p>', 1, 1, 1, 1, '2021-09-05 02:05:34', '2021-09-05 03:36:04'),
(3, 3, NULL, 'egestas tellus rutrum tellus pellentesque eu tincidunt tortor', '<p>tincidunt nunc pulvinar sapien et ligula ullamcorper malesuada proin libero nunc consequat interdum varius sit amet mattis vulputate enim nulla aliquet porttitor lacus luctus accumsan tortor posuere ac ut consequat</p>', 3, 1, 1, 1, '2021-09-05 02:06:00', '2021-09-05 02:47:53'),
(4, 3, NULL, 'eget dolor morbi non arcu risus quis varius quam quisque?', '<p>interdum velit euismod in pellentesque massa placerat duis ultricies lacus sed turpis tincidunt id aliquet risus feugiat in ante metus dictum at tempor commodo ullamcorper</p>', 4, 1, 1, 1, '2021-09-05 02:06:32', '2021-09-05 02:48:45'),
(5, 4, NULL, 'I am not getting the package mentioned bandwidth speed.', '<p>id leo in vitae turpis massa sed elementum tempus egestas sed sed risus pretium quam vulputate dignissim suspendisse in est ante in nibh mauris cursus mattis molestie a iaculis at erat pellentesque adipiscing commodo elit</p>', 2, 1, 1, 3, '2021-09-07 04:04:02', '2021-10-27 02:14:26'),
(6, 4, NULL, 'My internet connection is not working.', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 1, 1, 1, 3, '2021-09-07 04:04:37', '2021-10-27 02:14:12'),
(7, 4, NULL, 'I forgot my user id or billing id.', '<p>tincidunt nunc pulvinar sapien et ligula ullamcorper malesuada proin libero nunc consequat interdum varius sit amet mattis vulputate enim nulla aliquet porttitor lacus luctus accumsan tortor posuere ac ut consequat</p>', 5, 1, 1, 3, '2021-09-07 04:05:26', '2021-10-27 02:14:39'),
(8, 4, NULL, 'I already paid the bill but the connection is not working.', '<p><strong style=\"margin: 0px; padding: 0px; color: #000000; font-family: \'Open Sans\', Arial, sans-serif; text-align: justify;\">Lorem Ipsum</strong><span style=\"color: #000000; font-family: \'Open Sans\', Arial, sans-serif; text-align: justify;\">&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</span></p>', 6, 0, 3, NULL, '2021-10-27 02:15:18', '2021-10-27 02:15:18'),
(9, 4, NULL, 'My internet speed fluctuates from time to time.', '<p><span style=\"color: #000000; font-family: \'Open Sans\', Arial, sans-serif; text-align: justify;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p>', 7, 0, 3, NULL, '2021-10-27 02:16:05', '2021-10-27 02:16:05'),
(10, 4, NULL, 'I am facing a high ping issue.', '<p><span style=\"color: #000000; font-family: \'Open Sans\', Arial, sans-serif; text-align: justify;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p>', 8, 0, 3, NULL, '2021-10-27 02:16:27', '2021-10-27 02:16:27'),
(11, 4, NULL, 'I am getting huge buffering while watching videos.', '<p><span style=\"color: #000000; font-family: \'Open Sans\', Arial, sans-serif; text-align: justify;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p>', 9, 0, 3, NULL, '2021-10-27 02:16:53', '2021-10-27 02:16:53'),
(12, 1, NULL, 'lofewradsfdshf', '<p>dsaf askdjflag;dhgaljlaHFDGKJnzkfJS JHSDD</p>', 10, 0, 3, 4, '2021-10-27 02:22:35', '2022-11-10 01:56:16'),
(13, 1, NULL, 'Does Smile Broadband have FTP servers?', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 11, 1, 4, NULL, '2022-11-10 01:38:31', '2022-11-10 01:38:31'),
(14, 1, NULL, 'What Are The Bill Payment Options?', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 12, 1, 4, NULL, '2022-11-10 01:54:22', '2022-11-10 01:54:22'),
(15, 1, NULL, 'Is there any installation charge for new connectivity?', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 13, 1, 4, NULL, '2022-11-10 01:55:21', '2022-11-10 01:55:21'),
(16, 1, NULL, 'Is there any Data Cap or Fair Usage Policy (FUP)?', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 14, 1, 4, NULL, '2022-11-10 01:56:08', '2022-11-10 01:56:08'),
(18, 9, NULL, 'Test Question', '<p>Description test</p>', 1, 1, 5, 5, '2022-11-12 20:00:27', '2022-11-12 20:00:56');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'customers/happy_customer.png',
  `district_id` int UNSIGNED NOT NULL,
  `customer_from` date NOT NULL,
  `status` int UNSIGNED NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `full_name`, `photo`, `district_id`, `customer_from`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Customer 1', 'Customer Name', 'customers/November2022/Xi0vFVn4lW1XcBwPvvjE.png', 1, '2022-11-01', 1, '2022-11-09 01:10:32', '2022-11-09 01:10:32', NULL),
(2, 'Customer 2', 'Customer Name 2', 'customers/November2022/EF5Trjw4xlYTHZjiPK2C.png', 2, '2022-11-01', 1, '2022-11-09 02:19:38', '2022-11-09 02:19:38', NULL),
(3, 'Customer 3', 'Customer Name 3', 'customers/November2022/kEV3mbvT1L5BPYkon884.png', 3, '2022-11-01', 1, '2022-11-13 22:43:27', '2022-11-13 22:43:27', NULL),
(4, 'Customer 4', 'Customer Name 4', 'customers/November2022/BE8Kb21oh12486svCs0M.png', 1, '2022-11-17', 1, '2022-11-16 04:46:14', '2022-11-16 04:46:14', NULL),
(12, 'Customer 5', 'Customer Name 5', 'customers/November2022/ogShq5FECPu3MR1Mp1aE.png', 5, '2022-11-27', 1, '2022-11-28 00:31:17', '2022-11-28 03:39:52', NULL),
(13, 'Customer 6', 'Customer Name 6', NULL, 4, '2022-11-27', 1, '2022-11-28 00:45:20', '2022-11-28 00:45:20', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customer_reviews`
--

CREATE TABLE `customer_reviews` (
  `id` int UNSIGNED NOT NULL,
  `customer_id` int UNSIGNED NOT NULL,
  `review_date` timestamp NOT NULL,
  `description` varchar(125) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ratings` int NOT NULL,
  `status` int UNSIGNED NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `show_at_home` tinyint UNSIGNED NOT NULL DEFAULT '0',
  `order` int UNSIGNED DEFAULT NULL,
  `description_more` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customer_reviews`
--

INSERT INTO `customer_reviews` (`id`, `customer_id`, `review_date`, `description`, `ratings`, `status`, `created_at`, `updated_at`, `show_at_home`, `order`, `description_more`) VALUES
(2, 2, '2022-11-22 04:55:00', ' 1 Average service...', 3, 1, '2022-11-21 22:55:55', '2022-11-21 22:55:55', 1, NULL, 'Let\'s Play with SMILE Broadband Internet Engie join forces to convert the GOS, Orange\'s maiLet\'s Play with SMILE Broadbend internet'),
(3, 3, '2022-11-22 04:56:00', '2 Good Service', 4, 1, '2022-11-21 22:57:04', '2022-11-21 22:57:04', 1, NULL, 'Let\'s Play with SMILE Broadband Internet Engie join forces to convert the GOS, Orange\'s maiLet\'s Play with SMILE Broadbend internet'),
(4, 4, '2022-11-22 04:57:00', '3 Great service', 5, 1, '2022-11-21 22:57:30', '2022-11-21 22:57:30', 1, NULL, 'Let\'s Play with SMILE Broadband Internet Engie join forces to convert the GOS, Orange\'s maiLet\'s Play with SMILE Broadbend internet'),
(5, 3, '2022-11-22 04:59:00', '4 Great service', 4, 1, '2022-11-21 23:03:10', '2022-11-21 23:03:10', 1, NULL, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, Lorem Ipsum is simply dummy text of the'),
(6, 2, '2022-10-30 05:03:00', '5 Average service...', 3, 1, '2022-11-21 23:03:38', '2022-11-21 23:03:38', 1, NULL, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, Lorem Ipsum is simply dummy text of the'),
(7, 3, '2022-11-13 05:03:00', 'Great service', 4, 1, '2022-11-21 23:04:04', '2022-11-21 23:04:04', 0, NULL, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, Lorem Ipsum is simply dummy text of the'),
(8, 2, '2022-11-13 05:04:00', 'Great service', 5, 1, '2022-11-21 23:04:24', '2022-11-21 23:04:24', 0, NULL, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, Lorem Ipsum is simply dummy text of the'),
(9, 4, '2022-11-20 05:04:00', 'Average service...', 3, 1, '2022-11-21 23:04:57', '2022-11-21 23:04:57', 0, NULL, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, Lorem Ipsum is simply dummy text of the'),
(10, 12, '2022-11-28 06:33:00', 'Great service', 5, 1, '2022-11-28 00:33:33', '2022-11-28 00:33:33', 1, NULL, 'scldgdgey fkryukeyd hkdyysyd hdjtjs');

-- --------------------------------------------------------

--
-- Table structure for table `data_rows`
--

CREATE TABLE `data_rows` (
  `id` int UNSIGNED NOT NULL,
  `data_type_id` int UNSIGNED NOT NULL,
  `field` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `browse` tinyint(1) NOT NULL DEFAULT '1',
  `read` tinyint(1) NOT NULL DEFAULT '1',
  `edit` tinyint(1) NOT NULL DEFAULT '1',
  `add` tinyint(1) NOT NULL DEFAULT '1',
  `delete` tinyint(1) NOT NULL DEFAULT '1',
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `order` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_rows`
--

INSERT INTO `data_rows` (`id`, `data_type_id`, `field`, `type`, `display_name`, `required`, `browse`, `read`, `edit`, `add`, `delete`, `details`, `order`) VALUES
(1, 1, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, '{}', 1),
(2, 1, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, '{}', 2),
(3, 1, 'email', 'text', 'Email', 1, 1, 1, 1, 1, 1, '{}', 3),
(4, 1, 'password', 'password', 'Password', 1, 0, 0, 1, 1, 0, '{}', 4),
(5, 1, 'remember_token', 'text', 'Remember Token', 0, 0, 0, 0, 0, 0, '{}', 5),
(6, 1, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 0, 0, 0, '{}', 6),
(7, 1, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 7),
(8, 1, 'avatar', 'image', 'Avatar', 0, 1, 1, 1, 1, 1, '{}', 8),
(9, 1, 'user_belongsto_role_relationship', 'relationship', 'Role', 0, 1, 1, 1, 1, 0, '{\"model\":\"TCG\\\\Voyager\\\\Models\\\\Role\",\"table\":\"roles\",\"type\":\"belongsTo\",\"column\":\"role_id\",\"key\":\"id\",\"label\":\"display_name\",\"pivot_table\":\"roles\",\"pivot\":\"0\",\"taggable\":\"0\"}', 10),
(10, 1, 'user_belongstomany_role_relationship', 'relationship', 'Roles', 0, 1, 1, 1, 1, 0, '{\"model\":\"TCG\\\\Voyager\\\\Models\\\\Role\",\"table\":\"roles\",\"type\":\"belongsToMany\",\"column\":\"id\",\"key\":\"id\",\"label\":\"display_name\",\"pivot_table\":\"user_roles\",\"pivot\":\"1\",\"taggable\":\"0\"}', 11),
(11, 1, 'settings', 'hidden', 'Settings', 0, 0, 0, 0, 0, 0, '{}', 12),
(12, 2, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(13, 2, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, NULL, 2),
(14, 2, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, NULL, 3),
(15, 2, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL, 4),
(16, 3, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(17, 3, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, NULL, 2),
(18, 3, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, NULL, 3),
(19, 3, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL, 4),
(20, 3, 'display_name', 'text', 'Display Name', 1, 1, 1, 1, 1, 1, NULL, 5),
(21, 1, 'role_id', 'text', 'Role', 0, 1, 1, 1, 1, 1, '{}', 9),
(22, 4, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, '{}', 1),
(23, 4, 'parent_id', 'select_dropdown', 'Parent', 0, 0, 1, 1, 1, 1, '{\"default\":\"\",\"null\":\"\",\"options\":{\"\":\"-- None --\"},\"relationship\":{\"key\":\"id\",\"label\":\"name\"}}', 2),
(24, 4, 'order', 'text', 'Order', 1, 1, 1, 1, 1, 1, '{\"default\":1}', 3),
(25, 4, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"max:255\"]}}', 4),
(26, 4, 'slug', 'text', 'Slug', 1, 1, 1, 1, 1, 1, '{\"slugify\":{\"origin\":\"name\"},\"validation\":{\"rule\":[\"max:255\"]}}', 5),
(27, 4, 'created_at', 'timestamp', 'Created At', 0, 0, 1, 0, 0, 0, '{}', 6),
(28, 4, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 7),
(29, 5, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, '{}', 1),
(30, 5, 'author_id', 'text', 'Author', 1, 0, 1, 1, 0, 1, '{}', 2),
(31, 5, 'category_id', 'text', 'Category', 0, 0, 1, 1, 1, 0, '{}', 3),
(32, 5, 'title', 'text', 'Title', 1, 1, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 4),
(33, 5, 'excerpt', 'text_area', 'Excerpt', 0, 0, 1, 1, 1, 1, '{}', 5),
(34, 5, 'body', 'rich_text_box', 'Body', 1, 0, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"required\"]}}', 6),
(35, 5, 'image', 'image', 'Post Image', 0, 1, 1, 1, 1, 1, '{\"resize\":{\"width\":\"1000\",\"height\":\"null\"},\"quality\":\"100%\",\"upsize\":true,\"thumbnails\":[{\"name\":\"medium\",\"scale\":\"50%\"},{\"name\":\"small\",\"scale\":\"25%\"},{\"name\":\"cropped\",\"crop\":{\"width\":\"300\",\"height\":\"250\"}}]}', 7),
(36, 5, 'slug', 'text', 'Slug', 1, 0, 1, 1, 1, 1, '{\"slugify\":{\"origin\":\"title\",\"forceUpdate\":true},\"validation\":{\"rule\":\"required|max:255|unique:posts,slug\"}}', 8),
(37, 5, 'meta_description', 'text_area', 'Meta Description', 0, 0, 1, 1, 1, 1, '{}', 9),
(38, 5, 'meta_keywords', 'text_area', 'Meta Keywords', 0, 0, 1, 1, 1, 1, '{}', 10),
(39, 5, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"default\":\"DRAFT\",\"options\":{\"PUBLISHED\":\"published\",\"DRAFT\":\"draft\",\"PENDING\":\"pending\"}}', 11),
(40, 5, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 0, 0, 0, '{}', 12),
(41, 5, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 16),
(42, 5, 'seo_title', 'text', 'SEO Title', 0, 1, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"max:255\"]}}', 17),
(43, 5, 'featured', 'checkbox', 'Featured', 1, 1, 1, 1, 1, 1, '{}', 18),
(44, 6, 'id', 'number', 'ID', 1, 0, 0, 0, 0, 0, NULL, 1),
(45, 6, 'author_id', 'text', 'Author', 1, 0, 0, 0, 0, 0, NULL, 2),
(46, 6, 'title', 'text', 'Title', 1, 1, 1, 1, 1, 1, NULL, 3),
(47, 6, 'excerpt', 'text_area', 'Excerpt', 1, 0, 1, 1, 1, 1, NULL, 4),
(48, 6, 'body', 'rich_text_box', 'Body', 1, 0, 1, 1, 1, 1, NULL, 5),
(49, 6, 'slug', 'text', 'Slug', 1, 0, 1, 1, 1, 1, '{\"slugify\":{\"origin\":\"title\"},\"validation\":{\"rule\":\"unique:pages,slug\"}}', 6),
(50, 6, 'meta_description', 'text', 'Meta Description', 1, 0, 1, 1, 1, 1, NULL, 7),
(51, 6, 'meta_keywords', 'text', 'Meta Keywords', 1, 0, 1, 1, 1, 1, NULL, 8),
(52, 6, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"default\":\"INACTIVE\",\"options\":{\"INACTIVE\":\"INACTIVE\",\"ACTIVE\":\"ACTIVE\"}}', 9),
(53, 6, 'created_at', 'timestamp', 'Created At', 1, 1, 1, 0, 0, 0, NULL, 10),
(54, 6, 'updated_at', 'timestamp', 'Updated At', 1, 0, 0, 0, 0, 0, NULL, 11),
(55, 6, 'image', 'image', 'Page Image', 0, 1, 1, 1, 1, 1, NULL, 12),
(56, 7, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(57, 7, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 2),
(58, 7, 'order', 'text', 'Order', 1, 0, 0, 0, 0, 0, '{}', 3),
(59, 7, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"default\":\"0\",\"options\":{\"0\":\"Inactive\",\"1\":\"active\"}}', 4),
(60, 7, 'created_by', 'text', 'Created By', 1, 0, 0, 0, 0, 0, '{}', 5),
(61, 7, 'last_updated_by', 'text', 'Last Updated By', 0, 0, 0, 0, 0, 0, '{}', 6),
(62, 7, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 0, 0, 0, '{}', 7),
(63, 7, 'updated_at', 'timestamp', 'Updated At', 0, 1, 1, 0, 0, 0, '{}', 8),
(64, 7, 'district_belongsto_user_relationship', 'relationship', 'Created by', 0, 1, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"created_by\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 9),
(65, 7, 'district_hasone_user_relationship', 'relationship', 'Updated by', 0, 1, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"hasOne\",\"column\":\"id\",\"key\":\"last_updated_by\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 10),
(82, 9, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(83, 9, 'title', 'text', 'Title', 1, 1, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 2),
(84, 9, 'district_id', 'text', 'District Id', 1, 1, 1, 1, 1, 1, '{}', 3),
(85, 9, 'address', 'rich_text_box', 'Address', 1, 1, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"required\"]}}', 5),
(86, 9, 'order', 'text', 'Order', 1, 1, 1, 0, 0, 0, '{}', 6),
(87, 9, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"default\":\"0\",\"options\":{\"0\":\"Inactive\",\"1\":\"Active\"}}', 7),
(88, 9, 'created_by', 'text', 'Created By', 1, 1, 1, 0, 0, 0, '{}', 8),
(89, 9, 'last_updated_by', 'text', 'Last Updated By', 0, 0, 1, 0, 0, 0, '{}', 10),
(90, 9, 'created_at', 'timestamp', 'Created At', 0, 0, 1, 0, 0, 0, '{}', 12),
(91, 9, 'updated_at', 'timestamp', 'Updated At', 0, 0, 1, 0, 0, 0, '{}', 13),
(92, 9, 'zone_office_belongsto_district_relationship', 'relationship', 'District', 0, 1, 1, 1, 1, 1, '{\"model\":\"App\\\\Models\\\\District\",\"table\":\"districts\",\"type\":\"belongsTo\",\"column\":\"district_id\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 4),
(93, 9, 'zone_office_belongsto_user_relationship', 'relationship', 'Created By', 0, 1, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"created_by\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 9),
(94, 9, 'zone_office_belongsto_user_relationship_1', 'relationship', 'Updated By', 0, 0, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"last_updated_by\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 11),
(95, 10, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(96, 10, 'title', 'text', 'Title', 1, 1, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 2),
(97, 10, 'description', 'text_area', 'Description', 0, 0, 1, 1, 1, 1, '{}', 3),
(98, 10, 'order', 'text', 'Order', 1, 1, 0, 0, 0, 0, '{}', 4),
(99, 10, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"default\":\"0\",\"options\":{\"0\":\"Inactive\",\"1\":\"Active\"}}', 5),
(100, 10, 'created_by', 'text', 'Created By', 1, 0, 0, 0, 0, 0, '{}', 6),
(101, 10, 'last_updated_by', 'text', 'Last Updated By', 0, 0, 0, 0, 0, 0, '{}', 8),
(102, 10, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 0, 0, 0, '{}', 10),
(103, 10, 'updated_at', 'timestamp', 'Updated At', 0, 0, 1, 0, 0, 0, '{}', 11),
(104, 10, 'network_coverage_belongsto_user_relationship', 'relationship', 'Created By', 0, 1, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"created_by\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 7),
(105, 10, 'network_coverage_belongsto_user_relationship_1', 'relationship', 'Updated By', 0, 1, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"last_updated_by\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 9),
(106, 11, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(107, 11, 'title', 'text', 'Title', 1, 1, 1, 1, 1, 1, '{}', 4),
(108, 11, 'description', 'text_area', 'Description', 0, 0, 1, 1, 1, 1, '{}', 5),
(109, 11, 'order', 'text', 'Order', 1, 1, 0, 0, 0, 0, '{}', 6),
(110, 11, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"default\":\"0\",\"options\":{\"0\":\"Inactive\",\"1\":\"Active\"}}', 7),
(111, 11, 'created_by', 'text', 'Created By', 1, 0, 0, 0, 0, 0, '{}', 8),
(112, 11, 'last_updated_by', 'text', 'Last Updated By', 0, 0, 0, 0, 0, 0, '{}', 10),
(113, 11, 'created_at', 'timestamp', 'Created At', 0, 0, 1, 0, 0, 0, '{}', 12),
(114, 11, 'updated_at', 'timestamp', 'Updated At', 0, 0, 1, 0, 0, 0, '{}', 13),
(115, 11, 'internet_coverage_belongsto_user_relationship', 'relationship', 'Created By', 0, 1, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"created_by\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 9),
(116, 11, 'internet_coverage_belongsto_user_relationship_1', 'relationship', 'Updated By', 0, 0, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"last_updated_by\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 11),
(117, 12, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(118, 12, 'title', 'text', 'Title', 1, 1, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 2),
(119, 12, 'description', 'text_area', 'Description', 1, 0, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"required\"]}}', 3),
(120, 12, 'logo', 'image', 'Logo', 1, 1, 1, 1, 1, 1, '{\"resize\":{\"width\":\"100\",\"height\":\"100\"},\"quality\":\"100%\",\"upsize\":true,\"description\":\"Size: 100px x 100px\"}', 4),
(121, 12, 'order', 'text', 'Order', 1, 1, 0, 0, 0, 0, '{}', 5),
(122, 12, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"default\":\"0\",\"options\":{\"0\":\"Inactive\",\"1\":\"Active\"}}', 6),
(123, 12, 'created_by', 'text', 'Created By', 1, 0, 0, 0, 0, 0, '{}', 7),
(124, 12, 'last_updated_by', 'text', 'Last Updated By', 0, 0, 0, 0, 0, 0, '{}', 9),
(125, 12, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 0, 0, 0, '{}', 11),
(126, 12, 'updated_at', 'timestamp', 'Updated At', 0, 0, 1, 0, 0, 0, '{}', 12),
(127, 12, 'service_value_belongsto_user_relationship', 'relationship', 'Created By', 0, 1, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"created_by\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 8),
(128, 12, 'service_value_belongsto_user_relationship_1', 'relationship', 'Updated By', 0, 0, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"last_updated_by\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 10),
(129, 13, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(130, 13, 'title', 'text', 'Title', 1, 1, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 2),
(131, 13, 'order', 'text', 'Order', 1, 1, 0, 0, 0, 0, '{}', 3),
(132, 13, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"default\":\"0\",\"options\":{\"0\":\"Inactive\",\"1\":\"Active\"}}', 5),
(133, 13, 'created_by', 'text', 'Created By', 1, 0, 0, 0, 0, 0, '{}', 8),
(134, 13, 'last_updated_by', 'text', 'Last Updated By', 0, 0, 0, 0, 0, 0, '{}', 10),
(135, 13, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 0, 0, 0, '{}', 12),
(136, 13, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 13),
(137, 13, 'package_category_belongsto_user_relationship', 'relationship', 'Created By', 0, 1, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"created_by\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 9),
(138, 13, 'package_category_belongsto_user_relationship_1', 'relationship', 'Updated By', 0, 0, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"last_updated_by\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 11),
(139, 14, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(140, 14, 'package_category_id', 'text', 'Package Category Id', 1, 1, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"}}', 5),
(141, 14, 'title', 'text', 'Title', 1, 1, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"},\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 2),
(142, 14, 'logo', 'image', 'Image', 0, 0, 0, 0, 0, 0, '{\"resize\":{\"width\":\"400\",\"height\":\"400\"},\"quality\":\"100%\",\"upsize\":true,\"description\":\"Size: 400px x 400px\",\"display\":{\"width\":\"6\"}}', 10),
(143, 14, 'booking_link', 'text', 'Booking Link', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"},\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 7),
(144, 14, 'internet_speed', 'text', 'Internet Speed', 1, 1, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"},\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 11),
(145, 14, 'internet_description', 'text', 'Internet Description', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"},\"validation\":{\"rule\":[\"max:255\"]}}', 12),
(146, 14, 'bdix_speed', 'text', 'BDIX Speed', 1, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"},\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 13),
(147, 14, 'bdix_description', 'text', 'BDIX Description', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"},\"validation\":{\"rule\":[\"max:255\"]}}', 14),
(148, 14, 'monthly_charges', 'text', 'Monthly Charges', 1, 1, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"},\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 15),
(149, 14, 'vat_declaration', 'text', 'Vat Declaration', 1, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"},\"validation\":{\"rule\":[\"max:255\"]}}', 16),
(150, 14, 'features', 'rich_text_box', 'Features', 1, 0, 1, 1, 1, 1, '{\"tinymceOptions\":{\"height\":200,\"min_height\":200}}', 19),
(151, 14, 'description_title', 'text', 'Description Title', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"},\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 20),
(152, 14, 'description_excerpt', 'rich_text_box', 'Description Excerpt', 0, 0, 1, 1, 1, 1, '{\"tinymceOptions\":{\"height\":200,\"min_height\":200},\"display\":{\"width\":\"6\"},\"validation\":{\"rule\":[\"required\"]}}', 22),
(153, 14, 'description_more', 'rich_text_box', 'Description More', 0, 0, 1, 1, 1, 1, '{\"tinymceOptions\":{\"height\":200,\"min_height\":200},\"display\":{\"width\":\"6\"}}', 23),
(154, 14, 'description_image', 'image', 'Description Image', 0, 0, 1, 1, 1, 1, '{\"resize\":{\"width\":\"400\",\"height\":\"400\"},\"quality\":\"100%\",\"upsize\":true,\"description\":\"Size: 400px x 400px\",\"display\":{\"width\":\"6\"}}', 21),
(155, 14, 'slug', 'text', 'Slug', 1, 1, 1, 1, 1, 1, '{\"slugify\":{\"origin\":\"title\",\"forceUpdate\":true},\"validation\":{\"rule\":\"required|max:255|unique:packages,slug\"},\"display\":{\"width\":\"6\"}}', 3),
(156, 14, 'seo_titlle', 'text', 'Seo Titlle', 0, 0, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 24),
(157, 14, 'meta_description', 'text_area', 'Meta Description', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"}}', 25),
(158, 14, 'meta_keyword', 'text_area', 'Meta Keyword', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"}}', 26),
(159, 14, 'og_title', 'text', 'Og Title', 0, 0, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 27),
(160, 14, 'og_description', 'text_area', 'Og Description', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"}}', 28),
(161, 14, 'og_image', 'text', 'Og Image', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"}}', 29),
(162, 14, 'order', 'text', 'Order', 1, 1, 0, 0, 0, 0, '{}', 30),
(163, 14, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"default\":\"0\",\"options\":{\"0\":\"Inactive\",\"1\":\"Active\"}}', 31),
(164, 14, 'created_by', 'text', 'Created By', 1, 0, 0, 0, 0, 0, '{}', 32),
(165, 14, 'last_updated_by', 'text', 'Last Updated By', 0, 0, 0, 0, 0, 0, '{}', 34),
(166, 14, 'created_at', 'timestamp', 'Created At', 0, 0, 1, 0, 0, 0, '{}', 36),
(167, 14, 'updated_at', 'timestamp', 'Updated At', 0, 0, 1, 0, 0, 0, '{}', 37),
(174, 14, 'package_belongsto_user_relationship', 'relationship', 'Created By', 0, 0, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"created_by\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 33),
(175, 14, 'package_belongsto_user_relationship_1', 'relationship', 'Updated By', 0, 0, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"last_updated_by\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 35),
(176, 14, 'maxim_id', 'text', 'Maxim Id', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"},\"validation\":{\"rule\":[\"required\",\"integer\"]}}', 4),
(177, 14, 'package_belongsto_package_category_relationship', 'relationship', 'Category', 1, 1, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"},\"model\":\"App\\\\Models\\\\PackageCategory\",\"table\":\"package_categories\",\"type\":\"belongsTo\",\"column\":\"package_category_id\",\"key\":\"id\",\"label\":\"title\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 6),
(178, 11, 'district_id', 'text', 'District Id', 1, 1, 1, 1, 1, 1, '{}', 2),
(179, 11, 'internet_coverage_belongsto_district_relationship', 'relationship', 'District', 0, 1, 1, 1, 1, 1, '{\"model\":\"App\\\\Models\\\\District\",\"table\":\"districts\",\"type\":\"belongsTo\",\"column\":\"district_id\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 3),
(203, 16, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(204, 16, 'image_laptop', 'media_picker', 'Image Laptop', 0, 0, 1, 1, 1, 1, '{\"max\":1,\"min\":1,\"expanded\":false,\"show_folders\":true,\"show_toolbar\":true,\"allow_upload\":true,\"allow_move\":true,\"allow_delete\":true,\"allow_create_folder\":true,\"allow_rename\":true,\"allow_crop\":true,\"allowed\":[\"image\\/jpeg\",\"image\\/png\",\"image\\/bmp\"],\"hide_thumbnails\":false,\"quality\":\"100%\",\"base_path\":\"\\/slideshows\\/\"}', 3),
(205, 16, 'image_tab', 'media_picker', 'Image Tab (768 - 991)', 0, 0, 1, 1, 1, 1, '{\"max\":1,\"min\":1,\"expanded\":false,\"show_folders\":true,\"show_toolbar\":true,\"allow_upload\":true,\"allow_move\":true,\"allow_delete\":true,\"allow_create_folder\":true,\"allow_rename\":true,\"allow_crop\":true,\"allowed\":[\"image\\/jpeg\",\"image\\/png\",\"image\\/bmp\"],\"hide_thumbnails\":false,\"quality\":\"100%\",\"base_path\":\"\\/slideshows\\/\"}', 4),
(206, 16, 'image_mobile', 'media_picker', 'Image Mobile', 1, 1, 1, 1, 1, 1, '{\"max\":1,\"min\":1,\"expanded\":false,\"show_folders\":true,\"show_toolbar\":true,\"allow_upload\":true,\"allow_move\":true,\"allow_delete\":true,\"allow_create_folder\":true,\"allow_rename\":true,\"allow_crop\":true,\"allowed\":[\"image\\/jpeg\",\"image\\/png\",\"image\\/bmp\"],\"hide_thumbnails\":false,\"quality\":\"100%\",\"base_path\":\"\\/slideshows\\/\"}', 6),
(207, 16, 'show_infobox', 'checkbox', 'Show Infobox', 1, 1, 1, 1, 1, 1, '{\"0\":\"No\",\"1\":\"Yes\",\"checked\":true}', 7),
(208, 16, 'infobox_color', 'color', 'Infobox Color', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\",\"id\":\"infobox_color\"}}', 8),
(209, 16, 'infobox_opacity', 'number', 'Infobox Opacity', 0, 0, 1, 1, 1, 1, '{\"step\":0.05,\"min\":0,\"max\":1,\"default\":1,\"display\":{\"width\":\"6\",\"id\":\"infobox_opacity\"}}', 9),
(210, 16, 'title', 'rich_text_box', 'Title', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\",\"id\":\"slideshow_title\"},\"validation\":{\"rule\":[\"max:255\"]}}', 10),
(211, 16, 'title_color', 'color', 'Title Color', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\",\"id\":\"slideshow_title_color\"}}', 11),
(212, 16, 'subtitle', 'text', 'Subtitle', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\",\"id\":\"slideshow_subtitle\"},\"validation\":{\"rule\":[\"max:255\"]}}', 12),
(213, 16, 'subtitle_color', 'color', 'Subtitle Color', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\",\"id\":\"slideshow_subtitle_color\"}}', 13),
(214, 16, 'excerpt', 'text', 'Excerpt', 0, 0, 1, 1, 1, 1, '{}', 14),
(215, 16, 'has_link', 'checkbox', 'Has Link', 0, 0, 1, 1, 1, 1, '{\"0\":\"No\",\"1\":\"Yes\",\"checked\":true,\"display\":{\"width\":\"3\",\"id\":\"has_link\"}}', 15),
(216, 16, 'link', 'text', 'Link', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"9\",\"id\":\"slideshow_link\"},\"validation\":{\"rule\":[\"max:255\"]}}', 16),
(217, 16, 'button_label', 'text', 'Button Label', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"4\",\"id\":\"button_label\"},\"validation\":{\"rule\":[\"max:255\"]}}', 17),
(218, 16, 'button_color', 'color', 'Button Color', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"4\",\"id\":\"button_color\"}}', 18),
(219, 16, 'button_opacity', 'number', 'Button Opacity', 0, 0, 1, 1, 1, 1, '{\"step\":0.05,\"min\":0,\"max\":1,\"default\":1,\"display\":{\"width\":\"4\",\"id\":\"button_opacity\"}}', 19),
(220, 16, 'order', 'text', 'Order', 1, 0, 1, 0, 0, 0, '{}', 20),
(221, 16, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"default\":\"1\",\"options\":{\"0\":\"Inactive\",\"1\":\"Active\"}}', 21),
(222, 16, 'created_by', 'text', 'Created By', 1, 0, 1, 0, 0, 0, '{}', 22),
(223, 16, 'last_updated_by', 'text', 'Last Updated By', 0, 0, 1, 0, 0, 0, '{}', 24),
(224, 16, 'created_at', 'timestamp', 'Created At', 0, 0, 1, 0, 0, 0, '{}', 26),
(225, 16, 'updated_at', 'timestamp', 'Updated At', 0, 0, 1, 0, 0, 0, '{}', 27),
(226, 16, 'slideshow_belongsto_user_relationship', 'relationship', 'Created By', 0, 0, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"created_by\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 23),
(227, 16, 'slideshow_belongsto_user_relationship_1', 'relationship', 'Last Updated By', 0, 0, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"last_updated_by\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 25),
(228, 17, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(229, 17, 'title', 'text', 'Title', 1, 1, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 2),
(230, 17, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"default\":\"0\",\"options\":{\"0\":\"Inactive\",\"1\":\"Active\"}}', 4),
(231, 17, 'created_by', 'text', 'Created By', 1, 0, 0, 0, 0, 0, '{}', 5),
(232, 17, 'last_updated_by', 'text', 'Last Updated By', 0, 0, 0, 0, 0, 0, '{}', 6),
(233, 17, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, '{}', 7),
(234, 17, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 8),
(235, 17, 'order', 'text', 'Order', 1, 1, 0, 0, 0, 0, '{}', 9),
(236, 18, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(237, 18, 'req_name', 'text', 'Name', 1, 1, 1, 0, 0, 0, '{}', 2),
(238, 18, 'req_phone', 'text', 'Phone', 1, 1, 1, 0, 0, 0, '{}', 3),
(239, 18, 'req_email', 'text', 'Email', 1, 1, 1, 0, 0, 0, '{}', 4),
(240, 18, 'solution_requirement_type_id', 'text', 'Solution Requirement Type Id', 1, 1, 1, 0, 0, 0, '{}', 5),
(241, 18, 'req_details', 'text', 'Details', 0, 1, 1, 0, 0, 0, '{}', 7),
(242, 18, 'is_human_verified', 'text', 'Is Human Verified', 1, 0, 1, 0, 0, 0, '{}', 8),
(243, 18, 'human_verification_result', 'text', 'Human Verification Result', 0, 0, 1, 0, 0, 0, '{}', 9),
(244, 18, 'remote_addr', 'text', 'Remote Addr', 0, 0, 1, 0, 0, 0, '{}', 10),
(245, 18, 'remote_port', 'text', 'Remote Port', 0, 0, 1, 0, 0, 0, '{}', 11),
(246, 18, 'request_scheme', 'text', 'Request Scheme', 0, 0, 1, 0, 0, 0, '{}', 12),
(247, 18, 'request_method', 'text', 'Request Method', 0, 0, 1, 0, 0, 0, '{}', 13),
(248, 18, 'platform', 'text', 'Platform', 0, 0, 1, 0, 0, 0, '{}', 14),
(249, 18, 'browser', 'text', 'Browser', 0, 0, 1, 0, 0, 0, '{}', 15),
(250, 18, 'browser_maker', 'text', 'Browser Maker', 0, 0, 1, 0, 0, 0, '{}', 16),
(251, 18, 'browser_version', 'text', 'Browser Version', 0, 0, 1, 0, 0, 0, '{}', 17),
(252, 18, 'device_type', 'text', 'Device Type', 0, 0, 1, 0, 0, 0, '{}', 18),
(253, 18, 'device_pointing_method', 'text', 'Device Pointing Method', 0, 0, 1, 0, 0, 0, '{}', 19),
(254, 18, 'minorver', 'text', 'Minorver', 0, 0, 1, 0, 0, 0, '{}', 20),
(255, 18, 'ismobiledevice', 'text', 'Is mobile device?', 0, 0, 1, 0, 0, 0, '{}', 21),
(256, 18, 'istablet', 'text', 'Is tablet?', 0, 0, 1, 0, 0, 0, '{}', 22),
(257, 18, 'crawler', 'text', 'Crawler', 0, 0, 1, 0, 0, 0, '{}', 23),
(258, 18, 'http_user_agent', 'text', 'Http User Agent', 0, 0, 1, 0, 0, 0, '{}', 24),
(259, 18, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 0, 0, 0, '{}', 25),
(260, 18, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 26),
(261, 18, 'solution_request_belongsto_solution_requirement_type_relationship', 'relationship', 'Solution Type', 0, 1, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\SolutionRequirementType\",\"table\":\"solution_requirement_types\",\"type\":\"belongsTo\",\"column\":\"solution_requirement_type_id\",\"key\":\"id\",\"label\":\"title\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 6),
(262, 19, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(263, 19, 'title', 'text', 'Title', 1, 1, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"},\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 2),
(264, 19, 'slug', 'text', 'Slug', 1, 1, 1, 1, 1, 1, '{\"slugify\":{\"origin\":\"title\",\"forceUpdate\":true},\"validation\":{\"rule\":\"required|max:255|unique:contents,slug\"},\"display\":{\"width\":\"6\"}}', 3),
(265, 19, 'description_title', 'text', 'Description Title', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"},\"validation\":{\"rule\":[\"max:255\"]}}', 4),
(266, 19, 'description_excerpt', 'rich_text_box', 'Description Excerpt', 0, 0, 1, 1, 1, 1, '{\"tinymceOptions\":{\"height\":200,\"min_height\":200},\"display\":{\"width\":\"6\"}}', 5),
(267, 19, 'description_more', 'rich_text_box', 'Description More', 0, 0, 1, 1, 1, 1, '{\"tinymceOptions\":{\"height\":200,\"min_height\":200},\"display\":{\"width\":\"6\"}}', 6),
(268, 19, 'description_image', 'media_picker', 'Description Image', 0, 0, 1, 1, 1, 1, '{\"resize\":{\"width\":\"400\",\"height\":\"400\"},\"quality\":\"100%\",\"upsize\":true,\"description\":\"Size: 400px x 400px\",\"display\":{\"width\":\"6\"}}', 7),
(269, 19, 'seo_titlle', 'text', 'Seo Titlle', 0, 0, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"max:255\"]}}', 8),
(270, 19, 'meta_description', 'text', 'Meta Description', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"}}', 9),
(271, 19, 'meta_keyword', 'text', 'Meta Keyword', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"}}', 10),
(272, 19, 'og_title', 'text', 'Og Title', 0, 0, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"max:255\"]}}', 11),
(273, 19, 'og_description', 'text', 'Og Description', 0, 0, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"}}', 12),
(274, 19, 'og_image', 'media_picker', 'Og Image', 0, 0, 1, 1, 1, 1, '{\"resize\":{\"width\":\"400\",\"height\":\"400\"},\"quality\":\"100%\",\"upsize\":true,\"description\":\"Size: 400px x 400px\",\"display\":{\"width\":\"6\"}}', 13),
(275, 19, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"default\":\"0\",\"options\":{\"0\":\"Inactive\",\"1\":\"Active\"}}', 14),
(276, 19, 'created_by', 'text', 'Created By', 1, 0, 1, 0, 0, 0, '{}', 15),
(277, 19, 'last_updated_by', 'text', 'Last Updated By', 0, 0, 1, 0, 0, 0, '{}', 16),
(278, 19, 'created_at', 'timestamp', 'Created At', 0, 0, 1, 0, 0, 0, '{}', 17),
(279, 19, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 18),
(280, 16, 'image_tab_2', 'media_picker', 'Image Tab 2 (575 - 767)', 0, 0, 1, 1, 1, 1, '{\"max\":1,\"min\":1,\"expanded\":false,\"show_folders\":true,\"show_toolbar\":true,\"allow_upload\":true,\"allow_move\":true,\"allow_delete\":true,\"allow_create_folder\":true,\"allow_rename\":true,\"allow_crop\":true,\"allowed\":[\"image\\/jpeg\",\"image\\/png\",\"image\\/bmp\"],\"hide_thumbnails\":false,\"quality\":\"100%\",\"base_path\":\"\\/slideshows\\/\"}', 5),
(281, 17, 'concern_email', 'text', 'Concern Email', 0, 1, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"max:255\"]}}', 3),
(282, 20, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(283, 20, 'title', 'text', 'Title', 1, 1, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 2),
(284, 20, 'concern_email', 'text', 'Concern Email', 1, 1, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 3),
(285, 20, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"default\":\"1\",\"options\":{\"0\":\"Inactive\",\"1\":\"Active\"}}', 4),
(286, 20, 'created_by', 'text', 'Created By', 1, 0, 1, 0, 0, 0, '{}', 5),
(287, 20, 'last_updated_by', 'text', 'Last Updated By', 0, 0, 1, 0, 0, 0, '{}', 7),
(288, 20, 'created_at', 'timestamp', 'Created At', 0, 0, 1, 0, 0, 0, '{}', 9),
(289, 20, 'updated_at', 'timestamp', 'Updated At', 0, 0, 1, 0, 0, 0, '{}', 10),
(290, 20, 'problem_type_belongsto_user_relationship', 'relationship', 'Created By', 0, 0, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"created_by\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 6),
(291, 20, 'problem_type_belongsto_user_relationship_1', 'relationship', 'Last Updated By', 0, 0, 1, 0, 0, 0, '{\"model\":\"App\\\\Models\\\\User\",\"table\":\"users\",\"type\":\"belongsTo\",\"column\":\"last_updated_by\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 8),
(292, 5, 'og_title', 'text', 'Og Title', 0, 1, 1, 1, 1, 1, '{\"validation\":{\"rule\":[\"max:255\"]}}', 13),
(293, 5, 'og_description', 'text_area', 'Og Description', 0, 1, 1, 1, 1, 1, '{\"display\":{\"rows\":3}}', 14),
(294, 5, 'og_image', 'media_picker', 'Og Image', 0, 1, 1, 1, 1, 1, '{\"max\":1,\"min\":1,\"expanded\":false,\"show_folders\":true,\"show_toolbar\":true,\"allow_upload\":true,\"allow_move\":true,\"allow_delete\":true,\"allow_create_folder\":true,\"allow_rename\":true,\"allow_crop\":true,\"allowed\":[\"image\\/jpeg\",\"image\\/png\",\"image\\/bmp\"],\"hide_thumbnails\":false,\"quality\":\"100%\",\"base_path\":\"\\/posts\\/\"}', 15),
(295, 16, 'image_big', 'media_picker', 'Image Big', 1, 0, 1, 1, 1, 1, '{\"max\":1,\"min\":1,\"expanded\":false,\"show_folders\":true,\"show_toolbar\":true,\"allow_upload\":true,\"allow_move\":true,\"allow_delete\":true,\"allow_create_folder\":true,\"allow_rename\":true,\"allow_crop\":true,\"allowed\":[\"image\\/jpeg\",\"image\\/png\",\"image\\/bmp\"],\"hide_thumbnails\":false,\"quality\":\"100%\",\"base_path\":\"\\/slideshows\\/\"}', 2),
(296, 14, 'home_logo', 'image', 'Home Page Logo', 0, 0, 0, 0, 0, 0, '{\"resize\":{\"width\":\"400\",\"height\":\"400\"},\"quality\":\"100%\",\"upsize\":true,\"description\":\"Size: 400px x 400px\",\"display\":{\"width\":\"6\"}}', 9),
(297, 14, 'show_in_honepage', 'checkbox', 'Show In Honepage', 1, 1, 1, 1, 1, 1, '{\"0\":\"No\",\"1\":\"Yes\",\"checked\":false,\"display\":{\"width\":\"6\",\"id\":\"show-in-homepage\"}}', 8),
(298, 13, 'short_description', 'rich_text_box', 'Short Description', 1, 1, 1, 1, 1, 1, '{}', 6),
(299, 13, 'detailed_description', 'rich_text_box', 'Detailed Description', 1, 1, 1, 1, 1, 1, '{}', 7),
(300, 14, 'features_1', 'rich_text_box', 'Features 1', 0, 1, 1, 1, 1, 1, '{\"tinymceOptions\":{\"height\":200,\"min_height\":200}}', 17),
(301, 14, 'features_2', 'rich_text_box', 'Features 2', 0, 1, 1, 1, 1, 1, '{\"tinymceOptions\":{\"height\":200,\"min_height\":200}}', 18),
(302, 13, 'slug', 'text', 'Slug', 1, 1, 1, 1, 1, 1, '{}', 4),
(303, 21, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(304, 21, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"},\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 3),
(305, 21, 'full_name', 'text', 'Full Name', 0, 1, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"},\"validation\":{\"rule\":[\"required\",\"max:255\"]}}', 4),
(306, 21, 'photo', 'image', 'Profile Image', 0, 1, 1, 1, 1, 1, '{\"resize\":{\"width\":\"400\",\"height\":\"400\"},\"quality\":\"100%\",\"upsize\":true,\"description\":\"Size: 400px x 400px\"}', 2),
(307, 21, 'district_id', 'select_dropdown', 'District Id', 1, 1, 1, 1, 1, 1, '{\"display\":{\"width\":\"4\"}}', 5),
(308, 21, 'customer_from', 'date', 'Customer From', 1, 1, 1, 1, 1, 1, '{\"display\":{\"width\":\"4\"}}', 7),
(309, 21, 'status', 'select_dropdown', 'Status', 1, 1, 1, 1, 1, 1, '{\"display\":{\"width\":\"4\"},\"default\":\"0\",\"options\":{\"0\":\"Inactive\",\"1\":\"Active\"}}', 8),
(310, 21, 'created_at', 'timestamp', 'Created At', 0, 0, 1, 0, 0, 0, '{}', 9),
(311, 21, 'updated_at', 'timestamp', 'Updated At', 0, 0, 1, 0, 0, 0, '{}', 10),
(312, 21, 'deleted_at', 'timestamp', 'Deleted At', 0, 0, 1, 0, 0, 0, '{}', 11),
(313, 21, 'customer_hasone_district_relationship', 'relationship', 'district', 0, 1, 1, 1, 1, 1, '{\"display\":{\"width\":\"4\"},\"model\":\"App\\\\Models\\\\District\",\"table\":\"districts\",\"type\":\"belongsTo\",\"column\":\"district_id\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 6),
(314, 22, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(315, 22, 'customer_id', 'text', 'Customer Id', 1, 1, 1, 1, 1, 1, '{}', 2),
(316, 22, 'review_date', 'timestamp', 'Review Date', 1, 1, 1, 1, 1, 1, '{\"display\":{\"width\":\"4\"}}', 5),
(317, 22, 'description', 'text', 'Review excerpt', 1, 1, 1, 1, 1, 1, '{\"display\":{\"width\":\"6\"},\"validation\":{\"rule\":\"required|max:125\",\"messages\":{\"required\":\"This :attribute field is a must.\",\"max\":\"This :attribute field maximum :max.\"}}}', 6),
(318, 22, 'ratings', 'select_dropdown', 'Ratings', 1, 1, 1, 1, 1, 1, '{\"default\":\"5\",\"options\":{\"0\":\"0\",\"1\":\"1\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"5\"},\"display\":{\"width\":\"4\"}}', 4),
(319, 22, 'status', 'checkbox', 'Status', 1, 1, 1, 1, 1, 1, '{\"0\":\"No\",\"1\":\"Yes\",\"checked\":false,\"display\":{\"width\":\"3\",\"id\":\"status\"}}', 9),
(320, 22, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 0, 0, 1, '{}', 10),
(321, 22, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 11),
(322, 22, 'show_at_home', 'checkbox', 'Show in Home', 1, 1, 1, 1, 1, 1, '{\"0\":\"No\",\"1\":\"Yes\",\"checked\":false,\"display\":{\"width\":\"3\",\"id\":\"sohw-in-homepage\"}}', 8),
(323, 22, 'order', 'text', 'Order', 0, 0, 0, 0, 0, 0, '{}', 12),
(324, 22, 'customer_review_belongsto_customer_relationship', 'relationship', 'customers', 0, 1, 1, 1, 1, 1, '{\"display\":{\"width\":\"4\"},\"model\":\"App\\\\Models\\\\Customer\",\"table\":\"customers\",\"type\":\"belongsTo\",\"column\":\"customer_id\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 3),
(325, 13, 'show_in_homepage', 'checkbox', 'Show In Homepage', 1, 1, 1, 1, 1, 1, '{\"0\":\"No\",\"1\":\"Yes\",\"checked\":false,\"display\":{\"width\":\"6\",\"id\":\"sohw-in-homepage\"}}', 12),
(326, 23, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(327, 23, 'title', 'text', 'Title', 1, 1, 1, 1, 1, 1, '{}', 2),
(328, 23, 'url', 'text', 'Url', 1, 1, 1, 1, 1, 1, '{}', 3),
(329, 23, 'icon_class', 'text', 'Icon Class', 0, 1, 1, 1, 1, 1, '{}', 4),
(330, 23, 'created_at', 'timestamp', 'Created At', 0, 1, 0, 0, 0, 0, '{}', 5),
(331, 23, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 6),
(332, 23, 'order', 'text', 'Order', 1, 1, 0, 0, 0, 0, '{}', 7),
(333, 23, 'status', 'checkbox', 'Status', 1, 1, 1, 1, 1, 1, '{\"0\":\"Inactive\",\"1\":\"Active\",\"checked\":false,\"display\":{\"width\":\"6\",\"id\":\"status\"}}', 8),
(343, 27, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(345, 27, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, '{}', 3),
(346, 27, 'logo', 'image', 'Logo', 1, 1, 1, 1, 1, 1, '{}', 4),
(347, 27, 'url', 'text', 'Url', 0, 1, 1, 1, 1, 1, '{}', 5),
(348, 27, 'status', 'checkbox', 'Status', 1, 1, 1, 1, 1, 1, '{\"0\":\"Inactive\",\"1\":\"Active\",\"checked\":false,\"display\":{\"width\":\"6\",\"id\":\"status\"}}', 6),
(349, 27, 'order', 'text', 'Order', 0, 1, 0, 0, 0, 0, '{}', 7),
(350, 27, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, '{}', 8),
(351, 27, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 9),
(352, 29, 'id', 'text', 'Id', 1, 0, 0, 0, 0, 0, '{}', 1),
(353, 29, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, '{}', 2),
(354, 29, 'slug', 'text', 'Slug', 1, 1, 1, 1, 1, 1, '{}', 3),
(355, 29, 'description', 'text', 'Description', 0, 1, 1, 1, 1, 1, '{}', 4),
(356, 29, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 1, 0, 1, '{}', 5),
(357, 29, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, '{}', 6),
(358, 27, 'brand_belongsto_brand_category_relationship', 'relationship', 'brand_categories', 0, 1, 1, 1, 1, 1, '{\"model\":\"App\\\\Models\\\\BrandCategory\",\"table\":\"brand_categories\",\"type\":\"belongsTo\",\"column\":\"brand_category_id\",\"key\":\"id\",\"label\":\"name\",\"pivot_table\":\"brand_categories\",\"pivot\":\"0\",\"taggable\":\"0\"}', 10),
(359, 27, 'brand_category_id', 'text', 'Brand Category Id', 1, 1, 1, 1, 1, 1, '{}', 10),
(360, 9, 'contact_number', 'text', 'Contact Number', 0, 1, 1, 1, 1, 1, '{}', 11),
(361, 9, 'email', 'text', 'Email', 0, 1, 1, 1, 1, 1, '{}', 12),
(362, 22, 'description_more', 'text_area', 'Review Body', 1, 1, 1, 1, 1, 1, '{\"display\":{\"width\":\"8\"},\"validation\":{\"rule\":[\"required\",\"max:200\"]}}', 7),
(363, 1, 'email_verified_at', 'timestamp', 'Email Verified At', 0, 1, 1, 1, 1, 1, '{}', 6);

-- --------------------------------------------------------

--
-- Table structure for table `data_types`
--

CREATE TABLE `data_types` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_singular` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_plural` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `policy_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `controller` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `generate_permissions` tinyint(1) NOT NULL DEFAULT '0',
  `server_side` tinyint NOT NULL DEFAULT '0',
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_types`
--

INSERT INTO `data_types` (`id`, `name`, `slug`, `display_name_singular`, `display_name_plural`, `icon`, `model_name`, `policy_name`, `controller`, `description`, `generate_permissions`, `server_side`, `details`, `created_at`, `updated_at`) VALUES
(1, 'users', 'users', 'User', 'Users', 'voyager-person', 'TCG\\Voyager\\Models\\User', 'TCG\\Voyager\\Policies\\UserPolicy', 'TCG\\Voyager\\Http\\Controllers\\VoyagerUserController', NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"desc\",\"default_search_key\":null,\"scope\":null}', '2021-07-19 01:12:51', '2022-11-27 22:29:32'),
(2, 'menus', 'menus', 'Menu', 'Menus', 'voyager-list', 'TCG\\Voyager\\Models\\Menu', NULL, '', '', 1, 0, NULL, '2021-07-19 01:12:51', '2021-07-19 01:12:51'),
(3, 'roles', 'roles', 'Role', 'Roles', 'voyager-lock', 'TCG\\Voyager\\Models\\Role', NULL, 'TCG\\Voyager\\Http\\Controllers\\VoyagerRoleController', '', 1, 0, NULL, '2021-07-19 01:12:51', '2021-07-19 01:12:51'),
(4, 'categories', 'categories', 'Category', 'Categories', 'voyager-categories', 'TCG\\Voyager\\Models\\Category', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"desc\",\"default_search_key\":null,\"scope\":null}', '2021-07-19 01:13:00', '2021-09-14 06:05:11'),
(5, 'posts', 'posts', 'Post', 'Posts', 'voyager-news', 'TCG\\Voyager\\Models\\Post', 'TCG\\Voyager\\Policies\\PostPolicy', NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"desc\",\"default_search_key\":null,\"scope\":null}', '2021-07-19 01:13:02', '2021-09-14 06:31:56'),
(6, 'pages', 'pages', 'Page', 'Pages', 'voyager-file-text', 'TCG\\Voyager\\Models\\Page', NULL, '', '', 1, 0, NULL, '2021-07-19 01:13:03', '2021-07-19 01:13:03'),
(7, 'districts', 'districts', 'District', 'Districts', NULL, 'App\\Models\\District', NULL, NULL, NULL, 1, 0, '{\"order_column\":\"order\",\"order_display_column\":\"name\",\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-07-29 05:03:39', '2021-09-14 06:14:40'),
(9, 'zone_offices', 'zone-offices', 'Zone Office', 'Zone Offices', NULL, 'App\\Models\\ZoneOffice', NULL, NULL, NULL, 1, 0, '{\"order_column\":\"order\",\"order_display_column\":\"title\",\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-07-31 22:33:54', '2022-11-13 05:12:43'),
(10, 'network_coverages', 'network-coverages', 'Network Coverage', 'Network Coverages', NULL, 'App\\Models\\NetworkCoverage', NULL, NULL, NULL, 1, 0, '{\"order_column\":\"order\",\"order_display_column\":\"title\",\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-07-31 23:37:08', '2021-09-14 06:15:48'),
(11, 'internet_coverages', 'internet-coverages', 'Internet Coverage', 'Internet Coverages', NULL, 'App\\Models\\InternetCoverage', NULL, NULL, NULL, 1, 0, '{\"order_column\":\"order\",\"order_display_column\":\"title\",\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-07-31 23:52:09', '2021-08-05 01:05:15'),
(12, 'service_values', 'service-values', 'Service Value', 'Service Values', NULL, 'App\\Models\\ServiceValue', NULL, NULL, NULL, 1, 0, '{\"order_column\":\"order\",\"order_display_column\":\"title\",\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-08-01 00:08:06', '2021-09-14 06:35:07'),
(13, 'package_categories', 'package-categories', 'Package Category', 'Package Categories', NULL, 'App\\Models\\PackageCategory', NULL, NULL, NULL, 1, 0, '{\"order_column\":\"order\",\"order_display_column\":\"title\",\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-08-01 03:08:18', '2022-11-09 04:19:44'),
(14, 'packages', 'packages', 'Package', 'Packages', NULL, 'App\\Models\\Package', NULL, NULL, NULL, 1, 0, '{\"order_column\":\"order\",\"order_display_column\":\"title\",\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-08-01 05:31:40', '2022-11-22 03:35:03'),
(16, 'slideshows', 'slideshows', 'Slideshow', 'Slideshows', NULL, 'App\\Models\\Slideshow', NULL, NULL, NULL, 1, 0, '{\"order_column\":\"order\",\"order_display_column\":\"image_mobile\",\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-08-05 05:50:15', '2022-11-09 22:53:04'),
(17, 'solution_requirement_types', 'solution-requirement-types', 'Solution Requirement Type', 'Solution Requirement Types', NULL, 'App\\Models\\SolutionRequirementType', NULL, NULL, NULL, 1, 0, '{\"order_column\":\"order\",\"order_display_column\":\"title\",\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-08-18 04:23:22', '2021-09-14 06:36:39'),
(18, 'solution_requests', 'solution-requests', 'Solution Request', 'Solution Requests', NULL, 'App\\Models\\SolutionRequest', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-08-22 03:05:58', '2021-08-22 06:31:36'),
(19, 'contents', 'contents', 'Content', 'Contents', NULL, 'App\\Models\\Content', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-08-28 22:41:45', '2021-09-14 06:12:56'),
(20, 'problem_types', 'problem-types', 'Problem Type', 'Problem Types', NULL, 'App\\Models\\ProblemType', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2021-09-07 06:00:12', '2021-09-14 06:33:32'),
(21, 'customers', 'customers', 'Customer', 'Customers', NULL, 'App\\Models\\Customer', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2022-11-09 00:04:50', '2022-11-09 00:48:09'),
(22, 'customer_reviews', 'customer-reviews', 'Customer Review', 'Customer Reviews', NULL, 'App\\Models\\CustomerReview', NULL, NULL, NULL, 1, 0, '{\"order_column\":\"order\",\"order_display_column\":\"description\",\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2022-11-09 00:40:57', '2022-11-21 22:54:57'),
(23, 'social_media', 'social-media', 'Social Media', 'Social Media', NULL, 'App\\Models\\SocialMedia', NULL, NULL, NULL, 1, 0, '{\"order_column\":\"order\",\"order_display_column\":\"title\",\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2022-11-10 00:21:27', '2022-11-10 05:24:15'),
(27, 'brands', 'brands', 'Brand', 'Brands', NULL, 'App\\Models\\Brand', NULL, NULL, NULL, 1, 0, '{\"order_column\":\"order\",\"order_display_column\":\"name\",\"order_direction\":\"asc\",\"default_search_key\":null,\"scope\":null}', '2022-11-10 06:59:33', '2022-11-12 21:53:01'),
(29, 'brand_categories', 'brand-categories', 'Brand Category', 'Brand Categories', NULL, 'App\\Models\\BrandCategory', NULL, NULL, NULL, 1, 0, '{\"order_column\":null,\"order_display_column\":null,\"order_direction\":\"asc\",\"default_search_key\":null}', '2022-11-10 07:09:28', '2022-11-10 07:09:28');

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` smallint NOT NULL,
  `status` tinyint NOT NULL DEFAULT '0',
  `created_by` int UNSIGNED NOT NULL,
  `last_updated_by` int UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `name`, `order`, `status`, `created_by`, `last_updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Dhaka', 1, 1, 1, 1, '2021-07-29 05:22:51', '2021-07-29 05:34:17'),
(2, 'Khulna', 2, 1, 1, 1, '2021-07-29 05:23:42', '2021-07-29 05:34:29'),
(3, 'Sylhet', 3, 1, 1, 1, '2021-07-29 05:34:05', '2021-09-07 05:29:53'),
(4, 'Comilla', 4, 1, 1, NULL, '2021-08-29 04:02:41', '2021-08-29 04:02:41'),
(5, 'Narayanganj', 5, 1, 1, NULL, '2021-08-29 04:03:15', '2021-08-29 04:03:15'),
(6, 'Bogra', 6, 1, 1, NULL, '2021-08-29 04:03:29', '2021-08-29 04:03:29'),
(7, 'Chittagong', 7, 1, 1, NULL, '2021-08-29 04:03:41', '2021-08-29 04:03:41'),
(8, 'Rangpur', 8, 1, 1, NULL, '2021-08-29 04:04:14', '2021-08-29 04:04:14'),
(9, 'Rajshahi', 9, 1, 1, NULL, '2021-08-29 04:04:27', '2021-08-29 04:04:27'),
(10, 'Kushtia', 10, 1, 1, NULL, '2021-08-29 04:04:43', '2021-08-29 04:04:43'),
(11, 'Tangail', 11, 1, 1, NULL, '2021-08-29 04:04:55', '2021-08-29 04:04:55'),
(12, 'Mymensingh', 12, 1, 1, NULL, '2021-08-29 04:05:08', '2021-08-29 04:05:08'),
(13, 'Jessore', 13, 1, 1, NULL, '2021-08-29 04:05:20', '2021-08-29 04:05:20');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `get_information_requests`
--

CREATE TABLE `get_information_requests` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_human_verified` tinyint DEFAULT NULL,
  `human_verification_result` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remote_addr` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remote_port` int DEFAULT NULL,
  `request_scheme` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_method` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `platform` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser_maker` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser_version` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_pointing_method` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `minorver` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ismobiledevice` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `istablet` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crawler` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `http_user_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `get_information_requests`
--

INSERT INTO `get_information_requests` (`id`, `name`, `phone`, `email`, `details`, `is_human_verified`, `human_verification_result`, `remote_addr`, `remote_port`, `request_scheme`, `request_method`, `platform`, `browser`, `browser_maker`, `browser_version`, `device_type`, `device_pointing_method`, `minorver`, `ismobiledevice`, `istablet`, `crawler`, `http_user_agent`, `created_at`, `updated_at`) VALUES
(1, 'Kylie Hart', '077 1421 1611', 'kyliehartila@yahoo.com', 'Hi, \r\n\r\nWe\'re wondering if you\'d be interested in a \'dofollow\' backlink to 210.4.77.134 from our website that has a Moz Domain Authority of 50?\r\n\r\nWe charge just $40 (USD) to be paid via Paypal, card, or Payoneer. This is a one-time fee, so there are no extra charges and the link is permanent.\r\n\r\nIf you\'d like to know more about the site, please reply to this email and we can discuss further.\r\n\r\nKind Regards,\r\nKylie', 0, NULL, '23.106.219.138', 23229, 'http', 'POST', 'Win8', 'Firefox', 'Mozilla Foundation', '60.0', 'Desktop', 'mouse', '0', '', '', '', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0', '2021-12-18 11:44:17', '2021-12-18 11:44:17'),
(2, 'Olivia Pointon', '02079460433', 'avaolivia2747@gmail.com', 'Hi,\r\n\r\nWe\'d like to introduce to you our explainer video service which we feel can benefit your site 210.4.77.134.\r\n\r\nCheck out some of our existing videos here:\r\nhttps://www.youtube.com/watch?v=oYoUQjxvhA0\r\nhttps://www.youtube.com/watch?v=MOnhn77TgDE\r\nhttps://www.youtube.com/watch?v=NKY4a3hvmUc\r\n\r\nAll of our videos are in a similar animated format as the above examples and we have voice over artists with US/UK/Australian accents.\r\nWe can also produce voice overs in languages other than English.\r\n\r\nThey can show a solution to a problem or simply promote one of your products or services. They are concise, can be uploaded to video such as Youtube, and can be embedded into your website or featured on landing pages.\r\n\r\nOur prices are as follows depending on video length:\r\n1 minute = $189\r\n1-2 minutes = $339\r\n2-3 minutes = $449\r\n\r\n*All prices above are in USD and include an engaging, captivating video with full script and voice-over.\r\n\r\nIf this is something you would like to discuss further, don\'t hesitate to get in touch.\r\n\r\nKind Regards,\r\nOlivia', 0, NULL, '23.80.97.15', 61592, 'http', 'POST', 'Win8', 'Firefox', 'Mozilla Foundation', '60.0', 'Desktop', 'mouse', '0', '', '', '', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0', '2021-12-19 16:16:41', '2021-12-19 16:16:41'),
(3, 'Mark Brown', '02079460433', 'markbrown3049@gmail.com', 'Hi,\r\n\r\nWe\'d like to introduce to you our logo design service that we feel would benefit your site 210.4.77.134.\r\n\r\nYou can view some of our previously designed logos here:\r\nhttps://imgur.com/a/39n0lTz\r\n\r\nWe design a wide range of logo styles including, abstract, 3D, animated, branding, plus several more. We can also do logos for your social media profiles such as Facebook, Twitter and Instagram.\r\n\r\nIf this is something you may be interested in, reply and we can discuss further.\r\n\r\nKind Regards,\r\nMark', 0, NULL, '23.106.219.174', 58963, 'http', 'POST', 'Win8', 'Firefox', 'Mozilla Foundation', '60.0', 'Desktop', 'mouse', '0', '', '', '', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0', '2022-01-15 09:35:58', '2022-01-15 09:35:58'),
(4, 'Steve Angeli', '026 462 98 78', 'steve@backlinks-4u.com', 'Hi, \r\n\r\nWe\'re wondering if you\'d be interested in a strong backlink (Moz DA50) to 210.4.77.134 to help improve your search engine rankings?\r\n\r\nOur price is just 50 USD, to be paid via Paypal and this is a one-time fee for a permanent backlink.\r\n\r\nIf you\'d like more information about the site and the options available, just reply to this email and we can discuss things further.\r\n\r\nKind Regards,\r\nSteve', 0, NULL, '23.254.55.116', 43197, 'http', 'POST', 'Win8', 'Firefox', 'Mozilla Foundation', '60.0', 'Desktop', 'mouse', '0', '', '', '', 'Mozilla/5.0 (Windows NT 6.2; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0', '2022-04-25 06:06:35', '2022-04-25 06:06:35'),
(5, 'Steve Watson', '078 4938 0361', 'steve@explainervideos4u.info', 'Hi,\r\n\r\nWe\'d like to introduce to you our explainer video service, which we feel can benefit your site 210.4.77.134.\r\n\r\nCheck out some of our existing videos here:\r\nhttps://www.youtube.com/watch?v=oYoUQjxvhA0\r\nhttps://www.youtube.com/watch?v=MOnhn77TgDE\r\nhttps://www.youtube.com/watch?v=NKY4a3hvmUc\r\n\r\nAll of our videos are in a similar animated format as the above examples, and we have voice over artists with US/UK/Australian/Canadian accents.\r\nWe can also produce voice overs in languages other than English.\r\n\r\nThey can show a solution to a problem or simply promote one of your products or services. They are concise, can be uploaded to video sites such as YouTube, and can be embedded into your website or featured on landing pages.\r\n\r\nOur prices are as follows depending on video length:\r\nUp to 1 minute = $259\r\n1-2 minutes = $379\r\n2-3 minutes = $489\r\n\r\n*All prices above are in USD and include an engaging, captivating video with full script and voice-over.\r\n\r\nIf this is something you would like to discuss further, don\'t hesitate to reply.\r\n\r\nKind Regards,\r\nSteve', 0, NULL, '23.106.219.181', 35028, 'http', 'POST', 'Win8.1', 'Firefox', 'Mozilla Foundation', '59.0', 'Desktop', 'mouse', '0', '', '', '', 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:59.0) Gecko/20100101 Firefox/59.0', '2022-04-29 20:39:03', '2022-04-29 20:39:03'),
(6, 'Steve Watson', '078 4938 0361', 'steve@explainervideos4u.info', 'Hi,\r\n\r\nWe\'d like to introduce to you our explainer video service, which we feel can benefit your site 210.4.77.134.\r\n\r\nCheck out some of our existing videos here:\r\nhttps://www.youtube.com/watch?v=oYoUQjxvhA0\r\nhttps://www.youtube.com/watch?v=MOnhn77TgDE\r\nhttps://www.youtube.com/watch?v=NKY4a3hvmUc\r\n\r\nAll of our videos are in a similar animated format as the above examples, and we have voice over artists with US/UK/Australian/Canadian accents.\r\nWe can also produce voice overs in languages other than English.\r\n\r\nThey can show a solution to a problem or simply promote one of your products or services. They are concise, can be uploaded to video sites such as YouTube, and can be embedded into your website or featured on landing pages.\r\n\r\nOur prices are as follows depending on video length:\r\nUp to 1 minute = $239\r\n1-2 minutes = $339\r\n2-3 minutes = $439\r\n\r\n*All prices above are in USD and include an engaging, captivating video with full script and voice-over.\r\n\r\nIf this is something you would like to discuss further, don\'t hesitate to reply.\r\n\r\nKind Regards,\r\nSteve', 0, NULL, '23.80.97.88', 53897, 'http', 'POST', 'Android', 'UC Browser', 'UCWeb Inc.', '11.3', 'Mobile Phone', 'touchscreen', '3', '1', '', '', 'Mozilla/5.0 (Windows; U; Windows NT 5.2; en-US) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.89 Safari/537.36 UCBrowser/11.3.5.908', '2022-05-03 14:12:39', '2022-05-03 14:12:39'),
(7, 'Josephine Glassey', '02076293931', 'glassey.josephine@gmail.com', 'Hi,\r\n\r\nHave you ever wondered how the big influencers on Instagram make so much money? If the answer is \"yes\", then this eBook is exactly what you\'ve been looking for. We go over everything you need to know about gaining real followers and earning real money. \r\n\r\nWith over 200 pages of strategies, growth methods and secrets - it\'s an Instagram goldmine! We have helped thousands of people to radically grow their profiles, businesses and income. \r\n\r\nWant to know more? Visit: https://bit.ly/3c9M062\r\n\r\nRegards,\r\nJosephine', 0, NULL, '37.59.144.237', 61197, 'http', 'POST', 'MacOSX', 'Firefox', 'Mozilla Foundation', '0.0', 'Desktop', 'mouse', '0', '', '', '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 12.5; rv:102.0) Gecko/20100101 Firefox/102.0', '2022-08-22 01:04:17', '2022-08-22 01:04:17'),
(8, 'Nicola Tucker', '01323 732632', 'nicolatuckerrvp@yahoo.com', 'Hi there,\r\n\r\nWe would like to introduce to you our service where we can grow the number of your Twitter followers, organically.\r\n\r\nMost people use a follow-unfollow technique where they follow accounts and then unfollow a few days later, hoping a % of them have followed back; or they offer a competition where people have to follow to enter. The big problem with these techniques is that people follow you either out of politeness or because there\'s an incentive - not because they are interested in your profile. Consequently, this results in poor engagement.\r\n\r\nInstead, we retweet your tweets to our audience of over 3 million people. If they like your profile - they might follow, meaning all your new followers are following because they wish to and not because they had an incentive to do so.\r\n\r\nOur price is $120 per 1000 followers and generally takes around 10-14 days.\r\n\r\nIf this is something you may be interested in, get back in touch.\r\n\r\nKind Regards,\r\nNicola', 0, NULL, '107.172.97.49', 34113, 'http', 'POST', 'Win10', 'Vivaldi', 'Vivaldi Technologies', '0.0', 'Desktop', 'mouse', '0', '', '', '', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36 Vivaldi/5.3.2679.68', '2022-09-07 11:14:52', '2022-09-07 11:14:52'),
(11, 'sjadasdasi', '2308473024732094', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-11-14 06:36:02', '2022-11-14 06:36:02'),
(12, 'sjadasdasi', '2308473024732094', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-11-14 06:39:37', '2022-11-14 06:39:37'),
(13, 'sjadasdasi', '2308473024732094', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-11-14 06:40:03', '2022-11-14 06:40:03'),
(14, 'sjadasdasi', '2308473024732094', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-11-14 06:43:51', '2022-11-14 06:43:51'),
(15, 'sjadasdasi', '2308473024732094', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-11-14 06:51:22', '2022-11-14 06:51:22'),
(16, 'sjadasdasi', '2308473024732094', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-11-14 07:05:52', '2022-11-14 07:05:52'),
(17, 'sjadasdasi', '2308473024732094', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-11-14 22:24:00', '2022-11-14 22:24:00'),
(18, 'sjadasdasi', '01681034449', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-11-14 22:46:16', '2022-11-14 22:46:16'),
(19, 'asjajlsha', '01681034449', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-11-15 05:11:42', '2022-11-15 05:11:42'),
(20, 'asjajlsha', '01681034449', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-11-15 05:16:02', '2022-11-15 05:16:02'),
(21, 'nahid', '01681034449', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-11-16 00:33:27', '2022-11-16 00:33:27'),
(22, 'test', '000000000000000000000', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-11-23 05:20:02', '2022-11-23 05:20:02');

-- --------------------------------------------------------

--
-- Table structure for table `internet_coverages`
--

CREATE TABLE `internet_coverages` (
  `id` int UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `order` int NOT NULL,
  `status` int NOT NULL DEFAULT '0',
  `created_by` int NOT NULL,
  `last_updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `district_id` int UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `internet_coverages`
--

INSERT INTO `internet_coverages` (`id`, `title`, `description`, `order`, `status`, `created_by`, `last_updated_by`, `created_at`, `updated_at`, `district_id`) VALUES
(1, 'Dhanmondi, Dhaka', 'Dhanmondi, Dhaka', 1, 1, 1, NULL, '2021-08-05 00:47:21', '2021-08-05 00:47:21', 1),
(2, 'Mohammadpur, Dhaka', 'Mohammadpur, Dhaka', 2, 1, 1, NULL, '2021-08-05 00:48:11', '2021-08-05 00:48:11', 1),
(3, 'KHulna Sadar', 'khulna address', 3, 1, 4, NULL, '2022-11-16 00:28:42', '2022-11-16 00:28:42', 2);

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'admin', '2021-07-19 01:12:52', '2021-07-19 01:12:52'),
(2, 'main_menu', '2021-07-28 00:44:37', '2021-07-28 00:45:01'),
(3, 'footer', '2021-08-18 00:33:45', '2021-08-18 00:33:45'),
(4, 'footer_collection', '2022-11-09 22:27:36', '2022-11-09 22:27:36');

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE `menu_items` (
  `id` int UNSIGNED NOT NULL,
  `menu_id` int UNSIGNED DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_self',
  `icon_class` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int DEFAULT NULL,
  `order` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `route` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameters` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`id`, `menu_id`, `title`, `url`, `target`, `icon_class`, `color`, `parent_id`, `order`, `created_at`, `updated_at`, `route`, `parameters`) VALUES
(1, 1, 'Dashboard', '', '_self', 'voyager-boat', NULL, NULL, 1, '2021-07-19 01:12:52', '2021-07-19 01:12:52', 'voyager.dashboard', NULL),
(2, 1, 'Media', '', '_self', 'voyager-images', NULL, NULL, 12, '2021-07-19 01:12:52', '2022-11-10 07:01:16', 'voyager.media.index', NULL),
(3, 1, 'Users', '', '_self', 'voyager-person', NULL, NULL, 11, '2021-07-19 01:12:53', '2022-11-10 07:01:16', 'voyager.users.index', NULL),
(4, 1, 'Roles', '', '_self', 'voyager-lock', NULL, NULL, 10, '2021-07-19 01:12:53', '2022-11-10 07:01:16', 'voyager.roles.index', NULL),
(5, 1, 'Tools', '', '_self', 'voyager-tools', NULL, NULL, 14, '2021-07-19 01:12:53', '2022-11-10 07:01:16', NULL, NULL),
(6, 1, 'Menu Builder', '', '_self', 'voyager-list', NULL, 5, 1, '2021-07-19 01:12:53', '2021-09-07 22:10:17', 'voyager.menus.index', NULL),
(7, 1, 'Database', '', '_self', 'voyager-data', NULL, 5, 2, '2021-07-19 01:12:53', '2021-09-07 22:10:17', 'voyager.database.index', NULL),
(8, 1, 'Compass', '', '_self', 'voyager-compass', NULL, 5, 3, '2021-07-19 01:12:53', '2021-09-07 22:10:17', 'voyager.compass.index', NULL),
(9, 1, 'BREAD', '', '_self', 'voyager-bread', NULL, 5, 4, '2021-07-19 01:12:53', '2021-09-07 22:10:17', 'voyager.bread.index', NULL),
(10, 1, 'Settings', '', '_self', 'voyager-settings', NULL, NULL, 15, '2021-07-19 01:12:53', '2022-11-10 07:01:16', 'voyager.settings.index', NULL),
(11, 1, 'Categories', '', '_self', 'voyager-categories', NULL, 49, 2, '2021-07-19 01:13:01', '2021-09-07 22:10:42', 'voyager.categories.index', NULL),
(12, 1, 'Posts', '', '_self', 'voyager-news', NULL, 49, 1, '2021-07-19 01:13:03', '2021-09-07 22:10:39', 'voyager.posts.index', NULL),
(13, 1, 'Pages', '', '_self', 'voyager-file-text', NULL, NULL, 13, '2021-07-19 01:13:04', '2022-11-10 07:01:16', 'voyager.pages.index', NULL),
(14, 1, 'Hooks', '', '_self', 'voyager-hook', NULL, 5, 5, '2021-07-19 01:13:07', '2021-09-07 22:10:17', 'voyager.hooks', NULL),
(16, 2, 'Packages', '/package/standard', '_self', NULL, '#ffffff', NULL, 1, '2021-07-28 00:47:15', '2022-11-22 04:58:17', NULL, ''),
(17, 2, 'FAQs', '/faqs', '_self', NULL, '#ffffff', NULL, 2, '2021-07-28 00:48:27', '2022-11-09 07:15:15', NULL, ''),
(18, 2, 'About', '/about', '_self', NULL, '#ffffff', NULL, 3, '2021-07-28 00:51:03', '2022-11-22 21:21:03', NULL, ''),
(19, 2, 'Contact', '/contact', '_self', NULL, '#ffffff', NULL, 4, '2021-07-28 00:53:08', '2022-11-09 07:15:15', NULL, ''),
(20, 2, 'Self Care', 'https://portal.smile.com.bd/customer/login', '_self', NULL, '#ffffff', NULL, 5, '2021-07-28 01:09:43', '2022-11-22 21:21:09', NULL, ''),
(21, 1, 'Districts', '', '_self', NULL, NULL, 52, 1, '2021-07-29 05:03:40', '2021-09-07 22:16:39', 'voyager.districts.index', NULL),
(23, 1, 'Zone Offices', '', '_self', NULL, NULL, 52, 2, '2021-07-31 22:33:55', '2021-09-07 22:16:53', 'voyager.zone-offices.index', NULL),
(24, 1, 'Network Coverages', '', '_self', NULL, NULL, 52, 3, '2021-07-31 23:37:09', '2021-09-07 22:17:03', 'voyager.network-coverages.index', NULL),
(25, 1, 'Internet Coverages', '', '_self', NULL, NULL, 52, 4, '2021-07-31 23:52:09', '2021-09-07 22:17:07', 'voyager.internet-coverages.index', NULL),
(26, 1, 'Service Values', '', '_self', NULL, NULL, 50, 3, '2021-08-01 00:08:07', '2021-09-12 03:11:39', 'voyager.service-values.index', NULL),
(27, 1, 'Package Categories', '', '_self', NULL, NULL, 51, 2, '2021-08-01 03:08:18', '2021-09-07 22:14:41', 'voyager.package-categories.index', NULL),
(28, 1, 'Packages', '', '_self', NULL, NULL, 51, 1, '2021-08-01 05:31:40', '2021-09-07 22:14:33', 'voyager.packages.index', NULL),
(30, 1, 'Slideshows', '', '_self', NULL, NULL, 50, 1, '2021-08-05 05:50:16', '2021-09-07 22:13:00', 'voyager.slideshows.index', NULL),
(31, 2, 'Standard', '/package/standard', '_self', NULL, '#000000', 16, 1, '2021-08-11 02:20:38', '2022-11-08 06:45:51', NULL, ''),
(45, 1, 'Solution Requirement Types', '', '_self', NULL, NULL, 53, 2, '2021-08-18 04:23:22', '2021-09-12 03:10:49', 'voyager.solution-requirement-types.index', NULL),
(46, 1, 'Solution Requests', '', '_self', NULL, NULL, 53, 1, '2021-08-22 03:05:59', '2021-09-07 22:19:07', 'voyager.solution-requests.index', NULL),
(47, 1, 'Contents', '', '_self', NULL, NULL, 50, 2, '2021-08-28 22:41:46', '2021-09-07 22:13:40', 'voyager.contents.index', NULL),
(48, 1, 'Problem Types', '', '_self', NULL, NULL, 53, 3, '2021-09-07 06:00:13', '2021-09-12 03:11:56', 'voyager.problem-types.index', NULL),
(49, 1, 'Blog', '', '_self', 'voyager-pen', '#000000', NULL, 5, '2021-09-07 22:10:06', '2022-11-10 00:40:24', NULL, ''),
(50, 1, 'Main Content', '', '_self', 'voyager-file-text', '#000000', NULL, 7, '2021-09-07 22:12:27', '2022-11-10 07:01:16', NULL, ''),
(51, 1, 'Package Info', '', '_self', 'voyager-gift', '#000000', NULL, 4, '2021-09-07 22:14:19', '2022-11-10 00:40:24', NULL, ''),
(52, 1, 'Location', '', '_self', 'voyager-location', '#000000', NULL, 9, '2021-09-07 22:16:28', '2022-11-10 07:01:16', NULL, ''),
(53, 1, 'Client\'s Feedback', '', '_self', 'voyager-chat', '#000000', NULL, 3, '2021-09-07 22:18:42', '2022-11-10 00:40:24', NULL, ''),
(54, 1, 'Supporting Content', '', '_self', NULL, '#000000', NULL, 16, '2021-09-07 22:19:54', '2022-11-10 07:01:16', NULL, ''),
(55, 2, 'Ek Desh Ek Rate', '/package/ek-desh-ek-rate', '_self', NULL, '#000000', 16, 2, '2021-09-29 05:09:01', '2022-11-09 07:15:15', NULL, ''),
(56, 1, 'Customers', '', '_self', 'voyager-people', '#000000', 58, 1, '2022-11-09 00:04:50', '2022-11-09 01:05:17', 'voyager.customers.index', 'null'),
(57, 1, 'Customer Reviews', '', '_self', 'voyager-certificate', '#000000', 58, 2, '2022-11-09 00:40:57', '2022-11-09 01:07:13', 'voyager.customer-reviews.index', 'null'),
(58, 1, 'Review', '', '_self', 'voyager-star-half', '#000000', NULL, 8, '2022-11-09 01:03:36', '2022-11-10 07:01:16', NULL, ''),
(59, 4, 'Bill Payment Guide', '/bill', '_self', NULL, '#000000', NULL, 29, '2022-11-09 22:28:43', '2022-11-22 21:19:41', NULL, ''),
(60, 4, 'Connectivity Form', '/connectivity', '_self', NULL, '#000000', NULL, 30, '2022-11-09 22:29:17', '2022-11-22 21:19:46', NULL, ''),
(61, 4, 'Media Center', '/media', '_self', NULL, '#000000', NULL, 31, '2022-11-09 22:29:35', '2022-11-22 21:19:51', NULL, ''),
(62, 4, 'Reviews', '/reviews', '_self', NULL, '#000000', NULL, 32, '2022-11-09 22:29:54', '2022-11-22 21:19:56', NULL, ''),
(63, 3, 'Privacy Policy', '/privacies', '_blank', NULL, '#000000', NULL, 33, '2022-11-09 22:40:33', '2022-11-10 04:13:09', NULL, ''),
(64, 3, 'Terms of Uses', '/terms', '_blank', NULL, '#000000', NULL, 34, '2022-11-09 22:41:03', '2022-11-10 03:35:38', NULL, ''),
(65, 1, 'Social Media', '', '_self', 'voyager-smile', '#000000', NULL, 2, '2022-11-10 00:21:27', '2022-11-10 00:40:24', 'voyager.social-media.index', 'null'),
(67, 1, 'Brand', '', '_self', 'voyager-categories', '#000000', NULL, 6, '2022-11-10 06:56:36', '2022-11-10 07:01:16', NULL, ''),
(68, 1, 'Brands', '', '_self', NULL, NULL, 67, 1, '2022-11-10 06:59:34', '2022-11-10 06:59:55', 'voyager.brands.index', NULL),
(69, 1, 'Brand Categories', '', '_self', NULL, NULL, 67, 2, '2022-11-10 07:09:28', '2022-11-10 07:10:03', 'voyager.brand-categories.index', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_01_01_000000_add_voyager_user_fields', 1),
(4, '2016_01_01_000000_create_data_types_table', 1),
(5, '2016_05_19_173453_create_menu_table', 1),
(6, '2016_10_21_190000_create_roles_table', 1),
(7, '2016_10_21_190000_create_settings_table', 1),
(8, '2016_11_30_135954_create_permission_table', 1),
(9, '2016_11_30_141208_create_permission_role_table', 1),
(10, '2016_12_26_201236_data_types__add__server_side', 1),
(11, '2017_01_13_000000_add_route_to_menu_items_table', 1),
(12, '2017_01_14_005015_create_translations_table', 1),
(13, '2017_01_15_000000_make_table_name_nullable_in_permissions_table', 1),
(14, '2017_03_06_000000_add_controller_to_data_types_table', 1),
(15, '2017_04_21_000000_add_order_to_data_rows_table', 1),
(16, '2017_07_05_210000_add_policyname_to_data_types_table', 1),
(17, '2017_08_05_000000_add_group_to_settings_table', 1),
(18, '2017_11_26_013050_add_user_role_relationship', 1),
(19, '2017_11_26_015000_create_user_roles_table', 1),
(20, '2018_03_11_000000_add_user_settings', 1),
(21, '2018_03_14_000000_add_details_to_data_types_table', 1),
(22, '2018_03_16_000000_make_settings_value_nullable', 1),
(23, '2019_08_19_000000_create_failed_jobs_table', 1),
(24, '2016_01_01_000000_create_pages_table', 2),
(25, '2016_01_01_000000_create_posts_table', 2),
(26, '2016_02_15_204651_create_categories_table', 2),
(27, '2017_04_11_000000_alter_post_nullable_fields_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `network_coverages`
--

CREATE TABLE `network_coverages` (
  `id` int UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `order` int NOT NULL,
  `status` int NOT NULL,
  `created_by` int NOT NULL,
  `last_updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `network_coverages`
--

INSERT INTO `network_coverages` (`id`, `title`, `description`, `order`, `status`, `created_by`, `last_updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Dhaka', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 1, 1, 1, 1, '2021-07-31 23:42:16', '2021-07-31 23:44:13'),
(2, 'Khulna', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 2, 1, 1, 1, '2021-07-31 23:42:37', '2021-10-27 04:53:04');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE `packages` (
  `id` int UNSIGNED NOT NULL,
  `maxim_id` int DEFAULT NULL,
  `package_category_id` int UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `home_logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `booking_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `internet_speed` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `internet_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bdix_speed` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bdix_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monthly_charges` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `vat_declaration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `features` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_excerpt` text COLLATE utf8mb4_unicode_ci,
  `description_more` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `seo_titlle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `meta_keyword` text COLLATE utf8mb4_unicode_ci,
  `og_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_description` text COLLATE utf8mb4_unicode_ci,
  `og_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int NOT NULL,
  `status` int NOT NULL DEFAULT '0',
  `created_by` int NOT NULL,
  `last_updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `show_in_honepage` tinyint UNSIGNED NOT NULL DEFAULT '0',
  `features_1` text COLLATE utf8mb4_unicode_ci,
  `features_2` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `maxim_id`, `package_category_id`, `title`, `home_logo`, `logo`, `booking_link`, `internet_speed`, `internet_description`, `bdix_speed`, `bdix_description`, `monthly_charges`, `vat_declaration`, `features`, `description_title`, `description_excerpt`, `description_more`, `description_image`, `slug`, `seo_titlle`, `meta_description`, `meta_keyword`, `og_title`, `og_description`, `og_image`, `order`, `status`, `created_by`, `last_updated_by`, `created_at`, `updated_at`, `show_in_honepage`, `features_1`, `features_2`) VALUES
(5, 3, 4, 'SILVER', 'packages/October2021/j1XYE7BXzgbU2aYPecHM.png', 'packages/October2021/0WKbBid0tfp86j8oUuL3.png', 'connectivity', '15', 'True Internet Bandwidth', '30 Mbps', 'Bufferless Facebook & YouTube', '945', '(Including 5% VAT)', '<div class=\"moz-value\"><span class=\"pk-8\">Internet: 25 Mbps</span> <span class=\"pk-8\">BDIX 30 Mbps</span> <span class=\"pk-8\">Fiber Optic Connection</span> <span class=\"pk-8\">No Data-Cap &amp; FUP</span> <span class=\"pk-8\">24/7 HelpDesk Support</span></div>', 'Most popular broadband internet package in Dhaka city.', '<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">Smile Silver is the most affordable and popular broadband internet package in the broadband users communities in Bangladesh. You will get 15Mbps True internet/ IIG/ Raw bandwidth speed, which has been designed to ensure smooth browsing experience on international websites, uninterrupted HD video calling, bufferless OTT streaming such as Netflix, Amazon Prime with unlimited browsing and downloading. The most unique thing is that, Smile ensures the package declared speed 24 hours accurately, which is our core commitment to our broadband users.</span></p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\">&nbsp;</p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">The Smile Silver package is designed to provide a smooth experience in all regular types of internet usages such as watching online videos, video conferencing, uploading and downloading files etc. With 30Mbps BDIX speed, users will enjoy bufferless video contents on YouTube, Facebook and other social media on any devices like Smart TV, PC and Smartphones. This package is considered the country\'s cheapest broadband internet package comparing the cost vs the bandwidth speed.</span></p>', '<p>&nbsp;</p>\r\n<p><span id=\"docs-internal-guid-e8032e48-7fff-0ac2-9ad7-e991e7a21c20\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;\">You may think that where other ISPs are providing 100Mbps BDIX speed in their broadband packages, why is Smile giving only 30Mbps? The answer is very simple- It will increase the package price and waste your money! Because you are never going to consume 100Mbps speed at once for your regular internet use, then why should you pay for that! Also, you will need an expensive wifi router to enable such speed on multiple devices. We had run hundreds of tests on our users to understand their maximum speed consumption on Youtube and social sites. We found that each and every user gets a smooth experience with around 30Mbps BDIX speed. Thus, we designed all of our broadband packages to give you the best internet experience with most cost effective prices.</span></span></p>', 'packages/October2021/ga2XPVCnt48U7FIvdyKZ.jpg', 'silver', '15Mbps Broadband Internet Package', 'Smile Silver is the most affordable and popular broadband internet package in the broadband users communities in Bangladesh.', 'most popular broadband internet package in dhaka city', 'Smile Broadband | 15Mbps True Internet Bandwidth | Accurate Speed 24/7', 'The Smile Silver package is designed to provide a smooth experience in all regular types of internet usages such as watching online videos, video conferencing, uploading and downloading files etc.', 'Ha Ha Ha', 1, 1, 3, 4, '2021-10-10 23:43:09', '2022-11-22 04:29:14', 1, '<div>Dynamic Real-IP</div>', '<div>Bufferless Facebook &amp; Youtube</div>'),
(6, 4, 4, 'SILVER SUPREME', 'packages/October2021/i9u8VwSQCYkGKSewmI4I.png', 'packages/October2021/BPWM5WGq7nrjCUfVgjBj.png', 'connectivity', '20', 'True Internet Bandwidth', '30', 'Bufferless Facebook & YouTube', '1260', '(Including 5% VAT)', '<div class=\"moz-value\"><span class=\"pk-8\">Internet: 25 Mbps</span> <span class=\"pk-8\">BDIX 30 Mbps</span> <span class=\"pk-8\">Fiber Optic Connection</span> <span class=\"pk-8\">No Data-Cap &amp; FUP</span> <span class=\"pk-8\">24/7 HelpDesk Support</span></div>', 'Best broadband internet package in Bangladesh', '<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\"><span style=\"font-size: 14.6667px;\">Smile silver supreme is the best broadband internet package for the students and the freelancers who need a bit higher bandwidth speeds for uninterrupted online classes, regular video calling with clients as well as uploading &amp;&nbsp; downloading multiple files at once.</span> Since the very beginning, the price of this package is 1260tk/month (5% VAT includes), luckily when Bangladesh Telecommunication Regulatory Commission (BTRC) declared a single broadband tariff plan for all ISP organizations called &ldquo;Ek Desh Ek Rate&rdquo;, Smile&rsquo;s Silver supreme already matched with the &ldquo;Ek Desh Ek Rate&rdquo; broadband package tariff plan but offers a lot more benefit than the &ldquo;Ek Desh Ek Rate tariff plan.</span></p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\">&nbsp;</p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span id=\"docs-internal-guid-f0d374b8-7fff-8929-c75c-192b96810545\"></span><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">Smile silver supreme is mostly suitable for Students, Freelancers, Sole Entrepreneurs, Online content publishers- Live, Stream etc. Silver supreme is also a budget friendly option for online gamers. Whether you&rsquo;re doing remote learning, working from home, gaming online or watching Netflix, this silver supreme broadband internet package is equipped with necessary power that can give you the most smooth experience upon such usage. Since mobile internet tends to be expensive and if you belong to a household with multiple internet users, this broadband internet package can be the best solution for you and your family.</span></p>', '<p>&nbsp;</p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">With 20Mbps Raw Internet -IIG, you can seamlessly explore international websites, HD video calling / video conferencing, live streaming with unlimited upload and download. It is very important to understand the necessary internet bandwidth speed based on your usage for choosing appropriate packages. Our \"Silver supreme\" has been designed for regular intensive online usage, even with multiple devices and users. Also, Smile broadband is the one and only broadband internet service provider in Bangladesh, that offers and assures 24hours accurate speed with no data cap or FUP (Fair Usage policy). We use multiple upstream to ensure you the best routing &amp; low latency.</span></p>', 'packages/October2021/zEaGbzLQnipITnfHd8oV.jpg', 'silver-supreme', '20Mbps Broadband Internet Package', 'Smile silver supreme is the best broadband internet package for the students and the freelancers who need a bit higher bandwidth speeds for uninterrupted online classes, regular video calling with clients as well as uploading &  downloading multiple files at once.', 'best broadband internet package in bangladesh', 'Smile Broadband | 20Mbps True Internet Bandwidth | Accurate Speed 24/7', 'Smile silver supreme is mostly suitable for Students, Freelancers, Sole Entrepreneurs, Online content publishers- Live, Stream etc.', 'Ha Ha Ha', 2, 1, 3, 4, '2021-10-27 01:34:07', '2022-11-13 06:20:48', 1, '<div>Dynamic Real-IP</div>', '<div>Bufferless Facebook &amp; Youtube</div>'),
(7, 5, 4, 'GOLD', 'packages/October2021/SZZPxEtg4KYDGt7KowJA.png', 'packages/October2021/yqhzgBI6hHigLyiKIbtX.png', 'connectivity', '25', 'True Internet Bandwidth', '30', 'Bufferless Facebook & YouTube', '1680', '(Including 5% VAT)', '<div class=\"moz-value\"><span class=\"pk-8\">Internet: 25 Mbps</span> <span class=\"pk-8\">BDIX 30 Mbps</span> <span class=\"pk-8\">Fiber Optic Connection</span> <span class=\"pk-8\">No Data-Cap &amp; FUP</span> <span class=\"pk-8\">24/7 HelpDesk Support</span></div>', 'Home broadband and wifi solution in Bangladesh', '<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">Smile Gold is mostly suitable for large apartments or flats where more than 4 to 5 internet users simultaneously remain online on multiple devices. That means, this package is packed with sufficient bandwidth speed for the large families. If you are living in a large family with multiple internet users and there are multiple smart devices in your home that need internet connectivity, then you should consider choosing a high bandwidth home broadband package like Smile Gold and create a wifi environment with a decent 5ghz supported wifi router. </span></p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\">&nbsp;</p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">With our 25Mbps true internet /IIG/Raw Bandwidth speed, you can finish your office works more efficiently, make your online meetings for effective without any interruptions, communicate with your long distance friends and families more smoothly, attend online classes with much clarity, enjoy lag free online gaming and streaming and watch buffer-less movies on any OTT platform such as Netflix, Amazon Prime, HBO Max, Hoichoi, Zee5 etc. in HD format. Also, you will get a smooth online experience, no matter the type of devices you use like Desktop, Laptop, Smart Phone, Tab, Smart TV etc.&nbsp;</span></p>', '<p>&nbsp;</p>\r\n<p><span id=\"docs-internal-guid-0922aa29-7fff-66f8-5e82-8b77d6dec284\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;\">Smile always strives to empower the users with the freedom to access and surf with no limitation, that is why we never introduced any FUP(fair usage policy) or Data cap on our home broadband packages. We are committed to provide the best home broadband and wifi solution in Bangladesh providing 24hours accurate speed with reliable connectivity and 24/7 prompt support to our users at an affordable price. In the Gold package you are also getting 30Mbps of cache bandwidth speed.</span></span></p>', 'packages/October2021/c5xxqjHb8wFyeWBJjq1z.jpg', 'gold', '25Mbps Broadband Internet Package', 'Smile Gold is mostly suitable for large apartments or flats where more than 4 to 5 internet users simultaneously remain online on multiple devices.', 'home broadband and wifi solution in Bangladesh', 'Smile Broadband | 25Mbps True Internet Bandwidth | Accurate Speed 24/7', 'We are committed to provide the best home broadband and wifi solution in Bangladesh', 'Ha Ha Ha', 3, 1, 3, 4, '2021-10-27 02:01:20', '2022-11-13 06:20:59', 1, '<div>Dynamic Real-IP</div>', '<div>Bufferless Facebook &amp; Youtube</div>'),
(8, 6, 4, 'DIAMOND', 'packages/October2021/xiQUzmKYkQRC9yOSzvrf.png', 'packages/October2021/E4kNEzcHNvKDidjIpwR8.png', 'connectivity', '30', 'True Internet Bandwidth', '50', 'Bufferless Facebook & YouTube', '1890', '(Including 5% VAT)', '<div class=\"moz-value\"><span class=\"pk-8\">Internet: 25 Mbps</span> <span class=\"pk-8\">BDIX 30 Mbps</span> <span class=\"pk-8\">Fiber Optic Connection</span> <span class=\"pk-8\">No Data-Cap &amp; FUP</span> <span class=\"pk-8\">24/7 HelpDesk Support</span></div>', 'Home broadband and wifi solution in Bangladesh', '<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">Smile diamond is mostly suitable for large apartments or flats where more than 4 to 5 internet users simultaneously remain online on multiple devices. That means, this package is packed with sufficient bandwidth speed for the large families. If you are living in a large family with multiple internet users and there are multiple smart devices in your home that need internet connectivity, then you should consider choosing a high bandwidth home broadband package like Smile Gold and create a wifi environment with a decent 5ghz supported wifi router.</span></p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\">&nbsp;</p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">With our 30Mbps true internet /IIG/Raw Bandwidth speed, you can finish your office works more efficiently, make your online meetings for effective without any interruptions, communicate with your long distance friends and families more smoothly, attend online classes with much clarity, enjoy lag free online gaming and streaming and watch buffer-less movies on any OTT platform such as Netflix, Amazon Prime, HBO Max, Hoichoi, Zee5 etc. in HD format. Also, you will get a smooth online experience, no matter the type of devices you use like Desktop, Laptop, Smart Phone, Tab, Smart TV etc. </span></p>', '<p><span id=\"docs-internal-guid-a1003501-7fff-4747-cda3-d67007b3e3c5\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;\">Smile always strives to empower the users with the freedom to access and surf with no limitation, that is why we never introduced any FUP(fair usage policy) or Data cap on our home broadband packages. We are committed to provide the best home broadband and wifi solution in Bangladesh providing 24hours accurate speed with reliable connectivity and 24/7 prompt support to our users at an affordable price. In the Gold package you are also getting 30Mbps of cache bandwidth speed.</span></span></p>', 'packages/October2021/rrHcCrTAhIyNZC97fbY3.jpg', 'diamond', 'Home broadband and wifi solution in Bangladesh', 'Smile diamond is mostly suitable for large apartments or flats where more than 4 to 5 internet users simultaneously remain online on multiple devices', 'Home broadband and wifi solution in Bangladesh', 'Smile Broadband |30Mbps True Internet Bandwidth | Accurate Speed 24/7', 'Smile diamond is mostly suitable for large apartments or flats where more than 4 to 5 internet users simultaneously remain online on multiple devices.', 'Ha Ha Ha', 4, 1, 3, 4, '2021-10-27 02:15:13', '2022-11-13 06:21:24', 1, '<div>Dynamic Real-IP</div>', '<div>Bufferless Facebook &amp; Youtube</div>'),
(9, 9, 3, 'Ek Desh P1', NULL, NULL, 'connectivity', '5', NULL, '30 Mbps', NULL, '525', '(Including 5% VAT)', '<div class=\"moz-value\"><span class=\"pk-8\">Internet: 25 Mbps</span> <span class=\"pk-8\">BDIX 30 Mbps</span> <span class=\"pk-8\">Fiber Optic Connection</span> <span class=\"pk-8\">No Data-Cap &amp; FUP</span> <span class=\"pk-8\">24/7 HelpDesk Support</span></div>', 'Most popular broadband internet package in Dhaka city.', '<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">Smile Silver is the most affordable and popular broadband internet package in the broadband users communities in Bangladesh. You will get 15Mbps True internet/ IIG/ Raw bandwidth speed, which has been designed to ensure smooth browsing experience on international websites, uninterrupted HD video calling, bufferless OTT streaming such as Netflix, Amazon Prime with unlimited browsing and downloading. The most unique thing is that, Smile ensures the package declared speed 24 hours accurately, which is our core commitment to our broadband users.</span></p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\">&nbsp;</p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">The Smile Ek Desh P1 package is designed to provide a smooth experience in all regular types of internet usages such as watching online videos, video conferencing, uploading and downloading files etc. With 30Mbps BDIX speed, users will enjoy bufferless video contents on YouTube, Facebook and other social media on any devices like Smart TV, PC and Smartphones. This package is considered the country\'s cheapest broadband internet package comparing the cost vs the bandwidth speed.</span></p>', NULL, NULL, 'ek-desh-p1', '5Mbps Broadband Internet Package', NULL, NULL, 'Smile Broadband | 15Mbps True Internet Bandwidth | Accurate Speed 24/7', NULL, NULL, 5, 1, 4, 4, '2022-11-21 04:21:11', '2022-11-22 04:36:06', 0, '<div>Shared Ratio 1:8</div>', '<div>Fiber Optic Connection</div>'),
(10, 10, 3, 'Ek Desh P2', NULL, NULL, 'connectivity', '10', NULL, '30 Mbps', NULL, '840', '(Including 5% VAT)', '<div class=\"moz-value\"><span class=\"pk-8\">Internet: 25 Mbps</span> <span class=\"pk-8\">BDIX 30 Mbps</span> <span class=\"pk-8\">Fiber Optic Connection</span> <span class=\"pk-8\">No Data-Cap &amp; FUP</span> <span class=\"pk-8\">24/7 HelpDesk Support</span></div>', 'Most popular broadband internet package in Dhaka city.', '<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">Smile Silver is the most affordable and popular broadband internet package in the broadband users communities in Bangladesh. You will get 15Mbps True internet/ IIG/ Raw bandwidth speed, which has been designed to ensure smooth browsing experience on international websites, uninterrupted HD video calling, bufferless OTT streaming such as Netflix, Amazon Prime with unlimited browsing and downloading. The most unique thing is that, Smile ensures the package declared speed 24 hours accurately, which is our core commitment to our broadband users.</span></p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\">&nbsp;</p>\r\n<p dir=\"ltr\" style=\"line-height: 1.38; text-align: justify; margin-top: 0pt; margin-bottom: 0pt;\"><span style=\"font-size: 11pt; font-family: Arial; color: #000000; background-color: transparent; font-weight: 400; font-style: normal; font-variant: normal; text-decoration: none; vertical-align: baseline; white-space: pre-wrap;\">The Smile Ek Desh P2 package is designed to provide a smooth experience in all regular types of internet usages such as watching online videos, video conferencing, uploading and downloading files etc. With 30Mbps BDIX speed, users will enjoy bufferless video contents on YouTube, Facebook and other social media on any devices like Smart TV, PC and Smartphones. This package is considered the country\'s cheapest broadband internet package comparing the cost vs the bandwidth speed.</span></p>', NULL, NULL, 'ek-desh-p2', '10Mbps Broadband Internet Package', NULL, NULL, 'Smile Broadband | 15Mbps True Internet Bandwidth | Accurate Speed 24/7', NULL, NULL, 6, 1, 4, 4, '2022-11-21 04:27:31', '2022-11-22 04:36:21', 0, '<div>Shared Ratio 1:8</div>', '<div>Fiber Optic Connection</div>');

-- --------------------------------------------------------

--
-- Table structure for table `package_categories`
--

CREATE TABLE `package_categories` (
  `id` int UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int NOT NULL,
  `status` int NOT NULL DEFAULT '0',
  `created_by` int NOT NULL,
  `last_updated_by` int DEFAULT NULL,
  `short_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `detailed_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `slug` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `show_in_homepage` tinyint UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `package_categories`
--

INSERT INTO `package_categories` (`id`, `title`, `order`, `status`, `created_by`, `last_updated_by`, `short_description`, `detailed_description`, `created_at`, `updated_at`, `slug`, `show_in_homepage`) VALUES
(1, 'Regular', 1, 1, 1, 3, '', '', NULL, NULL, '', 0),
(2, 'Community', 2, 1, 1, 1, '', '', NULL, NULL, '', 0),
(3, 'Ek Desh Ek Rate', 3, 1, 3, 4, '<p>Our shared connections feel like dedicated ones because we deliver package-wise committed bandwidth to <br>each and every users no matter how many users are active in the network.</p>', '<p>Our shared connections feel like dedicated ones because we deliver package-wise committed bandwidth to each and every users no matter how many users are active in the network. Our shared connections feel like dedicated ones because we deliver package-wise committed bandwidth to each and every users no matter how many users are active in the network. Ournections feel like dedicated ones because we deliver package-wise committed bandwidth to each and every u matter how many users are active in the network.</p>', NULL, '2022-11-21 04:48:10', 'ek-desh-ek-rate', 0),
(4, 'Standard', 4, 1, 4, 4, '<div>Our shared connections feel like dedicated ones because we deliver package-wise committed bandwidth to&nbsp;</div>\r\n<div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;each and every users no matter how many users are active in the network.</div>', '<div>Our shared connections feel like dedicated ones because we deliver package-wise committed bandwidth to each and every users no matter how many users are active in the network. Our shared connections feel like dedicated ones because we deliver package-wise committed bandwidth to each and every users no matter how many users are active in the network. Ournections feel like dedicated ones because we deliver package-wise committed bandwidth to each and every u</div>\r\n<div>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; matter how many users are active in the network.</div>', '2022-11-08 05:37:40', '2022-11-09 04:20:21', 'standard', 1);

-- --------------------------------------------------------

--
-- Table structure for table `package_faqs`
--

CREATE TABLE `package_faqs` (
  `id` int UNSIGNED NOT NULL,
  `package_id` int NOT NULL,
  `parent_id` int DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int NOT NULL,
  `status` int NOT NULL DEFAULT '0',
  `created_by` int NOT NULL,
  `last_updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `package_faqs`
--

INSERT INTO `package_faqs` (`id`, `package_id`, `parent_id`, `title`, `description`, `order`, `status`, `created_by`, `last_updated_by`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt?', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 2, 1, 1, 3, '2021-08-02 11:50:57', '2021-09-29 05:43:05'),
(2, 1, NULL, '2Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt?', '<p>2Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 3, 1, 1, 3, '2021-08-02 11:50:57', '2021-09-29 05:43:05'),
(5, 2, NULL, 'Gold:Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt?', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 1, 1, 1, 1, '2021-08-04 02:34:00', '2021-09-01 02:49:25'),
(6, 2, NULL, 'Gold:Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt?', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 2, 1, 1, 1, '2021-08-04 02:35:18', '2021-09-01 02:49:39'),
(7, 1, NULL, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur et.', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent venenatis iaculis magna, a hendrerit enim semper pharetra. Sed lectus erat, viverra eget posuere in, mollis nec est. Curabitur faucibus diam quis diam congue, eget hendrerit turpis vehicula. Nam condimentum risus in enim consequat, non maximus erat ultricies. Orci varius natoque.</p>', 4, 1, 1, 3, '2021-09-01 00:31:57', '2021-09-29 05:43:05'),
(8, 1, NULL, 'id aliquet lectus proin nibh nisl condimentum id venenatis a condimentum vitae', '<p>id leo in vitae turpis massa sed elementum tempus egestas sed sed risus pretium quam vulputate dignissim suspendisse in est ante in nibh mauris cursus mattis molestie a iaculis at erat pellentesque adipiscing commodo elit</p>', 1, 1, 1, 3, '2021-09-01 00:35:16', '2021-09-29 05:43:05'),
(9, 1, NULL, 'egestas tellus rutrum tellus pellentesque eu tincidunt tortor', '<p>tincidunt nunc pulvinar sapien et ligula ullamcorper malesuada proin libero nunc consequat interdum varius sit amet mattis vulputate enim nulla aliquet porttitor lacus luctus accumsan tortor posuere ac ut consequat</p>', 5, 1, 1, NULL, '2021-09-01 00:35:59', '2021-09-01 00:35:59'),
(10, 1, NULL, 'eget dolor morbi non arcu risus quis varius quam quisque', '<p>interdum velit euismod in pellentesque massa placerat duis ultricies lacus sed turpis tincidunt id aliquet risus feugiat in ante metus dictum at tempor commodo ullamcorper</p>', 6, 1, 1, NULL, '2021-09-01 00:36:33', '2021-09-01 00:36:33'),
(11, 1, NULL, 'euismod nisi porta lorem mollis aliquam ut porttitor leo a', '<p>sagittis vitae et leo duis ut diam quam nulla porttitor massa id neque aliquam vestibulum morbi blandit cursus risus at ultrices mi tempus imperdiet nulla malesuada pellentesque elit eget gravida cum sociis natoque penatibus et&nbsp;</p>\r\n<p>magnis dis parturient montes nascetur ridiculus mus mauris vitae ultricies leo integer malesuada nunc vel</p>', 7, 1, 1, NULL, '2021-09-01 00:37:12', '2021-09-01 00:37:12'),
(22, 5, NULL, 'Is this a shared package?', '<p>asas</p>', 8, 1, 4, NULL, '2022-11-23 22:02:08', '2022-11-23 22:02:08'),
(23, 5, NULL, 'Does Smile Broadband have FTP servers?', '<p>asdjasjd</p>', 9, 1, 4, NULL, '2022-11-23 22:02:24', '2022-11-23 22:02:24'),
(24, 5, NULL, 'Is there any installation charge for this package?', '<p>sadkaskld</p>', 10, 1, 4, NULL, '2022-11-23 22:02:42', '2022-11-23 22:02:42'),
(25, 5, NULL, 'What kind of IP do you provide with this package? Shared IP or Real IP?', '<p>sdfdsfzd</p>', 11, 1, 4, NULL, '2022-11-23 22:03:03', '2022-11-23 22:03:03'),
(26, 5, NULL, 'How much speed will I get when browsing and downloading from an international site?', '<p>asjkdvkasbdjlasbkd</p>', 12, 1, 4, NULL, '2022-11-23 22:03:46', '2022-11-23 22:03:46'),
(27, 9, NULL, 'Does Smile Broadband have FTP servers?', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 13, 1, 4, NULL, '2022-11-28 02:29:05', '2022-11-28 02:29:05'),
(28, 9, NULL, 'What Are The Bill Payment Options?', '<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.</p>', 14, 1, 4, NULL, '2022-11-28 02:29:35', '2022-11-28 02:29:35'),
(29, 9, NULL, 'Is there any installation charge for new connectivity?', '<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.</p>', 15, 1, 4, NULL, '2022-11-28 02:30:19', '2022-11-28 02:30:19'),
(30, 9, NULL, 'Is there any Data Cap or Fair Usage Policy (FUP)?', '<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.</p>', 16, 1, 4, NULL, '2022-11-28 02:30:50', '2022-11-28 02:30:50');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int UNSIGNED NOT NULL,
  `author_id` int NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meta_keywords` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` enum('ACTIVE','INACTIVE') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'INACTIVE',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `author_id`, `title`, `excerpt`, `body`, `image`, `slug`, `meta_description`, `meta_keywords`, `status`, `created_at`, `updated_at`) VALUES
(1, 0, 'Hello World', 'Hang the jib grog grog blossom grapple dance the hempen jig gangway pressgang bilge rat to go on account lugger. Nelsons folly gabion line draught scallywag fire ship gaff fluke fathom case shot. Sea Legs bilge rat sloop matey gabion long clothes run a shot across the bow Gold Road cog league.', '<p>Hello World. Scallywag grog swab Cat o\'nine tails scuttle rigging hardtack cable nipper Yellow Jack. Handsomely spirits knave lad killick landlubber or just lubber deadlights chantey pinnace crack Jennys tea cup. Provost long clothes black spot Yellow Jack bilged on her anchor league lateen sail case shot lee tackle.</p>\n<p>Ballast spirits fluke topmast me quarterdeck schooner landlubber or just lubber gabion belaying pin. Pinnace stern galleon starboard warp carouser to go on account dance the hempen jig jolly boat measured fer yer chains. Man-of-war fire in the hole nipperkin handsomely doubloon barkadeer Brethren of the Coast gibbet driver squiffy.</p>', 'pages/page1.jpg', 'hello-world', 'Yar Meta Description', 'Keyword1, Keyword2', 'ACTIVE', '2021-07-19 01:13:04', '2021-07-19 01:13:04');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint UNSIGNED NOT NULL,
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `table_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `key`, `table_name`, `created_at`, `updated_at`) VALUES
(1, 'browse_admin', NULL, '2021-07-19 01:12:53', '2021-07-19 01:12:53'),
(2, 'browse_bread', NULL, '2021-07-19 01:12:53', '2021-07-19 01:12:53'),
(3, 'browse_database', NULL, '2021-07-19 01:12:53', '2021-07-19 01:12:53'),
(4, 'browse_media', NULL, '2021-07-19 01:12:53', '2021-07-19 01:12:53'),
(5, 'browse_compass', NULL, '2021-07-19 01:12:53', '2021-07-19 01:12:53'),
(6, 'browse_menus', 'menus', '2021-07-19 01:12:53', '2021-07-19 01:12:53'),
(7, 'read_menus', 'menus', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(8, 'edit_menus', 'menus', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(9, 'add_menus', 'menus', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(10, 'delete_menus', 'menus', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(11, 'browse_roles', 'roles', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(12, 'read_roles', 'roles', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(13, 'edit_roles', 'roles', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(14, 'add_roles', 'roles', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(15, 'delete_roles', 'roles', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(16, 'browse_users', 'users', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(17, 'read_users', 'users', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(18, 'edit_users', 'users', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(19, 'add_users', 'users', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(20, 'delete_users', 'users', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(21, 'browse_settings', 'settings', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(22, 'read_settings', 'settings', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(23, 'edit_settings', 'settings', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(24, 'add_settings', 'settings', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(25, 'delete_settings', 'settings', '2021-07-19 01:12:54', '2021-07-19 01:12:54'),
(26, 'browse_categories', 'categories', '2021-07-19 01:13:01', '2021-07-19 01:13:01'),
(27, 'read_categories', 'categories', '2021-07-19 01:13:01', '2021-07-19 01:13:01'),
(28, 'edit_categories', 'categories', '2021-07-19 01:13:01', '2021-07-19 01:13:01'),
(29, 'add_categories', 'categories', '2021-07-19 01:13:01', '2021-07-19 01:13:01'),
(30, 'delete_categories', 'categories', '2021-07-19 01:13:02', '2021-07-19 01:13:02'),
(31, 'browse_posts', 'posts', '2021-07-19 01:13:03', '2021-07-19 01:13:03'),
(32, 'read_posts', 'posts', '2021-07-19 01:13:03', '2021-07-19 01:13:03'),
(33, 'edit_posts', 'posts', '2021-07-19 01:13:03', '2021-07-19 01:13:03'),
(34, 'add_posts', 'posts', '2021-07-19 01:13:03', '2021-07-19 01:13:03'),
(35, 'delete_posts', 'posts', '2021-07-19 01:13:03', '2021-07-19 01:13:03'),
(36, 'browse_pages', 'pages', '2021-07-19 01:13:04', '2021-07-19 01:13:04'),
(37, 'read_pages', 'pages', '2021-07-19 01:13:04', '2021-07-19 01:13:04'),
(38, 'edit_pages', 'pages', '2021-07-19 01:13:04', '2021-07-19 01:13:04'),
(39, 'add_pages', 'pages', '2021-07-19 01:13:04', '2021-07-19 01:13:04'),
(40, 'delete_pages', 'pages', '2021-07-19 01:13:04', '2021-07-19 01:13:04'),
(41, 'browse_hooks', NULL, '2021-07-19 01:13:07', '2021-07-19 01:13:07'),
(42, 'browse_districts', 'districts', '2021-07-29 05:03:39', '2021-07-29 05:03:39'),
(43, 'read_districts', 'districts', '2021-07-29 05:03:39', '2021-07-29 05:03:39'),
(44, 'edit_districts', 'districts', '2021-07-29 05:03:39', '2021-07-29 05:03:39'),
(45, 'add_districts', 'districts', '2021-07-29 05:03:39', '2021-07-29 05:03:39'),
(46, 'delete_districts', 'districts', '2021-07-29 05:03:39', '2021-07-29 05:03:39'),
(52, 'browse_zone_offices', 'zone_offices', '2021-07-31 22:33:55', '2021-07-31 22:33:55'),
(53, 'read_zone_offices', 'zone_offices', '2021-07-31 22:33:55', '2021-07-31 22:33:55'),
(54, 'edit_zone_offices', 'zone_offices', '2021-07-31 22:33:55', '2021-07-31 22:33:55'),
(55, 'add_zone_offices', 'zone_offices', '2021-07-31 22:33:55', '2021-07-31 22:33:55'),
(56, 'delete_zone_offices', 'zone_offices', '2021-07-31 22:33:55', '2021-07-31 22:33:55'),
(57, 'browse_network_coverages', 'network_coverages', '2021-07-31 23:37:08', '2021-07-31 23:37:08'),
(58, 'read_network_coverages', 'network_coverages', '2021-07-31 23:37:08', '2021-07-31 23:37:08'),
(59, 'edit_network_coverages', 'network_coverages', '2021-07-31 23:37:08', '2021-07-31 23:37:08'),
(60, 'add_network_coverages', 'network_coverages', '2021-07-31 23:37:08', '2021-07-31 23:37:08'),
(61, 'delete_network_coverages', 'network_coverages', '2021-07-31 23:37:08', '2021-07-31 23:37:08'),
(62, 'browse_internet_coverages', 'internet_coverages', '2021-07-31 23:52:09', '2021-07-31 23:52:09'),
(63, 'read_internet_coverages', 'internet_coverages', '2021-07-31 23:52:09', '2021-07-31 23:52:09'),
(64, 'edit_internet_coverages', 'internet_coverages', '2021-07-31 23:52:09', '2021-07-31 23:52:09'),
(65, 'add_internet_coverages', 'internet_coverages', '2021-07-31 23:52:09', '2021-07-31 23:52:09'),
(66, 'delete_internet_coverages', 'internet_coverages', '2021-07-31 23:52:09', '2021-07-31 23:52:09'),
(67, 'browse_service_values', 'service_values', '2021-08-01 00:08:07', '2021-08-01 00:08:07'),
(68, 'read_service_values', 'service_values', '2021-08-01 00:08:07', '2021-08-01 00:08:07'),
(69, 'edit_service_values', 'service_values', '2021-08-01 00:08:07', '2021-08-01 00:08:07'),
(70, 'add_service_values', 'service_values', '2021-08-01 00:08:07', '2021-08-01 00:08:07'),
(71, 'delete_service_values', 'service_values', '2021-08-01 00:08:07', '2021-08-01 00:08:07'),
(72, 'browse_package_categories', 'package_categories', '2021-08-01 03:08:18', '2021-08-01 03:08:18'),
(73, 'read_package_categories', 'package_categories', '2021-08-01 03:08:18', '2021-08-01 03:08:18'),
(74, 'edit_package_categories', 'package_categories', '2021-08-01 03:08:18', '2021-08-01 03:08:18'),
(75, 'add_package_categories', 'package_categories', '2021-08-01 03:08:18', '2021-08-01 03:08:18'),
(76, 'delete_package_categories', 'package_categories', '2021-08-01 03:08:18', '2021-08-01 03:08:18'),
(77, 'browse_packages', 'packages', '2021-08-01 05:31:40', '2021-08-01 05:31:40'),
(78, 'read_packages', 'packages', '2021-08-01 05:31:40', '2021-08-01 05:31:40'),
(79, 'edit_packages', 'packages', '2021-08-01 05:31:40', '2021-08-01 05:31:40'),
(80, 'add_packages', 'packages', '2021-08-01 05:31:40', '2021-08-01 05:31:40'),
(81, 'delete_packages', 'packages', '2021-08-01 05:31:40', '2021-08-01 05:31:40'),
(82, 'browse_slideshow', 'slideshow', '2021-08-05 05:40:21', '2021-08-05 05:40:21'),
(83, 'read_slideshow', 'slideshow', '2021-08-05 05:40:21', '2021-08-05 05:40:21'),
(84, 'edit_slideshow', 'slideshow', '2021-08-05 05:40:21', '2021-08-05 05:40:21'),
(85, 'add_slideshow', 'slideshow', '2021-08-05 05:40:21', '2021-08-05 05:40:21'),
(86, 'delete_slideshow', 'slideshow', '2021-08-05 05:40:21', '2021-08-05 05:40:21'),
(92, 'browse_slideshows', 'slideshows', '2021-08-05 05:50:16', '2021-08-05 05:50:16'),
(93, 'read_slideshows', 'slideshows', '2021-08-05 05:50:16', '2021-08-05 05:50:16'),
(94, 'edit_slideshows', 'slideshows', '2021-08-05 05:50:16', '2021-08-05 05:50:16'),
(95, 'add_slideshows', 'slideshows', '2021-08-05 05:50:16', '2021-08-05 05:50:16'),
(96, 'delete_slideshows', 'slideshows', '2021-08-05 05:50:16', '2021-08-05 05:50:16'),
(97, 'browse_solution_requirement_types', 'solution_requirement_types', '2021-08-18 04:23:22', '2021-08-18 04:23:22'),
(98, 'read_solution_requirement_types', 'solution_requirement_types', '2021-08-18 04:23:22', '2021-08-18 04:23:22'),
(99, 'edit_solution_requirement_types', 'solution_requirement_types', '2021-08-18 04:23:22', '2021-08-18 04:23:22'),
(100, 'add_solution_requirement_types', 'solution_requirement_types', '2021-08-18 04:23:22', '2021-08-18 04:23:22'),
(101, 'delete_solution_requirement_types', 'solution_requirement_types', '2021-08-18 04:23:22', '2021-08-18 04:23:22'),
(102, 'browse_solution_requests', 'solution_requests', '2021-08-22 03:05:59', '2021-08-22 03:05:59'),
(103, 'read_solution_requests', 'solution_requests', '2021-08-22 03:05:59', '2021-08-22 03:05:59'),
(104, 'edit_solution_requests', 'solution_requests', '2021-08-22 03:05:59', '2021-08-22 03:05:59'),
(105, 'add_solution_requests', 'solution_requests', '2021-08-22 03:05:59', '2021-08-22 03:05:59'),
(106, 'delete_solution_requests', 'solution_requests', '2021-08-22 03:05:59', '2021-08-22 03:05:59'),
(107, 'browse_contents', 'contents', '2021-08-28 22:41:46', '2021-08-28 22:41:46'),
(108, 'read_contents', 'contents', '2021-08-28 22:41:46', '2021-08-28 22:41:46'),
(109, 'edit_contents', 'contents', '2021-08-28 22:41:46', '2021-08-28 22:41:46'),
(110, 'add_contents', 'contents', '2021-08-28 22:41:46', '2021-08-28 22:41:46'),
(111, 'delete_contents', 'contents', '2021-08-28 22:41:46', '2021-08-28 22:41:46'),
(112, 'browse_problem_types', 'problem_types', '2021-09-07 06:00:13', '2021-09-07 06:00:13'),
(113, 'read_problem_types', 'problem_types', '2021-09-07 06:00:13', '2021-09-07 06:00:13'),
(114, 'edit_problem_types', 'problem_types', '2021-09-07 06:00:13', '2021-09-07 06:00:13'),
(115, 'add_problem_types', 'problem_types', '2021-09-07 06:00:13', '2021-09-07 06:00:13'),
(116, 'delete_problem_types', 'problem_types', '2021-09-07 06:00:13', '2021-09-07 06:00:13'),
(117, 'browse_customers', 'customers', '2022-11-09 00:04:50', '2022-11-09 00:04:50'),
(118, 'read_customers', 'customers', '2022-11-09 00:04:50', '2022-11-09 00:04:50'),
(119, 'edit_customers', 'customers', '2022-11-09 00:04:50', '2022-11-09 00:04:50'),
(120, 'add_customers', 'customers', '2022-11-09 00:04:50', '2022-11-09 00:04:50'),
(121, 'delete_customers', 'customers', '2022-11-09 00:04:50', '2022-11-09 00:04:50'),
(122, 'browse_customer_reviews', 'customer_reviews', '2022-11-09 00:40:57', '2022-11-09 00:40:57'),
(123, 'read_customer_reviews', 'customer_reviews', '2022-11-09 00:40:57', '2022-11-09 00:40:57'),
(124, 'edit_customer_reviews', 'customer_reviews', '2022-11-09 00:40:57', '2022-11-09 00:40:57'),
(125, 'add_customer_reviews', 'customer_reviews', '2022-11-09 00:40:57', '2022-11-09 00:40:57'),
(126, 'delete_customer_reviews', 'customer_reviews', '2022-11-09 00:40:57', '2022-11-09 00:40:57'),
(127, 'browse_social_media', 'social_media', '2022-11-10 00:21:27', '2022-11-10 00:21:27'),
(128, 'read_social_media', 'social_media', '2022-11-10 00:21:27', '2022-11-10 00:21:27'),
(129, 'edit_social_media', 'social_media', '2022-11-10 00:21:27', '2022-11-10 00:21:27'),
(130, 'add_social_media', 'social_media', '2022-11-10 00:21:27', '2022-11-10 00:21:27'),
(131, 'delete_social_media', 'social_media', '2022-11-10 00:21:27', '2022-11-10 00:21:27'),
(137, 'browse_brands', 'brands', '2022-11-10 06:59:33', '2022-11-10 06:59:33'),
(138, 'read_brands', 'brands', '2022-11-10 06:59:33', '2022-11-10 06:59:33'),
(139, 'edit_brands', 'brands', '2022-11-10 06:59:33', '2022-11-10 06:59:33'),
(140, 'add_brands', 'brands', '2022-11-10 06:59:33', '2022-11-10 06:59:33'),
(141, 'delete_brands', 'brands', '2022-11-10 06:59:33', '2022-11-10 06:59:33'),
(142, 'browse_brand_categories', 'brand_categories', '2022-11-10 07:09:28', '2022-11-10 07:09:28'),
(143, 'read_brand_categories', 'brand_categories', '2022-11-10 07:09:28', '2022-11-10 07:09:28'),
(144, 'edit_brand_categories', 'brand_categories', '2022-11-10 07:09:28', '2022-11-10 07:09:28'),
(145, 'add_brand_categories', 'brand_categories', '2022-11-10 07:09:28', '2022-11-10 07:09:28'),
(146, 'delete_brand_categories', 'brand_categories', '2022-11-10 07:09:28', '2022-11-10 07:09:28');

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`permission_id`, `role_id`) VALUES
(1, 1),
(1, 3),
(2, 1),
(3, 1),
(4, 1),
(4, 3),
(5, 1),
(6, 1),
(6, 3),
(7, 1),
(7, 3),
(8, 1),
(8, 3),
(9, 1),
(9, 3),
(10, 1),
(10, 3),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(21, 1),
(21, 3),
(22, 1),
(22, 3),
(23, 1),
(23, 3),
(24, 1),
(25, 1),
(26, 1),
(26, 3),
(27, 1),
(27, 3),
(28, 1),
(28, 3),
(29, 1),
(29, 3),
(30, 1),
(30, 3),
(31, 1),
(31, 3),
(32, 1),
(32, 3),
(33, 1),
(33, 3),
(34, 1),
(34, 3),
(35, 1),
(35, 3),
(36, 1),
(37, 1),
(38, 1),
(39, 1),
(40, 1),
(41, 1),
(42, 1),
(42, 3),
(43, 1),
(43, 3),
(44, 1),
(44, 3),
(45, 1),
(45, 3),
(46, 1),
(46, 3),
(52, 1),
(52, 3),
(53, 1),
(53, 3),
(54, 1),
(54, 3),
(55, 1),
(55, 3),
(56, 1),
(56, 3),
(57, 1),
(57, 3),
(58, 1),
(58, 3),
(59, 1),
(59, 3),
(60, 1),
(60, 3),
(61, 1),
(61, 3),
(62, 1),
(62, 3),
(63, 1),
(63, 3),
(64, 1),
(64, 3),
(65, 1),
(65, 3),
(66, 1),
(66, 3),
(67, 1),
(67, 3),
(68, 1),
(68, 3),
(69, 1),
(69, 3),
(70, 1),
(70, 3),
(71, 1),
(71, 3),
(72, 1),
(72, 3),
(73, 1),
(73, 3),
(74, 1),
(74, 3),
(75, 1),
(75, 3),
(76, 1),
(76, 3),
(77, 1),
(77, 3),
(78, 1),
(78, 3),
(79, 1),
(79, 3),
(80, 1),
(80, 3),
(81, 1),
(81, 3),
(82, 1),
(83, 1),
(84, 1),
(85, 1),
(86, 1),
(92, 1),
(92, 3),
(93, 1),
(93, 3),
(94, 1),
(94, 3),
(95, 1),
(95, 3),
(96, 1),
(96, 3),
(97, 1),
(97, 3),
(98, 1),
(98, 3),
(99, 1),
(99, 3),
(100, 1),
(100, 3),
(101, 1),
(101, 3),
(102, 1),
(102, 3),
(103, 1),
(103, 3),
(104, 1),
(105, 1),
(106, 1),
(107, 1),
(107, 3),
(108, 1),
(108, 3),
(109, 1),
(109, 3),
(110, 1),
(110, 3),
(111, 1),
(111, 3),
(112, 1),
(112, 3),
(113, 1),
(113, 3),
(114, 1),
(114, 3),
(115, 1),
(115, 3),
(116, 1),
(116, 3),
(117, 1),
(118, 1),
(119, 1),
(120, 1),
(121, 1),
(122, 1),
(123, 1),
(124, 1),
(125, 1),
(126, 1),
(127, 1),
(128, 1),
(129, 1),
(130, 1),
(131, 1),
(137, 1),
(138, 1),
(139, 1),
(140, 1),
(141, 1),
(142, 1),
(143, 1),
(144, 1),
(145, 1),
(146, 1);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int UNSIGNED NOT NULL,
  `author_id` int NOT NULL,
  `category_id` int DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `seo_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meta_keywords` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `og_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `og_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('PUBLISHED','DRAFT','PENDING') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DRAFT',
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `author_id`, `category_id`, `title`, `seo_title`, `excerpt`, `body`, `image`, `slug`, `meta_description`, `meta_keywords`, `og_title`, `og_description`, `og_image`, `status`, `featured`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'This is the first blog post of smile', NULL, 'This is the excerpt for the Lorem Ipsum Post', '<div class=\"container-fluid\">\r\n<div class=\"row\">\r\n<div class=\"col-12\"><strong>what is lorem ipsum?</strong></div>\r\n<div class=\"col-12\">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.</div>\r\n<div class=\"col-12\"><strong>what is lorem ipsum?</strong></div>\r\n<ul>\r\n<li>Can we do it?</li>\r\n<li>Yes we can</li>\r\n<li>option three</li>\r\n<li>This is the last option</li>\r\n</ul>\r\n<div class=\"col-12\">&nbsp;</div>\r\n<div class=\"col-12\">&nbsp;</div>\r\n<div class=\"col-12\"><img class=\"rounded mx-auto d-block float-md-end s-p-8\" src=\"http://smilewww.mybdcom.com/storage/contents/dummy-400.jpg\" srcset=\"\" alt=\"\" />\r\n<p style=\"text-align: justify;\"><strong>what is lorem ipsum?</strong></p>\r\n<p style=\"text-align: justify;\">viverra ipsum nunc aliquet bibendum enim facilisis gravida neque convallis a cras semper auctor neque vitae tempus quam pellentesque nec nam aliquam sem et tortor consequat id porta nibh venenatis cras sed felis eget velit aliquet sagittis id consectetur purus ut faucibus pulvinar elementum integer enim neque volutpat ac tincidunt vitae semper quis lectus nulla at volutpat diam ut venenatis tellus in metus vulputate eu scelerisque felis imperdiet proin fermentum leo vel orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero id faucibus nisl tincidunt eget nullam non nisi est sit amet facilisis magna etiam tempor orci eu lobortis.</p>\r\n<p style=\"text-align: justify;\">sed blandit libero volutpat sed cras ornare arcu dui vivamus arcu felis bibendum ut tristique et egestas quis ipsum suspendisse ultrices gravida dictum fusce ut placerat orci nulla pellentesque dignissim enim sit amet venenatis urna cursus eget nunc scelerisque viverra mauris in aliquam sem fringilla ut morbi tincidunt augue interdum velit&nbsp;euismod in pellentesque massa placerat duis ultricies lacus sed turpis tincidunt id aliquet risus feugiat in ante metus dictum at tempor commodo ullamcorper a lacus vestibulum sed arcu non odio euismod lacinia at quis risus sed vulputate odio ut enim blandit volutpat maecenas volutpat blandit aliquam etiam erat velit.</p>\r\n<p style=\"text-align: justify;\">eu tincidunt tortor aliquam nulla facilisi cras fermentum odio eu feugiat pretium nibh ipsum consequat nisl vel pretium lectus quam id leo in vitae turpis massa sed elementum tempus egestas sed sed risus pretium quam vulputate dignissim suspendisse in est ante in nibh mauris cursus mattis molestie a iaculis at erat pellentesque adipiscing commodo elit at imperdiet dui accumsan sit amet nulla facilisi morbi tempus iaculis urna id volutpat lacus laoreet non curabitur gravida arcu ac tortor dignissim convallis aenean et tortor at risus viverra adipiscing at in tellus integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque sit.</p>\r\n<p style=\"text-align: justify;\">viverra ipsum nunc aliquet bibendum enim facilisis gravida neque convallis a cras semper auctor neque vitae tempus quam pellentesque nec nam aliquam sem et tortor consequat id porta nibh venenatis cras sed felis eget velit aliquet sagittis id consectetur purus ut faucibus pulvinar elementum integer enim neque volutpat ac tincidunt vitae semper quis lectus nulla at volutpat diam ut venenatis tellus in metus vulputate eu scelerisque felis imperdiet proin fermentum leo vel orci porta non pulvinar neque laoreet suspendisse interdum consectetur libero id faucibus nisl tincidunt eget nullam non nisi est sit amet facilisis magna etiam tempor orci eu lobortis.</p>\r\n<iframe class=\"mx-auto d-block float-md-start s-p-8\" title=\"YouTube video player\" src=\"https://www.youtube.com/embed/le5TKFR2T84\" width=\"560\" height=\"315\" frameborder=\"0\" allowfullscreen=\"\"></iframe>\r\n<p style=\"text-align: justify;\">sed blandit libero volutpat sed cras ornare arcu dui vivamus arcu felis bibendum ut tristique et egestas quis ipsum suspendisse ultrices gravida dictum fusce ut placerat orci nulla pellentesque dignissim enim sit amet venenatis urna cursus eget nunc scelerisque viverra mauris in aliquam sem fringilla ut morbi tincidunt augue interdum velit euismod in pellentesque massa placerat duis ultricies lacus sed turpis tincidunt id aliquet risus feugiat in ante metus dictum at tempor commodo ullamcorper a lacus vestibulum sed arcu non odio euismod lacinia at quis risus sed vulputate odio ut enim blandit volutpat maecenas volutpat blandit aliquam etiam erat velit.</p>\r\n<p style=\"text-align: justify;\">eu tincidunt tortor aliquam nulla facilisi cras fermentum odio eu feugiat pretium nibh ipsum consequat nisl vel pretium lectus quam id leo in vitae turpis massa sed elementum tempus egestas sed sed risus pretium quam vulputate dignissim suspendisse in est ante in nibh mauris cursus mattis molestie a iaculis at erat pellentesque adipiscing commodo elit at imperdiet dui accumsan sit amet nulla facilisi morbi tempus iaculis urna id volutpat lacus laoreet non curabitur gravida arcu ac tortor dignissim convallis aenean et tortor at risus viverra adipiscing at in tellus integer feugiat scelerisque varius morbi enim nunc faucibus a pellentesque sit.</p>\r\n</div>\r\n</div>\r\n</div>', 'posts/post1.jpg', 'this-is-the-first-blog-post-of-smile', 'This is the meta description', 'keyword1, keyword2, keyword3', 'Og Title', 'Og Description', 'posts/post1-cropped.jpg', 'PUBLISHED', 0, '2021-07-19 01:13:03', '2021-10-27 02:38:44'),
(2, 1, 2, 'My Sample Post', NULL, 'This is the excerpt for the sample Post', '<p>This is the body for the sample post, which includes the body.</p>\r\n<h2>We can use all kinds of format!</h2>\r\n<p>And include a bunch of other stuff.</p>', 'posts/post2.jpg', 'my-sample-post', 'Meta Description for sample post', 'keyword1, keyword2, keyword3', 'Og Title', 'Og Description', 'posts/post2-medium.jpg', 'PUBLISHED', 0, '2021-07-19 01:13:04', '2021-09-09 00:49:10'),
(3, 1, 1, 'Latest Post', NULL, 'This is the excerpt for the latest post', '<p>This is the body for the latest post</p>', 'posts/post3.jpg', 'latest-post', 'This is the meta description', 'keyword1, keyword2, keyword3', 'Og Title', 'Og Description', 'posts/post3-medium.jpg', 'PUBLISHED', 0, '2021-07-19 01:13:05', '2021-09-09 00:49:59'),
(4, 1, 2, 'Yarr Post', NULL, 'Reef sails nipperkin bring a spring upon her cable coffer jury mast spike marooned Pieces of Eight poop deck pillage. Clipper driver coxswain galleon hempen halter come about pressgang gangplank boatswain swing the lead. Nipperkin yard skysail swab lanyard Blimey bilge water ho quarter Buccaneer.', '<p>Swab deadlights Buccaneer fire ship square-rigged dance the hempen jig weigh anchor cackle fruit grog furl. Crack Jennys tea cup chase guns pressgang hearties spirits hogshead Gold Road six pounders fathom measured fer yer chains. Main sheet provost come about trysail barkadeer crimp scuttle mizzenmast brig plunder.</p>\r\n<p>Mizzen league keelhaul galleon tender cog chase Barbary Coast doubloon crack Jennys tea cup. Blow the man down lugsail fire ship pinnace cackle fruit line warp Admiral of the Black strike colors doubloon. Tackle Jack Ketch come about crimp rum draft scuppers run a shot across the bow haul wind maroon.</p>\r\n<p>Interloper heave down list driver pressgang holystone scuppers tackle scallywag bilged on her anchor. Jack Tar interloper draught grapple mizzenmast hulk knave cable transom hogshead. Gaff pillage to go on account grog aft chase guns piracy yardarm knave clap of thunder.</p>', 'posts/post4.jpg', 'yarr-post', 'this be a meta descript', 'keyword1, keyword2, keyword3', 'Og Title', 'Og Description', 'posts/post4-medium.jpg', 'PUBLISHED', 0, '2021-07-19 01:13:06', '2021-09-09 00:51:16'),
(5, 3, 1, 'Blog Category 3 Title', 'Category 3', 'Small description of this post Blog Category 3 Title', '<p><span style=\"color: #000000; font-family: \'Open Sans\', Arial, sans-serif; text-align: justify;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p>\r\n<figure class=\"image\"><img title=\"Cat 3\" src=\"http://smilewww.mybdcom.com/storage/posts/October2021/free-ceo-success-powerpoint-template.jpg\" alt=\"Cat 3\" width=\"400\" height=\"400\" />\r\n<figcaption>Caption</figcaption>\r\n</figure>\r\n<p>&nbsp;</p>\r\n<p><span style=\"color: #000000; font-family: \'Open Sans\', Arial, sans-serif; text-align: justify;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p>', 'posts/October2021/W9aCPEB07msjTCUT50e4.jpg', 'blog-category-3-title', 'Category 3', 'Category 3', 'Category 3', 'Category 3', 'posts/post1-cropped.jpg', 'PUBLISHED', 0, '2021-10-27 02:45:14', '2021-10-27 02:45:14');

-- --------------------------------------------------------

--
-- Table structure for table `problem_types`
--

CREATE TABLE `problem_types` (
  `id` int UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `concern_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int NOT NULL DEFAULT '0',
  `created_by` int NOT NULL,
  `last_updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `problem_types`
--

INSERT INTO `problem_types` (`id`, `title`, `concern_email`, `status`, `created_by`, `last_updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Problem 1', 'test@test.com', 1, 1, NULL, '2021-09-07 06:05:53', '2021-09-07 06:05:53'),
(2, 'Problem 2', 'test@test.com', 1, 1, NULL, '2021-09-07 06:06:04', '2021-09-07 06:06:04'),
(3, 'Problem 3', 'test@test.com', 1, 1, NULL, '2021-09-07 06:06:19', '2021-09-07 06:06:19');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Administrator', '2021-07-19 01:12:53', '2021-07-19 01:12:53'),
(2, 'user', 'Normal User', '2021-07-19 01:12:53', '2021-07-19 01:12:53'),
(3, 'moderator', 'Site Moderator', '2021-09-12 03:02:39', '2021-09-12 03:02:39');

-- --------------------------------------------------------

--
-- Table structure for table `service_values`
--

CREATE TABLE `service_values` (
  `id` int UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int NOT NULL,
  `status` int NOT NULL DEFAULT '0',
  `created_by` int NOT NULL,
  `last_updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service_values`
--

INSERT INTO `service_values` (`id`, `title`, `description`, `logo`, `order`, `status`, `created_by`, `last_updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Fiber Optic Connectivity', 'We connect our users with high quality fiber optic cable.', 'service-values/November2022/3ofU2mxqwqXPdwP8Au3m.png', 1, 1, 1, 4, '2021-08-01 02:47:46', '2022-11-09 06:01:15'),
(2, 'No Peak No Off-Peak', 'Our users enjoy same bandwidth speed 24 hours.', 'service-values/November2022/XTzUIrYxJkfLoGBDwdpo.png', 2, 1, 1, 4, '2021-08-01 02:48:45', '2022-11-09 06:06:18'),
(3, 'Unlimited Data', 'Enjoy unlimited upload and download at accurate speed.', 'service-values/November2022/T9HtXNMyNm2UdpvmqUfd.png', 3, 1, 1, 4, '2021-08-01 02:49:20', '2022-11-09 06:06:56'),
(4, '24/7 Helpdesk Support', 'Our engineers are committed to assist whenver you need.', 'service-values/November2022/GKjOnF4bJX6juokYdW2L.png', 4, 1, 4, NULL, '2022-11-09 06:08:12', '2022-11-09 06:08:12');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int UNSIGNED NOT NULL,
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int NOT NULL DEFAULT '1',
  `group` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `key`, `display_name`, `value`, `details`, `type`, `order`, `group`) VALUES
(1, 'site.title', 'Site Title', 'Smile broadband | best broadband internet service provider in bd', '', 'text', 1, 'Site'),
(2, 'site.description', 'Site Description', 'The best broadband internet service provider in Bangladesh that provides broadband packages at best price with accurate bandwidth speed 24/7.', '', 'text', 2, 'Site'),
(3, 'site.logo', 'Site Logo', 'settings/November2022/lUFORhz0U2Jwux22ge14.png', '', 'image', 3, 'Site'),
(4, 'site.google_analytics_tracking_id', 'Google Analytics Tracking ID', NULL, '', 'text', 4, 'Site'),
(5, 'admin.bg_image', 'Admin Background Image', '', '', 'image', 5, 'Admin'),
(6, 'admin.title', 'Admin Title', 'Smile', '', 'text', 1, 'Admin'),
(7, 'admin.description', 'Admin Description', 'Welcome to Voyager. The Missing Admin for Laravel', '', 'text', 2, 'Admin'),
(8, 'admin.loader', 'Admin Loader', '', '', 'image', 3, 'Admin'),
(9, 'admin.icon_image', 'Admin Icon Image', 'settings/November2022/E3RiGwxTkSjfoj8g8ZC0.png', '', 'image', 4, 'Admin'),
(10, 'admin.google_analytics_client_id', 'Google Analytics Client ID (used for admin dashboard)', NULL, '', 'text', 1, 'Admin'),
(11, 'site.support_phone_number', 'Support Phone Number', '09666666666', NULL, 'text', 6, 'Site'),
(12, 'site.show_con_link_main_menu', 'Show Connectivity link on Main Menu', '1', '{\r\n    \"true\" : \"Yes\",\r\n    \"false\" : \"No\",\r\n    \"checked\" : true\r\n}', 'checkbox', 7, 'Site'),
(13, 'site.show_con_link_mm_text', 'Connectivity link Text', 'Apply for Connectivity', NULL, 'text', 8, 'Site'),
(15, 'site.show_con_link_mm_link', 'Link of Connectivity link', 'connectivity', NULL, 'text', 9, 'Site'),
(17, 'site.footer_contact_number', 'Footer contact number', '<h5 class=\"h5\"><a href=\"tel:+09666666666\">09666 666 666</a></h5>', '{\r\n    \"tinymceOptions\": {\r\n        \"height\": 200,\r\n        \"min_height\": 200\r\n    }\r\n}', 'rich_text_box', 10, 'Site'),
(18, 'site.footer_head_office_address', 'Footer head office address', '<p class=\"footer-info\">JL Bhaban (5th floor) <br>House # 1, Road # 1 <br>Gulshan Avenue, Gulshan-1 <br>Dhaka-1212, Bangladesh</p>', NULL, 'rich_text_box', 12, 'Site'),
(19, 'site.customized_solution_icon', 'Customized solution icon', 'settings/September2021/96Tfl5QKAI4eUD47vHJg.png', NULL, 'image', 15, 'Site'),
(20, 'site.customized_solution_title', 'Customized solution title', 'CUSTOMIZED BROADBAND SOLUTION', NULL, 'text', 16, 'Site'),
(21, 'site.customized_solution_description', 'Customized solution description', 'Looking for something more? Our technical experts can help!\r\nGet technical consultancy to find the best broadband solutions that suit your requirement.', NULL, 'text_area', 17, 'Site'),
(26, 'site.user_review_title', 'User Review Title', 'User Review', NULL, 'text', 22, 'Site'),
(27, 'site.user_review_description', 'User Review Description', 'It’s easy for anyone to post a comment on social media to spread disinformation. Here you can find the authentic feedbacks from the real users regarding their experience on Smile Broadband.', NULL, 'text', 23, 'Site'),
(28, 'site.coverage_area_title', 'Coverage Area Title', 'Coverage Area', NULL, 'text', 24, 'Site'),
(29, 'site.coverage_area_description', 'Coverage Area Description', 'At present Smile Broadband is available at 18 district cities. Uses the list below to find if we have coverage in your area. First select the district and then the area. If you don’t find your district or area in the list, it means we might not have coverage yet in that particular area.', NULL, 'text', 25, 'Site'),
(30, 'site.contact_form_title', 'Contact Form Title', 'Let Us Call You', NULL, 'text', 27, 'Site'),
(31, 'site.contact_form_description', 'Contact Form Description', 'Leave your name and phone number below, our team will call you immediately', NULL, 'text', 28, 'Site'),
(32, 'site.contact_form_icon', 'Contact Form Icon', 'settings/November2022/Bg1FdPj3jJ2bupGCJFcB.png', NULL, 'image', 30, 'Site'),
(33, 'site.footer_email_address', 'Footer email Address', '<h5 class=\"h5\"><a href=\"mailto:helpdesk@smile.com.bd\">helpdesk@smile.com.bd</a></h5>', NULL, 'rich_text_box', 11, 'Site'),
(34, 'site.contact_form_image', 'Contact Form Image', 'settings/November2022/a1tle4K0LHe6hlnZM3Lq.png', NULL, 'image', 31, 'Site'),
(35, 'site.description.title', 'Description TItle', '<div>You are going to</div>\r\n<div>love Smile because..&nbsp;</div>', NULL, 'rich_text_box', 13, 'Site'),
(36, 'site.description_details', 'Description details', '<p>Our shared connections feel like dedicated ones because we deliver package-wise committed bandwidth to each and every users no matter how many users are active in the network.</p>\r\n<p>You are never going to feel any speed drop unless there is a technical issue exists in your router or device, or there is a damage on the link between you and us.&nbsp;</p>\r\n<p>Don&rsquo;t Worry! We solve both issues very promptly.</p>', NULL, 'rich_text_box', 14, 'Site'),
(37, 'site.description_title', 'Description TItle', '<div>You are going to</div>\r\n<div>love Smile because..&nbsp;</div>', NULL, 'rich_text_box', 29, 'Site'),
(38, 'site.coverage_area_logo', 'Coverage Area Logo', 'settings/November2022/8trEDeu5nvCknv5G6h07.png', NULL, 'image', 26, 'Site'),
(39, 'site.home_slider_title', 'Home Slider Title', '<div>Enjoy Accurate&nbsp;</div>\r\n<div>Internet Speed 24/7</div>', NULL, 'rich_text_box', 32, 'Site'),
(40, 'site.home_slider_description', 'Home Slider Description', '<p>Slow internet speed can trouble you in your daily internet usage. So, we don&rsquo;t compromise in delivering the committed speed anytime day or night. Choose any of Smile&rsquo;s Standard Packages to enjoy package-wise accurate speed 24/7.</p>', NULL, 'rich_text_box', 33, 'Site'),
(41, 'site.faq_logo', 'FAQ logo', 'settings/November2022/yKR4dP3Ux4goFm6abljH.png', NULL, 'image', 34, 'Site'),
(42, 'site.head_office_icon', 'Head Office Icon', 'settings/November2022/eR2l7stCNoCnq5CJAqa4.png', NULL, 'image', 35, 'Site'),
(45, 'site.head_office_card_contact', 'Head Office Card Contact', '<p>JL Bhaban (5th floor)<br>House # 1, Road # 1, Gulshan-1<br>Gulshan Avenue, Dhaka - 1212, Bangladesh<br><br>+8809666 666 666<br>helpdesk@smile.com.bd</p>', NULL, 'rich_text_box', 36, 'Site');

-- --------------------------------------------------------

--
-- Table structure for table `slideshows`
--

CREATE TABLE `slideshows` (
  `id` int UNSIGNED NOT NULL,
  `image_laptop` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_tab` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_mobile` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `show_infobox` tinyint NOT NULL DEFAULT '1',
  `infobox_color` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `infobox_opacity` float DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_color` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtitle` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtitle_color` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `has_link` tinyint DEFAULT NULL,
  `link` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button_label` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button_color` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `button_opacity` float DEFAULT NULL,
  `order` int NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '0',
  `created_by` int NOT NULL,
  `last_updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `image_tab_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_big` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `slideshows`
--

INSERT INTO `slideshows` (`id`, `image_laptop`, `image_tab`, `image_mobile`, `show_infobox`, `infobox_color`, `infobox_opacity`, `title`, `title_color`, `subtitle`, `subtitle_color`, `excerpt`, `has_link`, `link`, `button_label`, `button_color`, `button_opacity`, `order`, `status`, `created_by`, `last_updated_by`, `created_at`, `updated_at`, `image_tab_2`, `image_big`) VALUES
(9, 'slideshows/Website-testing/expected-output/Output-demo-02.png', 'slideshows/Website-testing/expected-output/Output-demo-03.png', 'slideshows/Website-testing/expected-output/Output-demo-05.png', 0, '#000000', 1, NULL, '#000000', NULL, '#000000', NULL, 0, NULL, NULL, '#000000', 1, 1, 0, 3, 3, '2021-09-13 23:56:00', '2021-10-27 01:03:53', 'slideshows/Website-testing/expected-output/Output-demo-04.png', 'slideshows/Website-testing/expected-output/Output-demo-01.png'),
(10, 'slideshows/Website-testing/full-instructions/full-instructions-02.png', 'slideshows/Website-testing/full-instructions/full-instructions-03.png', 'slideshows/Website-testing/full-instructions/full-instructions-05.png', 0, '#000000', 1, NULL, '#000000', NULL, '#000000', NULL, 0, NULL, NULL, '#000000', 1, 2, 0, 3, 3, '2021-09-13 23:58:56', '2021-10-27 01:04:38', 'slideshows/Website-testing/full-instructions/full-instructions-04.png', 'slideshows/Website-testing/full-instructions/full-instructions-01.png'),
(13, 'slideshows/Website-testing/only-box-position/Box-position-0s2.png', 'slideshows/Website-testing/only-box-position/Box-position-0s3.png', 'slideshows/Website-testing/only-box-position/Box-position-0s5.png', 0, '#000000', 1, NULL, '#000000', NULL, '#000000', NULL, 0, NULL, NULL, '#000000', 1, 3, 0, 3, 3, '2021-09-14 01:32:48', '2021-10-27 01:04:48', 'slideshows/Website-testing/only-box-position/Box-position-0s4.png', 'slideshows/Website-testing/only-box-position/Box-position-0s1.png'),
(17, 'slideshows/Desktop-View-2.jpg', 'slideshows/Tablet-View-1.jpg', 'slideshows/Website-testing/Mobile-Phone.jpg', 1, '#ffffff', 0, 'No Peak No Off Peak, 24 Hours Accurate Speed', '#000000', 'Meeting our commitment is our core growth policy. So we made our commitment very short and simple. We promise to deliver package with accurate bandwidth speed to the client no matter what it takes. That is what people believe in us.', '#000000', NULL, 1, '#', 'Check our package prices', '#000000', 1, 4, 0, 3, 4, '2021-10-10 03:40:02', '2022-11-09 21:57:13', 'slideshows/Website-testing/Tablet-view-2-Portrait.jpg', 'slideshows/Website-testing/Desktop-View-1.jpg'),
(18, 'slideshows/Desktop-View-2-2nd-Banner.jpg', 'slideshows/Tablet-2nd-Banner.jpg', 'slideshows/Mobile-Phone-2nd-Banner.jpg', 1, '#ff6600', 0.5, 'Image Slider 004', '#000000', 'Image Slider 004 Image Slider 004 Image Slider 004 Image Slider 004', '#000000', 'Image Slider 004', 1, 'www.bdcom.com', 'More', '#000000', 1, 5, 0, 3, 3, '2021-10-10 03:55:18', '2021-10-27 01:04:53', 'slideshows/Tablet-2-Portrait-2nd-Banner.jpg', 'slideshows/Desktop-2nd-Banner.jpg'),
(19, 'slideshows/slider-d-1.jpg', 'slideshows/slider-m-1.jpg', 'slideshows/slider-m-1.jpg', 1, '#000000', 1, '<div>Enjoy Accurate&nbsp;</div>\r\n<div>Internet Speed 24/7</div>\r\n<div id=\"gtx-trans\" style=\"position: absolute; left: -176px; top: -14px;\">\r\n<div class=\"gtx-trans-icon\">&nbsp;</div>\r\n</div>', '#000000', NULL, '#000000', 'Slow internet speed can trouble you in your daily internet usage. So, we don’t compromise in delivering the committed speed anytime day or night. Choose any of Smile’s Standard Packages to enjoy package-wise accurate speed 24/7.', 1, '/package/standard', NULL, '#000000', 1, 7, 1, 4, 4, '2022-11-09 21:53:45', '2022-11-16 00:09:17', 'slideshows/slider-m-1.jpg', 'slideshows/slider-d-1.jpg'),
(20, 'slideshows/slider-d-2.jpg', 'slideshows/slider-m-2.jpg', 'slideshows/slider-m-2.jpg', 1, '#000000', 1, '<div>Enjoy Accurate&nbsp;</div>\r\n<div>Internet Speed 24/7</div>', '#000000', NULL, '#000000', 'Slow internet speed can trouble you in your daily internet usage. So, we don’t compromise in delivering the committed speed anytime day or night. Choose any of Smile’s Standard Packages to enjoy package-wise accurate speed 24/7.', 1, '/package/standard', NULL, '#000000', 1, 6, 1, 4, 4, '2022-11-09 22:01:08', '2022-11-16 00:09:17', 'slideshows/slider-m-2.jpg', 'slideshows/slider-d-2.jpg'),
(21, 'slideshows/slider-d-3.jpg', 'slideshows/slider-m-3.jpg', 'slideshows/slider-m-3.jpg', 1, '#000000', 1, '<div>Enjoy Accurate&nbsp;</div>\r\n<div>Internet Speed 24/7</div>', '#000000', NULL, '#000000', 'Slow internet speed can trouble you in your daily internet usage. So, we don’t compromise in delivering the committed speed anytime day or night. Choose any of Smile’s Standard Packages to enjoy package-wise accurate speed 24/7.', 1, '/package/standard', NULL, '#000000', 1, 8, 1, 4, 4, '2022-11-09 22:02:03', '2022-11-09 22:56:35', 'slideshows/slider-m-3.jpg', 'slideshows/slider-d-3.jpg'),
(22, 'slideshows/pb-beer-1513436-1600.jpg', 'slideshows/pb-beer-1513436-1600.jpg', 'slideshows/pb-beer-1513436-1600.jpg', 1, '#000000', 1, '<p>24 ঘন্টা সঠিক গতি</p>', '#000000', NULL, '#000000', 'Slow internet speed can trouble you in your daily internet usage. So, we don’t compromise in delivering the committed speed anytime day or night. Choose any of Smile’s Standard Packages to enjoy package-wise accurate speed 24/7.', 1, NULL, NULL, '#000000', 1, 9, 0, 4, 4, '2022-11-16 00:13:05', '2022-11-16 00:14:31', 'slideshows/pb-beer-1513436-1600.jpg', 'slideshows/pb-beer-1513436-1600.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `social_media`
--

CREATE TABLE `social_media` (
  `id` int UNSIGNED NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `order` int NOT NULL DEFAULT '1',
  `status` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `social_media`
--

INSERT INTO `social_media` (`id`, `title`, `url`, `icon_class`, `created_at`, `updated_at`, `order`, `status`) VALUES
(1, 'Facebook', 'https://facebook.com', 'fa-facebook', '2022-11-10 01:19:25', '2022-11-13 06:36:09', 1, 1),
(2, 'Youtube', 'https://www.youtube.com', 'fa-youtube-play', '2022-11-10 01:23:40', '2022-11-16 00:39:23', 3, 1),
(3, 'Instagram', 'https://www.instagram.com', 'fa-instagram', '2022-11-10 01:24:07', '2022-11-13 06:35:25', 2, 1),
(4, 'Linkedin', 'https://www.linkedin.com', 'fa-linkedin-in', '2022-11-10 01:24:43', '2022-11-16 00:39:23', 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `solution_requests`
--

CREATE TABLE `solution_requests` (
  `id` int UNSIGNED NOT NULL,
  `req_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `req_phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `req_email` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `solution_requirement_type_id` int NOT NULL,
  `req_details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_human_verified` tinyint NOT NULL,
  `human_verification_result` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NULL',
  `remote_addr` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NULL',
  `remote_port` int DEFAULT NULL,
  `request_scheme` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NULL',
  `request_method` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NULL',
  `platform` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NULL',
  `browser` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NULL',
  `browser_maker` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NULL',
  `browser_version` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NULL',
  `device_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NULL',
  `device_pointing_method` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `minorver` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NULL',
  `ismobiledevice` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `istablet` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `crawler` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NULL',
  `http_user_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NULL',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `solution_requirement_types`
--

CREATE TABLE `solution_requirement_types` (
  `id` int UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int UNSIGNED NOT NULL DEFAULT '0',
  `created_by` int UNSIGNED NOT NULL,
  `last_updated_by` int UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `order` int UNSIGNED NOT NULL,
  `concern_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `solution_requirement_types`
--

INSERT INTO `solution_requirement_types` (`id`, `title`, `status`, `created_by`, `last_updated_by`, `created_at`, `updated_at`, `order`, `concern_email`) VALUES
(1, 'Home Wi-Fi solution', 1, 1, 1, '2021-08-18 04:23:48', '2021-08-19 02:07:17', 1, NULL),
(2, 'Building Solution', 1, 1, 1, '2021-08-18 04:24:00', '2021-08-19 02:07:35', 2, NULL),
(3, 'Corporate solution', 1, 1, 1, '2021-08-18 04:24:56', '2021-08-19 02:07:51', 3, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `translations`
--

CREATE TABLE `translations` (
  `id` int UNSIGNED NOT NULL,
  `table_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `column_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `foreign_key` int UNSIGNED NOT NULL,
  `locale` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `translations`
--

INSERT INTO `translations` (`id`, `table_name`, `column_name`, `foreign_key`, `locale`, `value`, `created_at`, `updated_at`) VALUES
(1, 'data_types', 'display_name_singular', 5, 'pt', 'Post', '2021-07-19 01:13:04', '2021-07-19 01:13:04'),
(2, 'data_types', 'display_name_singular', 6, 'pt', 'Página', '2021-07-19 01:13:04', '2021-07-19 01:13:04'),
(3, 'data_types', 'display_name_singular', 1, 'pt', 'Utilizador', '2021-07-19 01:13:05', '2021-07-19 01:13:05'),
(4, 'data_types', 'display_name_singular', 4, 'pt', 'Categoria', '2021-07-19 01:13:05', '2021-07-19 01:13:05'),
(5, 'data_types', 'display_name_singular', 2, 'pt', 'Menu', '2021-07-19 01:13:05', '2021-07-19 01:13:05'),
(6, 'data_types', 'display_name_singular', 3, 'pt', 'Função', '2021-07-19 01:13:05', '2021-07-19 01:13:05'),
(7, 'data_types', 'display_name_plural', 5, 'pt', 'Posts', '2021-07-19 01:13:05', '2021-07-19 01:13:05'),
(8, 'data_types', 'display_name_plural', 6, 'pt', 'Páginas', '2021-07-19 01:13:05', '2021-07-19 01:13:05'),
(9, 'data_types', 'display_name_plural', 1, 'pt', 'Utilizadores', '2021-07-19 01:13:05', '2021-07-19 01:13:05'),
(10, 'data_types', 'display_name_plural', 4, 'pt', 'Categorias', '2021-07-19 01:13:05', '2021-07-19 01:13:05'),
(11, 'data_types', 'display_name_plural', 2, 'pt', 'Menus', '2021-07-19 01:13:05', '2021-07-19 01:13:05'),
(12, 'data_types', 'display_name_plural', 3, 'pt', 'Funções', '2021-07-19 01:13:05', '2021-07-19 01:13:05'),
(13, 'categories', 'slug', 1, 'pt', 'categoria-1', '2021-07-19 01:13:05', '2021-07-19 01:13:05'),
(14, 'categories', 'name', 1, 'pt', 'Categoria 1', '2021-07-19 01:13:05', '2021-07-19 01:13:05'),
(15, 'categories', 'slug', 2, 'pt', 'categoria-2', '2021-07-19 01:13:05', '2021-07-19 01:13:05'),
(16, 'categories', 'name', 2, 'pt', 'Categoria 2', '2021-07-19 01:13:05', '2021-07-19 01:13:05'),
(17, 'pages', 'title', 1, 'pt', 'Olá Mundo', '2021-07-19 01:13:05', '2021-07-19 01:13:05'),
(18, 'pages', 'slug', 1, 'pt', 'ola-mundo', '2021-07-19 01:13:06', '2021-07-19 01:13:06'),
(19, 'pages', 'body', 1, 'pt', '<p>Olá Mundo. Scallywag grog swab Cat o\'nine tails scuttle rigging hardtack cable nipper Yellow Jack. Handsomely spirits knave lad killick landlubber or just lubber deadlights chantey pinnace crack Jennys tea cup. Provost long clothes black spot Yellow Jack bilged on her anchor league lateen sail case shot lee tackle.</p>\r\n<p>Ballast spirits fluke topmast me quarterdeck schooner landlubber or just lubber gabion belaying pin. Pinnace stern galleon starboard warp carouser to go on account dance the hempen jig jolly boat measured fer yer chains. Man-of-war fire in the hole nipperkin handsomely doubloon barkadeer Brethren of the Coast gibbet driver squiffy.</p>', '2021-07-19 01:13:06', '2021-07-19 01:13:06'),
(20, 'menu_items', 'title', 1, 'pt', 'Painel de Controle', '2021-07-19 01:13:06', '2021-07-19 01:13:06'),
(21, 'menu_items', 'title', 2, 'pt', 'Media', '2021-07-19 01:13:06', '2021-07-19 01:13:06'),
(22, 'menu_items', 'title', 12, 'pt', 'Publicações', '2021-07-19 01:13:06', '2021-07-19 01:13:06'),
(23, 'menu_items', 'title', 3, 'pt', 'Utilizadores', '2021-07-19 01:13:06', '2021-07-19 01:13:06'),
(24, 'menu_items', 'title', 11, 'pt', 'Categorias', '2021-07-19 01:13:06', '2021-07-19 01:13:06'),
(25, 'menu_items', 'title', 13, 'pt', 'Páginas', '2021-07-19 01:13:06', '2021-07-19 01:13:06'),
(26, 'menu_items', 'title', 4, 'pt', 'Funções', '2021-07-19 01:13:06', '2021-07-19 01:13:06'),
(27, 'menu_items', 'title', 5, 'pt', 'Ferramentas', '2021-07-19 01:13:06', '2021-07-19 01:13:06'),
(28, 'menu_items', 'title', 6, 'pt', 'Menus', '2021-07-19 01:13:06', '2021-07-19 01:13:06'),
(29, 'menu_items', 'title', 7, 'pt', 'Base de dados', '2021-07-19 01:13:06', '2021-07-19 01:13:06'),
(30, 'menu_items', 'title', 10, 'pt', 'Configurações', '2021-07-19 01:13:06', '2021-07-19 01:13:06');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'users/default.png',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `settings` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `name`, `email`, `avatar`, `email_verified_at`, `password`, `remember_token`, `settings`, `created_at`, `updated_at`) VALUES
(1, 1, 'Tareq', 'tareq@office.bdcom.com', 'users/default.png', NULL, '$2y$10$z37NCdWm4Oi0OtSfEskIuuNT5bFHOx/i/fbelPY.NfHZP/NKExh7e', 'xPrrUvIwu5tcUFemaJBhcKaZGRON7f0mi7gjjTsYxCgEdqpj5bcPx5dslnsN', '{\"locale\":\"en\"}', '2021-07-19 01:13:02', '2021-07-19 01:16:09'),
(3, 3, 'Jewel', 'jewel@office.bdcom.com', 'users/default.png', NULL, '$2y$10$nP4KbjDd/1NKawOHK/2mGOeQ2T3bzcUQebkGpaYHkaswXGHkeyXlS', 'bMf9KC2In0RCxpsTosSYykGe1xinxBrBimlTguNzKa0n473jCRuMcfhw7Oth', '{\"locale\":\"en\"}', '2021-09-12 03:05:27', '2021-09-12 03:05:27'),
(4, 1, 'Nahid', 'nahid@bdcom.com', 'users/default.png', NULL, '$2y$10$3RNLbomJq1CrRxbXr/eMa.sLBu8tlfdS2gymsm4vsCPQgLQp3947i', NULL, NULL, '2022-11-08 02:38:11', '2022-11-08 02:38:11'),
(5, 1, 'ziadul', 'ziadul@bdcom.com', 'users/default.png', NULL, '$2y$10$nJirMzJ3v349.P6Qdu9.weWoPPB6wfh7tepl2NdBD.E/836UI4tC2', NULL, '{\"locale\":\"en\"}', '2022-11-09 02:32:32', '2022-11-09 02:32:32');

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

CREATE TABLE `user_roles` (
  `user_id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `zone_offices`
--

CREATE TABLE `zone_offices` (
  `id` int UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `district_id` int NOT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int NOT NULL,
  `status` tinyint NOT NULL DEFAULT '0',
  `created_by` int UNSIGNED NOT NULL,
  `last_updated_by` int UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `contact_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '+8809666 666 666',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'helpdesk@smile.com.bd'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `zone_offices`
--

INSERT INTO `zone_offices` (`id`, `title`, `district_id`, `address`, `order`, `status`, `created_by`, `last_updated_by`, `created_at`, `updated_at`, `contact_number`, `email`) VALUES
(1, 'Motijheel Office', 1, '<p>Monjuri Bhaban (3rd Floor), &nbsp;</p>\r\n<p>8 DIT Avenue,</p>\r\n<p>Motijheel, Dhaka-1000</p>', 1, 1, 1, 4, '2021-07-31 22:45:18', '2022-11-21 21:38:20', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(2, 'Palton Office', 1, 'Sultan Ahmed Plaza (6th Floor), Suite: 605, 32 Purana Paltan, Dhaka-1000', 2, 1, 1, 4, '2021-07-31 22:51:45', '2022-11-13 05:08:48', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(3, 'Panthapath Office', 1, 'Firoz Tower (15th Floor) 152/3B, Bir Uttam Nuruzzaman Sarak, Panthapath, Dhaka-1215', 3, 1, 1, 4, '2021-08-29 03:54:07', '2022-11-13 05:09:00', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(4, 'Gulshan Office', 1, 'House: 36 (1st Floor), Road: 117, Gulshan: 1, Dhaka-1212', 4, 1, 1, 4, '2021-08-29 03:54:44', '2022-11-13 05:09:12', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(5, 'Banasree Rampura Office', 1, 'House: 32 (Ground Floor), Road: 2, Block: A, Banasree Rampura, Dhaka-1219', 5, 1, 1, 4, '2021-08-29 03:55:17', '2022-11-13 05:09:23', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(6, 'Bashundhara, Dhaka', 1, 'Ground floor, House: 749, Road: 23, Block: G, Bashundhara, Dhaka', 6, 1, 1, NULL, '2021-08-29 03:55:45', '2021-08-29 03:55:45', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(7, 'Mirpur Office', 1, 'House: 03 (Ground Floor), Road: 2, Block: D, Mirpur: 2, Dhaka', 7, 1, 1, 4, '2021-08-29 03:56:20', '2022-11-13 05:09:33', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(8, 'Mirpur DOHS Office', 1, 'House: 1252 (Ground Floor), Road: 9, Mirpur DOHS, Dhaka', 8, 1, 1, 4, '2021-08-29 03:56:45', '2022-11-13 05:09:44', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(9, 'Uttara, Sector-11 Office', 1, 'House: 4 (4th Floor), Road: 19, Sector: 11, Uttara, Dhaka', 9, 1, 1, 4, '2021-08-29 03:57:27', '2022-11-13 05:09:58', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(10, 'Uttara, Sector-7 Office', 1, 'Sayed Grand Center (5th Floor), House: 89, Road: 28, Sector: 7, Uttara, Dhaka-1230', 10, 1, 1, 4, '2021-08-29 03:58:17', '2022-11-13 05:10:07', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(11, 'Savar Office', 1, 'Block: B, 123 Jalessor, Siraj Auto Engineering Market, Savar Bus Stand, Savar', 11, 1, 1, 4, '2021-08-29 03:59:02', '2022-11-13 05:10:22', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(12, 'Comilla', 4, 'Artisan Nasir Center, Holding No: 491, Nazrul Islam Avenue, Kandirpar, Comilla', 12, 1, 1, NULL, '2021-08-29 04:07:01', '2021-08-29 04:07:01', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(13, 'Narayanganj', 5, '1/1 (4th floor), Alam Khan Lane, BB Road, Narayanganj', 13, 1, 1, NULL, '2021-08-29 04:07:34', '2021-08-29 04:07:34', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(14, 'Bogra', 6, '739/A Rabu Tower (5th Floor), Bogra Rangpur Road, Borogola, Bogra', 14, 1, 1, NULL, '2021-08-29 04:08:07', '2021-08-29 04:08:07', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(15, 'Chittagong', 7, 'Lokman Tower (6th Floor), House: 1646, Sheak Mujib Road, Pathantuli, Chownuhani Agrabad, Chittagong', 15, 1, 1, NULL, '2021-08-29 04:09:01', '2021-08-29 04:09:01', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(16, 'GEC, Chittagong', 7, 'GEC Dampara (Ground Floor), 18 Zakir Hossain Road, Chittagong', 16, 1, 1, NULL, '2021-08-29 04:09:38', '2021-08-29 04:09:38', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(17, 'Sylhet', 3, 'Anando Tower & Shopping Complex (6th Floor), Flat: 7/A, Jail Road, Dopa Uttor Par, Sylhet', 17, 1, 1, NULL, '2021-08-29 04:10:12', '2021-08-29 04:10:12', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(18, 'Amborkhana, Sylhet', 3, 'Wave: B-103 (1st Floor), Dorgahgate, Amborkhana, Sylhet', 18, 1, 1, NULL, '2021-08-29 04:10:50', '2021-08-29 04:10:50', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(19, 'Khulna', 2, 'Mollick Shopping Complex (5th Floor), House: 99, Khan A Sabur Road, Dak Bangla, Khulna', 19, 1, 1, NULL, '2021-08-29 04:11:19', '2021-08-29 04:11:19', '+8809666 666 666', 'helpdesk@smile.com.bd'),
(20, 'Rangpur', 8, 'House: 16/1, Road: 2 PB Road, Choto Monthona, Kotwali, Rangpur', 20, 1, 1, NULL, '2021-08-29 04:11:45', '2021-08-29 04:11:45', '+8809666 666 666', 'helpdesk@smile.com.bd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brand_categories`
--
ALTER TABLE `brand_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`),
  ADD KEY `categories_parent_id_foreign` (`parent_id`);

--
-- Indexes for table `connectivity_applications`
--
ALTER TABLE `connectivity_applications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contents`
--
ALTER TABLE `contents`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `contents_slug_unique` (`slug`);

--
-- Indexes for table `content_faqs`
--
ALTER TABLE `content_faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_reviews`
--
ALTER TABLE `customer_reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_rows`
--
ALTER TABLE `data_rows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `data_rows_data_type_id_foreign` (`data_type_id`);

--
-- Indexes for table `data_types`
--
ALTER TABLE `data_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `data_types_name_unique` (`name`),
  ADD UNIQUE KEY `data_types_slug_unique` (`slug`);

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `districts_name_unique` (`name`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `get_information_requests`
--
ALTER TABLE `get_information_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `internet_coverages`
--
ALTER TABLE `internet_coverages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `menus_name_unique` (`name`);

--
-- Indexes for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_items_menu_id_foreign` (`menu_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `network_coverages`
--
ALTER TABLE `network_coverages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `packages_slug_unique` (`slug`);

--
-- Indexes for table `package_categories`
--
ALTER TABLE `package_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `package_faqs`
--
ALTER TABLE `package_faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pages_slug_unique` (`slug`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permissions_key_index` (`key`);

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `permission_role_permission_id_index` (`permission_id`),
  ADD KEY `permission_role_role_id_index` (`role_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `posts_slug_unique` (`slug`);

--
-- Indexes for table `problem_types`
--
ALTER TABLE `problem_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `service_values`
--
ALTER TABLE `service_values`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `settings_key_unique` (`key`);

--
-- Indexes for table `slideshows`
--
ALTER TABLE `slideshows`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `social_media`
--
ALTER TABLE `social_media`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `solution_requests`
--
ALTER TABLE `solution_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `solution_requirement_types`
--
ALTER TABLE `solution_requirement_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `solution_requirement_types_title_unique` (`title`);

--
-- Indexes for table `translations`
--
ALTER TABLE `translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `translations_table_name_column_name_foreign_key_locale_unique` (`table_name`,`column_name`,`foreign_key`,`locale`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_role_id_foreign` (`role_id`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `user_roles_user_id_index` (`user_id`),
  ADD KEY `user_roles_role_id_index` (`role_id`);

--
-- Indexes for table `zone_offices`
--
ALTER TABLE `zone_offices`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `brand_categories`
--
ALTER TABLE `brand_categories`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `connectivity_applications`
--
ALTER TABLE `connectivity_applications`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `contents`
--
ALTER TABLE `contents`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `content_faqs`
--
ALTER TABLE `content_faqs`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `customer_reviews`
--
ALTER TABLE `customer_reviews`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `data_rows`
--
ALTER TABLE `data_rows`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=364;

--
-- AUTO_INCREMENT for table `data_types`
--
ALTER TABLE `data_types`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `districts`
--
ALTER TABLE `districts`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `get_information_requests`
--
ALTER TABLE `get_information_requests`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `internet_coverages`
--
ALTER TABLE `internet_coverages`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `network_coverages`
--
ALTER TABLE `network_coverages`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `package_categories`
--
ALTER TABLE `package_categories`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `package_faqs`
--
ALTER TABLE `package_faqs`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `problem_types`
--
ALTER TABLE `problem_types`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `service_values`
--
ALTER TABLE `service_values`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `slideshows`
--
ALTER TABLE `slideshows`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `social_media`
--
ALTER TABLE `social_media`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `solution_requests`
--
ALTER TABLE `solution_requests`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `solution_requirement_types`
--
ALTER TABLE `solution_requirement_types`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `translations`
--
ALTER TABLE `translations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `zone_offices`
--
ALTER TABLE `zone_offices`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `data_rows`
--
ALTER TABLE `data_rows`
  ADD CONSTRAINT `data_rows_data_type_id_foreign` FOREIGN KEY (`data_type_id`) REFERENCES `data_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD CONSTRAINT `menu_items_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`);

--
-- Constraints for table `user_roles`
--
ALTER TABLE `user_roles`
  ADD CONSTRAINT `user_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_roles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
